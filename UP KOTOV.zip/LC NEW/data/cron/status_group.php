<?php

    include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
    $sql = $mysqli->query('SELECT * FROM `groupstat`');
    while($db = $sql->fetch_array()) {
	
	$access_token = $db['token'];
	$gid = $db['group'];
    $country = 'В России'; 
date_default_timezone_set ('Europe/Moscow'); 

$time = date("H:i");

$mGet = curl('https://api.vk.com/method/groups.getMembers?group_id='.$gid.'&count=1&access_token='.$access_token);
$json = json_decode($mGet,1);
$countM = $json['response']['count'];

$pGet = curl('https://api.vk.com/method/wall.get?owner_id=-'.$gid.'&count=1&access_token='.$access_token);
$jsonD = json_decode($pGet,1);
$countD = $jsonD['response']['0'];

$blGet = curl('https://api.vk.com/method/groups.getBanned?group_id='.$gid.'&count=1&access_token='.$access_token);
$json1 = json_decode($blGet,1);
$countR = $json1['response']['0'];


$status = ' &#127760; Время '.$time.'  👥 Участников: '.$countM.' 🚶 В ЧС: '.$countR.' ☺  Постов: '.$countD;

$statusSet = curl('https://api.vk.com/method/status.set?text='.urlencode($status).'&group_id='.$gid.'&access_token='.$access_token);
	}

function curl( $url ){
    $ch = curl_init( $url );
    curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
    curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, false );
    curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
    $response = curl_exec( $ch );
    curl_close( $ch );
    return $response;
}
?>