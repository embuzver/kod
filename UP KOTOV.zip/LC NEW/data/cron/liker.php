<?php
      include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');

	$sql1 = $mysqli->query('SELECT * FROM `liker`');
    while($db = $sql1->fetch_array()) {
		
    $id = $db['id']; 
    $user = $db['user']; // ПРОФИЛЬ ID
    $token = $db['token']; // ACCESS_TOKEN

	$method = 'https://api.vk.com/method/';
	$v = '&v=5.52';
	
    /*   НЕ СТРОЙ ИЗ СЕБЯ ПРАГРАМИСТРА, внизу нечего не трогай   */
    $group = random(array( '28870275' , '85719461' , '117989717' , '111242352' , '74294944' , '102107767' , '107601843', '90701007', '123807551', '115926097'));
    $pin = json_decode(file_get_contents("{$method}wall.get?owner_id=-{$group}&count=2&filter=owner{$v}"), true)[response][items][0][is_pinned];
    $wallGet = json_decode(file_get_contents("{$method}wall.get?owner_id=-{$group}&offset={$pin}&count=2&filter=owner"), true)[response][1][id];
    $Liked = json_decode(file_get_contents("{$method}likes.isLiked?type=post&owner_id={$group}&item_id={$wallGet}{$v}&access_token={$token}"), true)[response][liked];
    if('0' == $Liked) { echo $likesAdd = file_get_contents("{$method}likes.add?type=post&owner_id=-{$group}&item_id={$wallGet}&access_token={$token}"); }
}
    function random($my_rand) {
	$random = mt_rand(0,count($my_rand)-1); 
	return $my_rand[$random]; 
}
?> 