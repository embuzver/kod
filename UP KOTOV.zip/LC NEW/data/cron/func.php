<?php
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
$send = $mysqli->query('SELECT * FROM `online`');
while($db = $send->fetch_array()){

/* ������ ������ */
if ($db['online']=='2') { 
$Online = curl('https://api.vk.com/method/account.setOnline?&access_token='.$db['token']); 
}

/* ������ :3 */
} function curl($url){
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}?>