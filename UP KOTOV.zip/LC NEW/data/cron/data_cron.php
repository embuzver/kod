<? session_start();

$start = microtime(true);
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
$getinfo = $mysqli->query('SELECT * FROM `status`');
while($db = $getinfo->fetch_array()) {

// Status-1
if($db['status_id'] == 1) {
	date_default_timezone_set($db['city']);
	$time3 = date('H:i');
	$time1 = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
	$time2 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '&#127358;');
	$time = str_replace($time1, $time2, $time3);

	$data3 = date('d.m');
	$data1 = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
	$data2 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '&#127358;');
	$data = str_replace($data1, $data2, $data3);

	$getLikesJson = curl('photos.get?album_id=profile&rev=1&extended=1&count=1&access_token='.$db['token'].'&v=3.0');
	$likes = $getLikesJson['0']['likes']['count'];

	$smiles = array('💗', '💘', '💙','💚', '💛', '💜');
	$rand = rand(0,count($smiles) - 1);
	$hurt = $smiles[$rand];

	$json = curl('users.get?name_case=nom&access_token='.$db['token']);
	$userid = $json['0']['uid'];

	$ID3 = $json['0']['uid'];
	$ID1 = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
	$ID2 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '&#127358;');
	$ID = '🆔 '.str_replace($ID1, $ID2, $ID3).' ';

	$status = '    '.$time.'| '.$hurt.' на аве лайков: '.$likes.' | '.$data.'           '.$ID;
	$sendStats = curl('status.set?text='.urlencode($status).'&v=3.0&access_token='.$db['token']);
	if($sendStats['error_code']){ echo $sendStats['error_msg'].' | ERR CODE: '.$sendStats['error_code'].' |  USER ID: '.$db['user_id'].' <br>';
	} else { echo '{"response":1, "user_id":'.$db['user_id'].'} <br>'; }
	if($sendStats['error_code']=='2' || $sendStats['error_code']=='5' || $sendStats['error_code']=='7' || $sendStats['error_code']=='15' || $sendStats['error_code']=='18')
	{ $mysqli->query('DELETE FROM `status` WHERE `user_id`="'.$db['user_id'].'"'); }
}

// Status-2

if($db['status_id'] == 2) {
	date_default_timezone_set($db['city']);
	$time = date('H:i'); $date1 = date('d.m');

	$getLikesJson = curl('photos.get?album_id=profile&rev=1&extended=1&count=1&access_token='.$db['token'].'&v=3.0');
	$likes = $getLikesJson['0']['likes']['count'];

	$json = curl('messages.get?count=1&access_token='.$db['token']);
	$countM = $json['0'];

	$smiles = array('😼', '😸', '😆', '😾', '😚', '😸', '😽', '😉', '😊', '😉', '😘', '😼', '😽', '😾', '😉', '🐩', '😜', '😽');
	$rand = rand(0,count($smiles) - 1);
	$hurt = $smiles[$rand];

	$smi3 = 'ᅠᅠᅠᅠᅠ '.$time.' ᅠᅠᅠᅠ '.$hurt.' ᅠᅠᅠᅠ '.$date1;
	$smi = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
	$smi2 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '0⃣');

	$status = str_replace($smi, $smi2, $smi3);
	$sendStats = curl('status.set?text='.urlencode($status).'&access_token='.$db['token']);
	if($sendStats['error_code']){ echo $sendStats['error_msg'].' | ERR CODE: '.$sendStats['error_code'].' |  USER ID: '.$db['user_id'].' <br>';
	} else { echo '{"response":1, "user_id":'.$db['user_id'].'} <br>'; }
	if($sendStats['error_code']=='2' || $sendStats['error_code']=='5' || $sendStats['error_code']=='7' || $sendStats['error_code']=='15' || $sendStats['error_code']=='18')
	{ $mysqli->query('DELETE FROM `status` WHERE `user_id`="'.$db['user_id'].'"'); }
}

//Status-3

if($db['status_id'] == 3) {
	date_default_timezone_set($db['city']);
	$time = date('H:i'); $date = date('d.m');

	$json = curl('account.getBanned?access_token='.$db['token']);
	$countM = $json['0'];

	$a7 = '  В чёрном списке: $countM';
	$a8 = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
	$a9 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '0⃣');

	$a1 = $time;
	$a2 = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
	$a3 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '0⃣');

	$a4 = $date;
	$a5 = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
	$a6 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '0⃣');

	$smiles = array('😼', '😸', '😆', '😾', '😚', '😸', '😽', '😉', '😊', '😉', '😘', '😼', '😽', '😾', '😉', '🐩', '😜', '😽');
	$rand = rand(0,count($smiles) - 1);
	$hurt = $smiles[$rand];

	$json2 = curl('users.get?access_token='.$db['token'].'&fields=uid,first_name,last_name,nickname,screen_name,sex,bdate,city,country,timezone,photo,photo_medium,photo_big,has_mobile,rate,contacts,education,online,counters');
	$fonline = $json2['0']['counters']['online_friends'];
	$friends = $json2['0']['counters']['friends'];

	$json1 = curl('users.get?fields=online&name_case=Nom&access_token='.$db['token']);
	$countR = $json1[0]['online_mobile'];
	$countD = $json1[0]['online'];

	$online2 = array(0 => 'В данный момент я &#128564;', 1 => 'В данный момент я с компьютера &#128187;');
	$online = array(1 => 'В данный момент я с телефона &#128242;');


	if($countR == 1) { $answer=$online[$countR]; } else { $answer=$online2[$countD]; }
	$status = (''.str_replace($a2, $a3, $a1).'          '.$hurt.'         '.str_replace($a5, $a6, $a4).' '.str_replace($a8, $a9, $a7).' | '.$answer.'         Online '.$fonline.' из '.$friends.'');
	$sendStats = curl('status.set?text='.urlencode($status).'&access_token='.$db['token']);
	if($sendStats['error_code']){ echo $sendStats['error_msg'].' | ERR CODE: '.$sendStats['error_code'].' |  USER ID: '.$db['user_id'].' <br>';
	} else { echo '{"response":1, "user_id":'.$db['user_id'].'} <br>'; }
	if($sendStats['error_code']=='2' || $sendStats['error_code']=='5' || $sendStats['error_code']=='7' || $sendStats['error_code']=='15' || $sendStats['error_code']=='18')
	{ $mysqli->query('DELETE FROM `status` WHERE `user_id`="'.$db['user_id'].'"'); }
}

//Status-4

if($db['status_id'] == 4) {
	date_default_timezone_set($db['city']);

	$getMessagesJson = curl('messages.get?lang=ru&v=3.0&count=1&access_token='.$db['token']);
	$userIdLastMessage = $getMessagesJson['1']['uid'];
	$getDataOfLastUserJson = curl('users.get?lang=ru&v=3.0&user_ids='.$userIdLastMessage.'&name_case=gen&access_token='.$db['token']);
	$lastUserName = $getDataOfLastUserJson['0']['first_name'];
	$lastUserSurname = $getDataOfLastUserJson['0']['last_name'];

	$time3 = date('H:i');
	$time1 = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
	$time2 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '&#127358;');
	$time  = str_replace($time1, $time2, $time3);

	$data3 = date('d.m');
	$data1 = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
	$data2 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '&#127358;');
	$date = str_replace($data1, $data2, $data3);

	$json1 = curl('users.get?user_ids='.$tvoiID.'&fields=online&name_case=Nom&access_token='.$db['token']);
	$countR = $json1['response'][0]['online_mobile'];
	$countD = $json1['response'][0]['online'];

	$online2 = array(0 => 'Я &#128564;', 1 => 'Я с &#128187;');
	$online = array(1 => 'Я с &#128242;');
	if($countR == 1) { $answer="$online[$countR]"; } else { $answer="$online2[$countD]"; }

	$getLikesJson = curl('photos.get?album_id=profile&rev=1&extended=1&count=1&access_token='.$db['token'].'&v=3.0');
	$likes = $getLikesJson['0']['likes']['count'];

	$json = curl('account.getBanned?access_token='.$db['token']);
	$колво_в_чс = $json['0'];

	$smiles = array("😸", "🙀", "😿","😾", "😹", "😼", "😻", "😎","😉", "😈", "😂", "😃", "😀");
	$smiles2 = array("🐸", "👻", "😺","😘", "😚", "😎", "😍", "😜","😃", "💍", "💎", "💌", "😙");
	$rand = rand(0,count($smiles) - 1);
	$rand2 = rand(0,count($smiles) - 1);
	$rand3 = rand(0,count($smiles2) - 1);
	$smail = $smiles2[$rand];
	$smail2 = $smiles2[$rand2];
	$smail3 = $smiles[$rand3];

	$status = '|&#8987;|'.$time.' ('.$smail2.')  На аве:'.$likes.'❤ ('.$smail.')  | &#128197; | '.$date.' Последнее ✉ от '.$lastUserName.' '.$lastUserSurname.' | ⛔ В чс: '.$колво_в_чс.' | '.$answer.' | ('.$smail3.')';
	$sendStats = curl('status.set?text='.urlencode($status).'&access_token='.$db['token']);
	if($sendStats['error_code']){ echo $sendStats['error_msg'].' | ERR CODE: '.$sendStats['error_code'].' |  USER ID: '.$db['user_id'].' <br>';
	} else { echo '{"response":1, "user_id":'.$db['user_id'].'} <br>'; }
	if($sendStats['error_code']=='2' || $sendStats['error_code']=='5' || $sendStats['error_code']=='7' || $sendStats['error_code']=='15' || $sendStats['error_code']=='18')
	{ $mysqli->query('DELETE FROM `status` WHERE `user_id`="'.$db['user_id'].'"'); }
}

//Status-5

if($db['status_id'] == 5) {
	date_default_timezone_set($db['city']);

	$carl = array("1", "2", "3", "4", "5", "6", "7", "8", "9", "0");
	$ezgo = array("1⃣", "2⃣", "3⃣", "4⃣", "5⃣", "6⃣", "7⃣", "8⃣", "9⃣", "0⃣");

	$photoGet = curl('photos.get?album_id=profile&rev=1&extended=1&access_token='.$db['token']);
	$countL = $photoGet[0]['likes']['count'];

	$getDialogs = curl('messages.getDialogs?access_token='.$db['token']);
	$countD = $getDialogs[0];

	$messageGet = curl('messages.get?access_token='.$db['token']);
	$countM = $messageGet[0];

	$getMessages = curl('messages.get?v=3.0&count=1&access_token='.$db['token']);
	$uid = $getMessages[1]['uid'];

	$usersGet = curl('users.get?user_ids=".$uid."&name_case=gen&access_token='.$db['token']);
	$first_name = $usersGet[0]['first_name'];
	$last_name = $usersGet[0]['last_name'];

	$likeS = array('💗', '💘', '💙', '💚', '💛');
	$randL = rand(0,count($likeS) - 1);
	$like = $likeS[$randL];

	$smileS = array("😸", "🙀", "😿","😾", "😹", "😼", "😻", "😎","😉", "😈", "😂", "😃", "😀");
	$randS = rand(0,count($smileS) - 1);
	$smile = $smileS[$randS];

	$text = str_replace($carl, $ezgo, date("H:i")).'|📨:'.$countM.' |'.$smile.'| 📝:'.$countD.' |'.$smile.'| '.$like.':'.$countL.' |'.str_replace($carl, $ezgo, date("d.m")).'Последнее 📥 пришло от '.$first_name.' '.$last_name.
	$sendStats = curl('status.set?text='.urlencode($text).'&access_token='.$db['token']);
	if($sendStats['error_code']){ echo $sendStats['error_msg'].' | ERR CODE: '.$sendStats['error_code'].' |  USER ID: '.$db['user_id'].' <br>';
	} else { echo '{"response":1, "user_id":'.$db['user_id'].'} <br>'; }
	if($sendStats['error_code']=='2' || $sendStats['error_code']=='5' || $sendStats['error_code']=='7' || $sendStats['error_code']=='15' || $sendStats['error_code']=='18')
	{ $mysqli->query('DELETE FROM `status` WHERE `user_id`="'.$db['user_id'].'"'); }
}

//Status-6


if($db['status_id'] == 6) {
	date_default_timezone_set($db['city']);

	$time = date('H:i');
	$mm = array(1 => 'Января', 2 => 'Февраля', 3 => 'Марта', 4 => 'Апреля', 5 => 'Мая', 6 => 'Июня', 7 => 'Июля', 8 => 'Августа', 9 => 'Сентября', 10 => 'Октября', 11 => 'Ноября', 12 => 'Декабря');
	$date1 = date('d '.$mm[(date('n'))].'');

	$json = curl('messages.get?access_token='.$db['token']); $countM = $json['0'];
	$json2 = curl('users.get?access_token='.$db['token'].'&fields=uid,first_name,last_name,nickname,screen_name,sex,bdate,city,country,timezone,photo,photo_medium,photo_big,has_mobile,rate,contacts,education,online,counters');

	$followers = $json2['0']['counters']['followers'];
	$fonline = $json2['0']['counters']['online_friends'];
	$friends = $json2['0']['counters']['friends'];

	$status = ' &#9200;:'.$time.'&#12288;&#128197;:'.$date1.'&#12288;&#128229;:'.$countM.'&#12288;&#128107;:'.$friends.'&#12288;&#128101;:'.$followers.' ';
	$sendStats = curl('status.set?text='.urlencode($status).'&access_token='.$db['token']);
	if($sendStats['error_code']){ echo $sendStats['error_msg'].' | ERR CODE: '.$sendStats['error_code'].' |  USER ID: '.$db['user_id'].' <br>';
	} else { echo '{"response":1, "user_id":'.$db['user_id'].'} <br>'; }
	if($sendStats['error_code']=='2' || $sendStats['error_code']=='5' || $sendStats['error_code']=='7' || $sendStats['error_code']=='15' || $sendStats['error_code']=='18')
	{ $mysqli->query('DELETE FROM `status` WHERE `user_id`="'.$db['user_id'].'"'); }
}

//Status-7

if($db['status_id'] == 7) {
	date_default_timezone_set($db['city']);
	$curl = array("1", "2", "3", "4", "5", "6", "7", "8", "9", "0");
	$srv = array("1⃣", "2⃣", "3⃣", "4⃣", "5⃣", "6⃣", "7⃣", "8⃣", "9⃣", "0⃣");
	$smi3 = '                '.str_replace($curl, $srv, date("H:i")).'                        '.str_replace($curl, $srv, date("d.m.Y"));
	$sendStats = curl('status.set?text='.urlencode($smi3).'&access_token='.$db['token']);
	if($sendStats['error_code']){ echo $sendStats['error_msg'].' | ERR CODE: '.$sendStats['error_code'].' |  USER ID: '.$db['user_id'].' <br>';
	} else { echo '{"response":1, "user_id":'.$db['user_id'].'} <br>'; }
	if($sendStats['error_code']=='2' || $sendStats['error_code']=='5' || $sendStats['error_code']=='7' || $sendStats['error_code']=='15' || $sendStats['error_code']=='18')
	{ $mysqli->query('DELETE FROM `status` WHERE `user_id`="'.$db['user_id'].'"'); }
}

//Status-8

if($db['status_id'] == 8) {
	date_default_timezone_set($db['city']);
	$json = json_decode(file_get_contents('http://www.radiorecord.ru/xml/club_online_v6.txt'), 1);
	$artist = $json['ARTIST']; $name = $json['NAME'];

	$smile = random(array("😀","😂","😄","😅","😆","😉","☺","😌","😎"));
	$music = random(array("🎵","🎶","🔊","🎤","🎧","🎼"));
	$other = random(array("ℹ","🔄","⏺","🔂","🔁","🔀","⏯","▶"));

	$time2 = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
	$time3 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '0⃣');
	$time = str_replace($time2, $time3, date("H:i"));

	$status = $time.' | '.$smile.' | '.$other.' В прямом эфире Record Club играет :
	             								                       '.$music.' '.$artist.'  -  '.$name.' '.$music;
	$sendStats = curl('status.set?text='.urlencode($status).'&access_token='.$db['token']);
	if($sendStats['error_code']){ echo $sendStats['error_msg'].' | ERR CODE: '.$sendStats['error_code'].' |  USER ID: '.$db['user_id'].' <br>';
	} else { echo '{"response":1, "user_id":'.$db['user_id'].'} <br>'; }
	if($sendStats['error_code']=='2' || $sendStats['error_code']=='5' || $sendStats['error_code']=='7' || $sendStats['error_code']=='15' || $sendStats['error_code']=='18')
	{ $mysqli->query('DELETE FROM `status` WHERE `user_id`="'.$db['user_id'].'"'); }
}

//Status-9

if($db['status_id'] == 9) {
	date_default_timezone_set($db['city']);
	$time = date('H:i');
	$date = rdate('d M');

	$json = curl('messages.getDialogs?count&access_token='.$db['token']);
	$Dialogs = $json['0'];

	$json = curl('messages.get?access_token='.$db['token']);
	$колвосб = $json['0'];

	$getLikesJson = curl('photos.get?album_id=profile&rev=1&extended=1&count=1&access_token='.$db['token'].'&v=3.0');
	$likes = $getLikesJson['0']['likes']['count'];

	$смайл1 = random(array('&#9993;','&#128233;','&#128232;'));
	$смайл2 = random(array('&#128221;','&#128209;'));
	$смайл3 = random(array('&#128154;','&#128153;','&#128156;','&#128155;','&#10084;'));

	$status = '                 &#128197;'.$date.' &#8986;'.$time.'               
     '.$смайл1.'Входящих: '.$колвосб.'  '.$смайл2.'Диалогов: '.$Dialogs.'  '.$смайл3.'Лайков на аве: '.$likes.'';

	$sendStats = curl('status.set?text='.urlencode($status).'&v=3.0&access_token='.$db['token']);
	if($sendStats['error_code']){ echo $sendStats['error_msg'].' | ERR CODE: '.$sendStats['error_code'].' |  USER ID: '.$db['user_id'].' <br>';
	} else { echo '{"response":1, "user_id":'.$db['user_id'].'} <br>'; }
	if($sendStats['error_code']=='2' || $sendStats['error_code']=='5' || $sendStats['error_code']=='7' || $sendStats['error_code']=='15' || $sendStats['error_code']=='18')
	{ $mysqli->query('DELETE FROM `status` WHERE `user_id`="'.$db['user_id'].'"'); }
}

//Status-10

if($db['status_id'] == 10) {
	date_default_timezone_set($db['city']);
	$time3 = date('H:i');
	$time1 = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
	$time2 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '&#127358;');
	$time  = str_replace($time1, $time2, $time3);

	$data3 = date('d.m');
	$data1 = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
	$data2 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '&#127358;');
	$data = str_replace($data1, $data2, $data3);
	$status = 'Время: '.$time.' | Дата:  '.$data;
	$sendStats = curl('status.set?text='.urlencode($status).'&v=3.0&access_token='.$db['token']);
	if($sendStats['error_code']){ echo $sendStats['error_msg'].' | ERR CODE: '.$sendStats['error_code'].' |  USER ID: '.$db['user_id'].' <br>';
	} else { echo '{"response":1, "user_id":'.$db['user_id'].'} <br>'; }
	if($sendStats['error_code']=='2' || $sendStats['error_code']=='5' || $sendStats['error_code']=='7' || $sendStats['error_code']=='15' || $sendStats['error_code']=='18')
	{ $mysqli->query('DELETE FROM `status` WHERE `user_id`="'.$db['user_id'].'"'); } }

//Status-11

if($db['status_id'] == 11) {
	date_default_timezone_set($db['city']);
	$smile = random(array("😀","😂","😄","😅","😆","😉","☺","😌","😎"));
	$other = random(array("Добавь👾","МУР МУР😇","Хочу 10к ДР🎇","Я кися🍉","Кинь заявочку✔","Фыр Фыр🌺","Ищу тянку👑","Рррррр😻"));
	$time2 = array('1', '2', '3', '4', '5', '6', '7', '8', '9', '0');
	$time3 = array('1⃣', '2⃣', '3⃣', '4⃣', '5⃣', '6⃣', '7⃣', '8⃣', '9⃣', '0⃣');
	$time = str_replace($time2, $time3, date("H:i"));

	$status = $time.' | '.$smile.' | '.$other;
	$sendStats = curl('status.set?text='.urlencode($status).'&access_token='.$db['token']);
	if($sendStats['error_code']){ echo $sendStats['error_msg'].' | ERR CODE: '.$sendStats['error_code'].' |  USER ID: '.$db['user_id'].' <br>';
	} else { echo '{"response":1, "user_id":'.$db['user_id'].'} <br>'; }
	if($sendStats['error_code']=='2' || $sendStats['error_code']=='5' || $sendStats['error_code']=='7' || $sendStats['error_code']=='15' || $sendStats['error_code']=='18')
	{ $mysqli->query('DELETE FROM `status` WHERE `user_id`="'.$db['user_id'].'"'); }
}

#StatusDone
}

#Функции
function rdate($param, $time=0){
	if(intval($time)==0)$time=time();
	$MonthNames=array("Января", "Февраля", "Марта", "Апреля", "Мая", "Июня", "Июля", "Августа", "Сентября", "Октября", "Ноября", "Декабря");
	if(strpos($param,'M')===false) return date($param, $time);
	else return date(str_replace('M',$MonthNames[date('n',$time)-1],$param), $time);
}

function random($text) {
	$random = mt_rand(0,count($text)-1);
	return $text[$random];
}

function curl($method) {
	$ch = curl_init('https://api.vk.com/method/'.$method);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
	curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
	$response = curl_exec($ch);
	curl_close($ch);
	$json = json_decode($response, true);
	if($json['error']['error_msg']) {
		return $json['error'];
	} else {
		return $json['response'];
	}
}

$mysqli->query('UPDATE `work_time` SET `status`="'.number_format(microtime(true) - $start, 3).'"');
$mysqli->close();
