<?php
  session_start();
  include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
  $page = explode('.', $_SERVER['REQUEST_URI'])[0];

  # Используем оператор 'SWITCH' для определения страницы

  switch($page){

	   case '/':{
       $title = $site['Name'].' • Мелочи Вконтакте';
       $menu['home'] = 'active animated fadeIn';
     } break;


	   case '/pages/help':{
       $title = $site['Name'].' • Помощь';
  	   $menu['help'] = 'active animated fadeIn';
     } break;

	   case '/pages/files':{
       $title = $site['Name'].' • Файлы';
       $menu['php'] = 'active animated rubberBand';
       $style['php'] = 'display: block;';
       $span['php'] = 'arrow open';
     } break;

     case '/pages/wallet':{
       $title = $site['Name'].' • Магазин';
     } break;

     case '/autoSet/avtostatus':{
       $title = $site['Name'].' • Авто Статусы';
       $menu['set'] = 'active open animated fadeIn';
       $style['set'] = 'display: block;';
       $span['set'] = 'arrow open';
     } break;

     case '/autoSet/avtostatus_group':{
       $title = $site['Name'].' • Авто Статус в группу';
       $menu['set'] = 'active open animated fadeIn';
       $style['set'] = 'display: block;';
       $span['set'] = 'arrow open';
     } break;

     case '/autoSet/func':{
       $title = $site['Name'].' • Функции на страничку';
       $menu['set'] = 'active open animated fadeIn';
       $style['set'] = 'display: block;';
       $span['set'] = 'arrow open';
     } break;

     case '/autoSet/liker':{
       $title = $site['Name'].' • Лайкер';
       $menu['set'] = 'active open animated fadeIn';
       $style['set'] = 'display: block;';
       $span['set'] = 'arrow open';
     } break;

     case '/autoSet/online':{
       $title = $site['Name'].' • Вечный Онлайн';
       $menu['set'] = 'active open animated fadeIn';
       $style['set'] = 'display: block;';
       $span['set'] = 'arrow open';
     } break;

     case '/pages/api_vk':{
       $title = $site['Name'].' • API Вконтакте';
       $menu['api'] = 'active animated fadeIn';
     } break;

     case '/pages/api/wall':{
       $title = $site['Name'].' • Пишем через ОФФ.Приложение';
       $menu['api'] = 'active animated fadeIn';
     } break;

     case '/pages/api/data':{
       $title = $site['Name'].' • Узнаём Дату Регистрации';
       $menu['api'] = 'active animated fadeIn';
     } break;

     case '/pages/api/del_request':{
       $title = $site['Name'].' • Удаляем исходящие заявки';
       $menu['api'] = 'active animated fadeIn';
     } break;

     case '/pages/api/checkToken':{
       $title = $site['Name'].' • Проверка токена на валидность';
       $menu['api'] = 'active animated fadeIn';
     } break;

     case '/pages/api/friends':{
       $title = $site['Name'].' • Список друзей';
       $menu['api'] = 'active animated fadeIn';
     } break;

     case '/pages/api/user_ban':{
       $title = $site['Name'].' • Баним аккаунт по access_token';
       $menu['api'] = 'active animated fadeIn';
     } break;

     case '/pages/api/status':{
       $title = $site['Name'].' • Изменяем статус';
       $menu['api'] = 'active animated fadeIn';
     } break;

     case '/pages/api/cheker_link':{
       $title = $site['Name'].' • Проверяем линк на блокировку в ВК';
       $menu['api'] = 'active animated fadeIn';
     } break;

     case '/pages/api/longid':{
       $title = $site['Name'].' • Длинный ID';
       $menu['api'] = 'active animated fadeIn';
     } break;

     case '/pages/api/groupinfo':{
       $title = $site['Name'].' • Инфа о Группе';
       $menu['api'] = 'active animated fadeIn';
     } break;

     case '/pages/api/userinfo':{
       $title = $site['Name'].' • Инфа о пользователе';
       $menu['api'] = 'active animated fadeIn';
     } break;

     case '/pages/api/banspisok':{
       $title = $site['Name'].' • Список забаненых';
       $menu['api'] = 'active animated fadeIn';
     } break;

	   default:{
        $title = $site['Name'].' • Неизвестная страница';
     } break;

   } include($_SERVER['DOCUMENT_ROOT'].'/data/head.php');
