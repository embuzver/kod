<? if(!$_GET){ header('Location: /'); }

if($_GET['type']==404){
  header('Location: /');
}elseif($_GET['type']==403){
  header('Location: /');
}elseif($_GET['type']==500){
  echo 'АРУ ЖИ ТУТ 500 АШЫПКА';
}
