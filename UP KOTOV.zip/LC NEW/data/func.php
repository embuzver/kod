<? session_start(); set_time_limit(0);
if(!$_GET){ echo '{"response":null}'; }
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');

if(isset($_GET['userfunc'])){
$start = microtime(true);
$send = $mysqli->query('SELECT * FROM `set_func`');
while($rekt = $send->fetch_array()){
	$idz = $rekt['user_id'];
	if($rekt['friends_add']=='2') {
		$getRequests = curl('friends.getRequests?count=10&out=0&access_token='.$rekt['token']);
			if ($getRequests['count'] != 0) {
				for ($i = 0; $i < 10; $i++) {
						$sendfunc = curl('friends.add?user_id='.$getRequests['items'][$i].'&access_token='.$rekt['token']);
			    }
		   }
			if($sendfunc['error_code']){ echo $sendfunc['error_msg'].' | ERR CODE: '.$sendfunc['error_code'].' |  USER ID: '.$rekt['user_id'].' <br>';
 			} else { echo '{"response":1, "user_id":'.$rekt['user_id'].'} <br>'; }
 			if($sendfunc['error_code']=='2' || $sendfunc['error_code']=='5' || $sendfunc['error_code']=='7' || $sendfunc['error_code']=='15' || $sendfunc['error_code']=='18')
 			{ $mysqli->query('DELETE FROM `set_func` WHERE `user_id`="'.$rekt['user_id'].'"'); }
}

	if($rekt['friends_delete']=='2') {
		$delRequests = curl('friends.getRequests?out=1&count=10&access_token='.$rekt['token']);
		for($i = 0; $i < count($delRequests); $i++){
			$friends_delete = curl('friends.delete?user_id='.$delRequests[$i].'&access_token='.$rekt['token']);
			if($friends_delete['error_code']){ echo $friends_delete['error_msg'].' | ERR CODE: '.$friends_delete['error_code'].' |  USER ID: '.$rekt['user_id'].' <br>';
			} else { echo '{"response":1, "user_id":'.$rekt['user_id'].'} <br>'; }
			if($friends_delete['error_code']=='2' || $friends_delete['error_code']=='5' || $friends_delete['error_code']=='7' || $friends_delete['error_code']=='15' || $friends_delete['error_code']=='18')
			{ $mysqli->query('DELETE FROM `set_func` WHERE `user_id`="'.$rekt['user_id'].'"'); }
		}
	}

} $mysqli->query('UPDATE `work_time` SET `userfunc`="'.number_format(microtime(true) - $start, 3).'"'); }

if(isset($_GET['online'])){
$start = microtime(true);
$sql = $mysqli->query('SELECT * FROM online');
while($rekt = $sql->fetch_array()) {
	$token = $rekt['token'];
	$idz = $rekt['user_id'];
#Вывод через что мы сидим
	$json_online = curl('users.get?fields=online,online_mobile&access_token='.$token);
	$online = $json_online[0]['online']; $online_mobile = $json_online[0]['online_mobile'];

#Начинает работать онлайн
	if($online == 0) {
		$onlineset = curl('account.setOnline?access_token='.$token);
	} elseif($online_mobile == 1){ $onlineset = curl('account.setOnline?access_token='.$token); }

	if($onlineset['error_code']){ echo $onlineset['error_msg'].' | ERR CODE: '.$onlineset['error_code'].' |  USER ID: '.$rekt['user_id'].' <br>';
	} else { echo '{"response":1, "user_id":'.$rekt['user_id'].'} <br>'; }
	if($onlineset['error_code']=='2' || $onlineset['error_code']=='5' || $onlineset['error_code']=='7' || $onlineset['error_code']=='15' || $onlineset['error_code']=='18')
	{ $mysqli->query('DELETE FROM `online` WHERE `user_id`="'.$rekt['user_id'].'"'); }

  } $mysqli->query('UPDATE `work_time` SET `online`="'.number_format(microtime(true) - $start, 3).'"');
}


#Статус в группу
if(isset($_GET['group'])){
$start = microtime(true);
$sql = $mysqli->query('SELECT * FROM `groupstat`');
while($rekt = $sql->fetch_array()) {
	$idz = $rekt['user_id'];
		$access_token = $rekt['token'];
		$gid = $rekt['group']; $country = 'В России';
		date_default_timezone_set ('Europe/Moscow'); $time = date("H:i");
		$json = curl('groups.getMembers?group_id='.$gid.'&count=1&access_token='.$access_token); $countM = $json['count'];
		$jsonD = curl('wall.get?owner_id=-'.$gid.'&count=1&access_token='.$access_token); $countD = $jsonD['0'];
		$json1 = curl('groups.getBanned?group_id='.$gid.'&count=1&access_token='.$access_token); $countR = $json1['0'];

		$status = ' ⏰ Время: '.$time.'  👥 Участников: '.$countM.' ⛔ В чёрном списке: '.$countR.' ✉ Постов: '.$countD;
		$statusSet = curl('status.set?text='.urlencode($status).'&group_id='.$gid.'&access_token='.$access_token);

		if($statusSet['error_code']){ echo $statusSet['error_msg'].' | ERR CODE: '.$statusSet['error_code'].' |  USER ID: '.$rekt['user_id'].' <br>';
		} else { echo '{"response":1, "user_id":'.$rekt['user_id'].'} <br>'; }
		if($statusSet['error_code']=='2' || $statusSet['error_code']=='5' || $statusSet['error_code']=='7' || $statusSet['error_code']=='15' || $statusSet['error_code']=='18')
		{ $mysqli->query('DELETE FROM `groupstat` WHERE `user_id`="'.$rekt['user_id'].'"'); }

 } $mysqli->query('UPDATE `work_time` SET `status_group`="'.number_format(microtime(true) - $start, 3).'"');
}


 #Лайкер
if(isset($_GET['liker'])){
 $start = microtime(true);
 $sql = $mysqli->query('SELECT * FROM `liker`');
 while($rekt = $sql->fetch_array()) {

	 $group = random(array('28870275', '85719461', '117989717', '111242352', '35359693', '74294944', '102107767', '107601843', '90701007', '123807551', '115926097', '126796920', '97228740'));

	 $user = $rekt['user_id']; $token = $rekt['token'];
	 $pin = curl('wall.get?owner_id=-'.$group.'&count=2&filter=owner&v=5.52');
	 $offset = $pin['items'][0]['is_pinned'];

	 $wallGet = curl('wall.get?owner_id=-'.$group.'&offset='.$offset.'&count=2&filter=owner');
	 $wget = $wallGet[1]['id'];

	 $Liked = curl('likes.isLiked?type=post&owner_id='.$group.'&item_id='.$wget.'&v=5.52&access_token='.$token);
		$lkd = $Liked['liked'];

		if($lkd==0){ $likesAdd = curl('likes.add?type=post&owner_id=-'.$group.'&item_id='.$wget.'&access_token='.$token); }
		if($likesAdd['error_code']){ echo $likesAdd['error_msg'].' | ERR CODE: '.$likesAdd['error_code'].' |  USER ID: '.$rekt['user_id'].' <br>';
		} else { echo 'Likes:'.$likesAdd['likes'].'<br>'; }
		if($likesAdd['error_code']=='2' || $likesAdd['error_code']=='5' || $likesAdd['error_code']=='7' || $likesAdd['error_code']=='15' || $likesAdd['error_code']=='18')
		{ $mysqli->query('DELETE FROM `liker` WHERE `user_id`="'.$rekt['user_id'].'"'); }

 } $mysqli->query('UPDATE `work_time` SET `liker`="'.number_format(microtime(true) - $start, 3).'"');
}

#Функции

	function curl($method) {
		$ch = curl_init('https://api.vk.com/method/'.$method);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
		$response = curl_exec($ch);
		curl_close($ch);
		$json = json_decode($response, true);
		if($json['error']['error_msg']) {
			return $json['error'];
		} else {
			return $json['response'];
		}
	}

	function random($my_rand){
		$random = mt_rand(0,count($my_rand)-1);
		return $my_rand[$random];
	}
