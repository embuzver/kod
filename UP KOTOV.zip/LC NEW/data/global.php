<? session_start();
$getMicro = microtime(true);
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');

if(isset($_SESSION['uid'])) {
	$try = $mysqli->query('SELECT * FROM users WHERE profile="'.$_SESSION['uid'].'"');
	if($try->num_rows == 0){ unset($_SESSION['uid']); }
	$pinfo = $mysqli->query('SELECT `id` FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"')->fetch_array();
	$id = $pinfo['id']; $pinfo = $_SESSION['uid'];
}

class systems {

	public function online(){
	include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');

	if(isset($_SESSION['uid'])) {
		$pisos = $mysqli->query('SELECT `id` FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"')->fetch_array();
		$id = $pisos['id'];  $uid = $_SESSION['uid'];
		$mysqli->query('UPDATE `users` SET `lastjoin`="'.date('Y-m-d H:i:s', time()).'" WHERE `profile`="'.$_SESSION['uid'].'"');
		} return true;
	}

	public function firstreg(){
		if(isset($_SESSION['firstreg']) && $_SERVER['REQUEST_URI'] != '/'){
			unset($_SESSION['firstreg']);
		} if(isset($_SESSION['firstreg'])) {
				echo '<div class="col-md-12 animated fadeIn">
				<div class="portlet light portlet-fit portlet-form bordered" id="form_wizard_1">
				<div class="portlet-body"><div class="form-body">
				<img style="float:left; wight:120px; height:120px;" src="/resources/img_site/first_reg.gif">
				<div class="row"><center>
				<div class="col-md-10"><h4>Добро пожаловать</h4>
				<h5>Приветствуем тебя на нашем сервисе. Ты у нас впервые :0</h5>
				<h5>Если у вас возникнут вопросы то вы можете зайти в раздел "<a href="/pages/help.php">Помощь</a>"</h5> <div></div></div>
				</center></div></div></div></div></div>';
			}
	}

	public function security(){
    	session_start();
		include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
		$rnd1 = $this->cloudflare('GET', 'https://api.cloudflare.com/client/v4/zones?name='.$_SERVER['HTTP_HOST'].'');
		$ip = $_SERVER['REMOTE_ADDR'];

		if($_SERVER['HTTP_HOST']!=$host){ $this->killpanel('Анонимайзеры запрещены!'); }

		$load = sys_getloadavg(); $la = $load[0];
		$server = $_SERVER['HTTP_REFERER'];
		$host = $_SERVER['HTTP_HOST'];

		/* Функции */
		if($rnd1['result']['0']['paused'] == true) {
			if($mysqli->query('SELECT `ban` FROM `ip_users` WHERE `ip` = "'.$ip.'"')->fetch_array()['ban'] == 2){ header('HTTP/1.1 503 Banned by UAC'); $this->killpanel('IP Адрес заблокирован на сайте'); }
			if($mysqli->query('SELECT * FROM ip_users WHERE ip="'.$ip)->num_rows == 0) { $mysqli->query('INSERT INTO `ip_users` (`ip`, `agent`, `ref`) VALUES("'.$ip.'", "'.$agent.'", "'.$server.'")'); }
			if($this->checkAgent() == 1) {
					$mysqli->query('UPDATE `ip_users` SET `ban`="2" WHERE `ip`="'.$ip.'"');
					$chUser = $mysqli->query('SELECT * FROM `users` WHERE ip_user="'.$ip.'"');
					if($chUser->num_rows != 0) {
						$mysqli->query('UPDATE `users` SET `who`="0" WHERE `ip_user`="'.$ip.'"');
						$mysqli->query('UPDATE `ip_users` SET `agent`="'.$agent.'" WHERE `ip`="'.$ip.'"');
						die('Хорошая попытка, неудачник!');
					}
				} else { if($this->checkAgent() == 1){ die('Хорошая попытка, неудачник!'); } }
			}

		//Проверка на бан профиля
		if(isset($_SESSION['uid'])){
			$checkBan = $mysqli->query('SELECT * FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"')->fetch_array();
			if($checkBan['who'] == 0){
				header('HTTP/1.1 503 Banned by UAC'); $this->killpanel('Аккаунт заблокирован');
			}
		}

	

			# UAC Checker link
			if(strpos($server,'hideme.ru')) {
				$mysqli->query('UPDATE `ip_users` SET `ref`="'.$server.'", `ban`="2" WHERE `ip`="'.$ip.'"');
				killpanel('Анонимайзер: hideme.ru заблокирован на сайте');
			}
		$mysqli->close();
	 return true;
	}

	public function checkAgent(){
		$agent = $_SERVER['HTTP_USER_AGENT'];
		if(strpos($agent,"DISCo Pump") || strpos($agent,"Offline Explorer") || strpos($agent,"Teleport") || strpos($agent,"WebZIP") ||
		strpos($agent,"WebCopier") || strpos($agent,"Wget") || strpos($agent,"FlashGet") || strpos($agent,"CIS TE") || strpos($agent,"DTS Agent") ||
		strpos($agent,"WebReaper") || strpos($agent,"HTTrack") || strpos($agent,"(compatible; MSIE 6.0; Windows NT 5.0)") || strpos($agent,"(compatible; MSIE 5.5; Windows NT 5.0)") ||
		strpos($agent,"(compatible; MSIE 5.01; Windows NT 5.0)") || strpos($agent,"(compatible; MSIE 5.0; Win32)") || strpos($agent,"(compatible; MSIE 4.01; Windows 98)") ||
		strpos($agent,"(compatible; MSIE 4.01; Windows 95)") || strpos($agent,"(compatible; MSIE 4.01; Windows NT)") || strpos($agent,"(Windows NT 5.0; U)") ||
		strpos($agent,"(Win98; I)") || strpos($agent,"(Windows; U; Windows NT 5.0; en-US; rv:1.1) Gecko/20020826") || strpos($agent,"(Win95; I)") || strpos($agent,"(compatible; MSIE 3.01; Windows 95)") ||
		strpos($agent,"(X11; I; Linux 2.0.34 i686)") || strpos($agent,"(X11; U; SunOS 5.5.1 sun4m)") || strpos($agent,"(Macintosh; I; PPC)") || strpos($agent,"(Macintosh; I; PPC)") ||
		strpos($agent,"(OS/2; I)") || strpos($agent,"(X11; U; SunOS 5.6 sun4u)") || strpos($agent,"(X11; I; AIX 4.1)") || strpos($agent,"(X11; I; FreeBSD 2.2.6-RELEASE i386)") ||
		strpos($agent,"(X11; I; IRIX 6.3 IP32)") || strpos($agent,"(compatible; MSIE 2.0)") || strpos($agent,"(compatible; MS FrontPage Express 2.0)") || strpos($agent,"(Win98; I)") ||
		strpos($agent,"(compatible; HTTrack 3.0x; Windows 98)") || strpos($agent,"(offline browser; web mirror utility)") || strpos($agent,"Web Downloader")){ return 1; }else{ return 0; }
	}

	public function cloudflare($method, $url, $param) {
		include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
	    $ch = curl_init();
	    curl_setopt($ch, CURLOPT_URL, $url);
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	    curl_setopt($ch, CURLOPT_VERBOSE, 1);
	    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
	    curl_setopt($ch, CURLOPT_HTTPHEADER, $cfhead);
		  curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
	    $response = curl_exec($ch);
			$json = json_decode($response, true);
			if($json['errors'][0]['message']) {
				return $json['errors'][0];
			} else {
				return $json;
			}
	}

	public function is_mobile() {
		$user_agent=strtolower(getenv('HTTP_USER_AGENT'));
		$accept=strtolower(getenv('HTTP_ACCEPT'));
		if((strpos($accept,'text/vnd.wap.wml')!==false) ||
			(strpos($accept,'application/vnd.wap.xhtml+xml')!==false)) {
				return 1;
		} if(isset($_SERVER['HTTP_X_WAP_PROFILE']) ||
			isset($_SERVER['HTTP_PROFILE'])) {
				return 2;
		} if(preg_match('/(mini 9.5|vx1000|lge |m800|e860|u940|ux840|compal|'.
			'wireless| mobi|ahong|lg380|lgku|lgu900|lg210|lg47|lg920|lg840|'.
			'lg370|sam-r|mg50|s55|g83|t66|vx400|mk99|d615|d763|el370|sl900|'.
			'mp500|samu3|samu4|vx10|xda_|samu5|samu6|samu7|samu9|a615|b832|'.
			'm881|s920|n210|s700|c-810|_h797|mob-x|sk16d|848b|mowser|s580|'.
			'r800|471x|v120|rim8|c500foma:|160x|x160|480x|x640|t503|w839|'.
			'i250|sprint|w398samr810|m5252|c7100|mt126|x225|s5330|s820|'.
			'htil-g1|fly v71|s302|-x113|novarra|k610i|-three|8325rc|8352rc|'.
			'sanyo|vx54|c888|nx250|n120|mtk |c5588|s710|t880|c5005|i;458x|'.
			'p404i|s210|c5100|teleca|s940|c500|s590|foma|samsu|vx8|vx9|a1000|'.
			'_mms|myx|a700|gu1100|bc831|e300|ems100|me701|me702m-three|sd588|'.
			's800|8325rc|ac831|mw200|brew |d88|htc\/|htc_touch|355x|m50|km100|'.
			'd736|p-9521|telco|sl74|ktouch|m4u\/|me702|8325rc|kddi|phone|lg |'.
			'sonyericsson|samsung|240x|x320vx10|nokia|sony cmd|motorola|'.
			'up.browser|up.link|mmp|symbian|smartphone|midp|wap|vodafone|o2|'.
			'pocket|kindle|mobile|psp|treo|android|iphone|ipod|webos|wp7|wp8|'.
			'fennec|blackberry|htc_|opera m|windowsphone)/', $user_agent)) {
			return 3;
		} return false;
	}

	public function killpanel($text){
		die('<html><head>
		<title>Access Denied</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="/resources/css/secureSystem/main.css"></head>
		<body class="landing"><div id="page-wrapper"><header id="header" class="reveal alt"><h1> Доступ к сайту ограничен</h1></header>

		<section id="banner"><h2>'.$_SERVER['HTTP_HOST'].'</h2>
		<p class="web-inspector-hide-shortcut">'.$text.'</p><ul class="actions">
		<li><a href="https://vk.com/one.user" class="button special">Разработчик</a></li>
		</ul></section>

		<section id="main" class="container">
		<section class="box special"><header class="major"><h2>Design by RektCore</h2></header>
		<span class="image featured"></span></section></section></div>
		<script src="/resources/css/secureSystem/jquery.min.js"></script>
		<script src="/resources/css/secureSystem/jquery.dropotron.min.js"></script>
		<script src="/resources/css/secureSystem/jquery.scrollgress.min.js"></script>
		<script src="/resources/css/secureSystem/skel.min.js"></script>
		<script src="/resources/css/secureSystem/util.js"></script>
		<script src="/resources/css/secureSystem/main.js"></script>
		</body></html>');
	}

	public function content($md, $name, $content, $icon){
		if($icon){ $iic = '<i class="fa fa-'.$icon.' font-blue"></i>'; }
  	echo '<div class="col-md-'.$md.' animated fadeInUp">
		<div class="portlet light portlet-fit portlet-form bordered">
		<div class="portlet-title"><div class="caption">'.$iic.'
		<span class="caption-subject font-dark sbold uppercase">'.$name.'</span>
		</div></div><div class="portlet-body"><div class="form-body">
		<ul class="list-group">'.$content.'</ul></div></div></div></div>';
	}

}

