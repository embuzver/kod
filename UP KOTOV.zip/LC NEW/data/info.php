﻿<? include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');

/* Yandex Metrica */
$Metrica = json_decode(file_get_contents('https://api-metrika.yandex.ru/stat/traffic/summary.json?id='.$metrica_id.'&oauth_token='.$metrica_token.'&date1='.date('Ymd')));
if($Metrica->data[0]->visits==''){$stats->visits='Нету';} else {$stats->visits = $Metrica->data[0]->visits;}


$mtr = json_decode(file_get_contents('https://api-metrika.yandex.ru/stat/traffic/summary.json?id='.$metrica_id.'&oauth_token='.$metrica_token.'&date1='.date('Ymd', strtotime('-8 days')).'&date2='.date('Ymd')));
$rows = $mtr->rows; $go = $rows - 1; for($i = $go; $i >= 0; $i--) { $Denial[$i] = $mtr->data[$i]->denial.''; }
$stats->denials = 100 - number_format(($Denial[$go]+$Denial[$go-1]+$Denial[$go-2]+$Denial[$go-3]+$Denial[$go-4]+$Denial[$go-5]+$Denial[$go-6]+$Denial[$go-7]) / 8, 2);

$json = cloudflare('GET', 'https://api.cloudflare.com/client/v4/zones?name='.$_SERVER['HTTP_HOST']);
if($json['result']['0']['paused'] != true) { $stats->ip = 'CloudFlare CDN'; } else { $stats->ip = $_SERVER['REMOTE_ADDR']; }

/* Функции: Дополнительные */
$statusAvto = $mysqli->query('SELECT COUNT(*) as count FROM `status`')->fetch_row();
$groupAvto = $mysqli->query('SELECT COUNT(*) as count FROM `groupstat`')->fetch_row();
$onlineAvto = $mysqli->query('SELECT COUNT(*) as count FROM `online`')->fetch_row();
$funcAvto = $mysqli->query('SELECT COUNT(*) as count FROM `set_func`')->fetch_row();
$likerAvto = $mysqli->query('SELECT COUNT(*) as count FROM `liker`')->fetch_row();

$allsets = $statusAvto[0] + $groupAvto[0] + $onlineAvto[0] + $funcAvto[0] + $likerAvto[0]; $stats->allsets = $allsets;
$colusers = $mysqli->query('SELECT COUNT(*) as count FROM `users`')->fetch_row(); $stats->users = $colusers[0];
$guest = $mysqli->query('SELECT COUNT(*) as count FROM `ip_users`')->fetch_row(); $stats->guest = $guest[0];
$stats->statuses = $site['statuses'];

/* Функции */

function cloudflare($method, $url, $param){
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_VERBOSE, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $cfhead);
	  curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
  $response = curl_exec($ch);
	$json = json_decode($response, true);
	if($json['errors'][0]['message']) {
		return $json['errors'][0];
	} else {
		return $json;
	}
}

/* Курл ебал Карал :D */
function curl($method) {
	$ch = curl_init('https://api.vk.com/method/'.$method);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
	curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
	$response = curl_exec($ch);
	curl_close($ch);
	$json = json_decode($response, true);
	if($json['error']['error_msg']) {
		return $json['error'];
	} else {
		return $json['response'];
	}
}
?>
<div class="col-md-4 animated fadeInUp">
<div class="portlet light portlet-fit portlet-form bordered" id="form_wizard_1">
<div class="portlet-title"><div class="caption"><i class="fa fa-cloud-download font-blue"></i>
<span class="caption-subject font-dark sbold uppercase">Авто Установки</span>
</div></div><div class="portlet-body"><div class="form-body">
<ul class="list-group"><li class="list-group-item">Автостатус<span class="badge badge-default"><?=$statusAvto[0]; ?></span></li>
<li class="list-group-item">Автостатус в группу<span class="badge badge-success"><?=$groupAvto[0]; ?></span></li>
<li class="list-group-item">Лайкер<span class="badge badge-info"><?=$likerAvto[0]; ?></span></li>
<li class="list-group-item">Вечный онлайн<span class="badge badge-danger"><?=$onlineAvto[0]; ?></span></li>
<li class="list-group-item">Функции<span class="badge badge-info"><?=$funcAvto[0]; ?></span></li></ul></div></div></div></div>

<div class="col-md-4 animated fadeInUp">
<div class="portlet light portlet-fit portlet-form bordered" id="form_wizard_1">
<div class="portlet-title"><div class="caption"><i class="fa fa-user font-blue"></i>
<span class="caption-subject font-dark sbold uppercase">Состав</span>
</div></div><div class="portlet-body"><div class="form-body">
<table class="table table-light"><thead></thead><tbody>
<?
$f1 = $mysqli->query('SELECT * FROM users WHERE id="1"')->fetch_array();
$json = curl('users.get?name_case=Nom&https=1&fields=status,photo_max&uid='.$f1['profile']);
echo '<tr><td class="fit"><img class="user-pic img-circle" src="'.$json[0]['photo_max'].'"></td><td>
<a href="https://vk.com/id'.$json[0]['uid'].'" class="primary-link">'.$json[0]['first_name'].' '.$json[0]['last_name'].'</a></td><td>Разработчик</td></tr>';

/*$f2 = $mysqli->query('SELECT * FROM users WHERE id="2"')->fetch_array();
$json = curl('users.get?name_case=Nom&https=1&fields=status,photo_max&uid='.$f2['profile']);
echo '<tr><td class="fit"><img class="user-pic img-circle" src="'.$json[0]['photo_max'].'"></td><td>
<a href="https://vk.com/id'.$json[0]['uid'].'" class="primary-link">'.$json[0]['first_name'].' '.$json[0]['last_name'].'</a></td><td>Братка</td></tr>';
*/?> </tbody></table></div></div></div></div>

<div class="col-md-4 animated fadeInUp">
<div class="portlet light portlet-fit portlet-form bordered" id="form_wizard_1">
<div class="portlet-title"><div class="caption"><i class="fa fa-info font-blue"></i>
<span class="caption-subject font-dark sbold uppercase">Информация</span>
</div></div><div class="portlet-body"><div class="form-body">
<li class="list-group-item">Гостей<span class="badge badge-warning"><?=$stats->visits;?></span></li>
<li class="list-group-item">Всего автоустановок<span class="badge badge-success"><?=$stats->allsets;?></span></li>
<li class="list-group-item">Пользователей<span class="badge badge-info"><?=$stats->users;?></span></li>
<li class="list-group-item">Uptime<span class="badge badge-primary"><?=$stats->denials;?>%</span></li></div></div></div></div>
