<? session_start();
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
$who = $mysqli->query('SELECT `who` FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"')->fetch_array()['who'];
if($who < 3 || !$_GET || !isset($_SESSION['uid'])){ header("Location: /"); }

if(isset($_GET['system'])){
if($who < 5){ header("Location: /"); }
$menu['sys'] = 'active animated fadeIn';
$title = $site['Name'].' • Системная Панель';
include($_SERVER['DOCUMENT_ROOT'].'/data/head.php');
$infoFetch = $mysqli->query('SELECT * from `site`')->fetch_array();
if($infoFetch['theme'] == '1') { $themeSel = '<option value="1" selected="">Тема • Стандарт</option><option value="2">Тема • Тёмная</option><option value="3">Тема • Синяя</option><option value="4">Тема • Грей</option><option value="5">Тема • Светлая</option><option value="6">Тема • Светлая (2)</option>'; }
if($infoFetch['theme'] == '2') { $themeSel = '<option value="2" selected="">Тема • Тёмная</option><option value="1">Тема • Стандарт</option><option value="3">Тема • Синяя</option><option value="4">Тема • Грей</option><option value="5">Тема • Светлая</option><option value="6">Тема • Светлая (2)</option>'; }
if($infoFetch['theme'] == '3') { $themeSel = '<option value="3" selected="">Тема • Синяя</option><option value="1">Тема • Стандарт</option><option value="2">Тема • Тёмная</option><option value="4">Тема • Грей</option><option value="5">Тема • Светлая</option><option value="6">Тема • Светлая (2)</option>'; }
if($infoFetch['theme'] == '4') { $themeSel = '<option value="4" selected="">Тема • Грей</option><option value="1">Тема • Стандарт</option><option value="2">Тема • Тёмная</option><option value="3">Тема • Синяя</option><option value="5">Тема • Светлая</option><option value="6">Тема • Светлая (2)</option>'; }
if($infoFetch['theme'] == '5') { $themeSel = '<option value="5" selected="">Тема • Светлая</option><option value="1">Тема • Стандарт</option><option value="2">Тема • Тёмная</option><option value="3">Тема • Синяя</option><option value="4">Тема • Грей</option><option value="6">Тема • Светлая (2)</option>'; }
if($infoFetch['theme'] == '6') { $themeSel = '<option value="6" selected="">Тема • Светлая (2)</option><option value="1">Тема • Стандарт</option><option value="2">Тема • Тёмная</option><option value="3">Тема • Синяя</option><option value="4">Тема • Грей</option><option value="5">Тема • Светлая</option>'; }
if($infoFetch['preloader']== 2){ $preload = '<option value="2" selected="">Включен</option> <option value="1">Выключен</option>'; } else { $preload = '<option value="1" selected="">Выключен</option> <option value="2">Включен</option>'; } ?>

<div class="col-md-12">
<div class="portlet light portlet-fit portlet-form bordered">
<div class="portlet-body"><div class="form-body"><center>
<a class="btn btn-success waves-effect" aria-expanded="true" href="#system" data-toggle="tab">Система</a>
<a class="btn btn-success waves-effect" aria-expanded="false" href="#cloudflare" data-toggle="tab">CloudFlare</a>
</center></div></div></div></div>

<div class="tab-content">
<div class="tab-pane active" id="system">
	<div id="info"></div>
	<div class="col-md-6 animated fadeIn">
	<div class="portlet light portlet-fit portlet-form bordered">
	<div class="portlet-title"><div class="caption"><i class="fa fa-cog font-blue"></i>
	<span class="caption-subject font-dark sbold uppercase">Системные настройки</span>
	</div></div><div class="portlet-body"><div class="form-body">
	<div class="form-group form-md-line-input form-md-floating-label has-success">
	<input type="text" class="form-control input-md" name="site_name" id="site_name" value="<?=$infoFetch['Name'];?>">
	<label for="form_control_1">Название сайта</label></div>
	<div class="form-group form-md-line-input form-md-floating-label has-info">
	<input type="text" class="form-control input-md" id="tags" value="<?=$infoFetch['tags'];?>">
	<label for="form_control_1">Теги</label></div>
	<div class="form-group form-md-line-input form-md-floating-label has-info">
	<input type="text" class="form-control input-md" id="desc" value="<?=$infoFetch['desc'];?>">
	<label for="form_control_1">Описание</label>
	</div><div class="form-group form-md-line-input form-md-floating-label has-warning">
	<input type="text" class="form-control input-md" name="wal" id="wal" value="<?=$infoFetch['wAverLoad'];?>" >
	<label for="form_control_1">Превышенный Load Average</label></div>
	<div class="form-group form-md-line-input form-md-floating-label has-error">
	<input type="text" class="form-control input-md" name="mal" id="mal" value="<?=$infoFetch['mAverLoad'];?>" >
	<label for="form_control_1">Максимальный LoadAverage</label></div>
	<button class="btn btn-minw btn-square btn-primary waves-effect" onclick="goMain()">Сохранить</button>
	</div></div></div></div>

	<div class="col-md-6 animated fadeIn">
	<div class="portlet light portlet-fit portlet-form bordered">
	<div class="portlet-title"><div class="caption"><i class="fa fa-tv font-blue"></i>
	<span class="caption-subject font-dark sbold uppercase">Оформление</span>
	</div></div><div class="portlet-body"><div class="form-body">
	<div class="form-group form-md-line-input form-md-floating-label has-info">
	<select class="form-control edited" id="preloaderSite" name="preloaderSite"><?=$preload;?></select>
	<label for="form_control_1">Preloader</label></div>
	<div class="form-group form-md-line-input form-md-floating-label has-info">
	<select class="form-control edited" id="themeSite" name="themeSite"><?=$themeSel;?></select>
	<label for="form_control_1">Тема</label></div><button class="btn btn-minw btn-square btn-primary waves-effect" onclick="goTheme()">Сохранить</button>
	</div></div></div></div>

	<div class="col-md-6 animated fadeIn">
	<div class="portlet light portlet-fit portlet-form bordered">
	<div class="portlet-title"><div class="caption"><i class="fa fa-tag font-blue"></i>
	<span class="caption-subject font-dark sbold uppercase">Остальное</span>
	</div></div><div class="portlet-body"><div class="form-body">
	<div class="form-group form-md-line-input form-md-floating-label has-success">
	<input type="text" class="form-control input-md" name="yaID" id="yaID" value="<?=$site['metrica_id'];?>">
	<label for="form_control_1">Yandex: ID Бара</label></div>
	<div class="form-group form-md-line-input form-md-floating-label has-success">
	<input type="text" class="form-control input-md" name="yaToken" id="yaToken" value="<?=$site['metrica_token'];?>">
	<label for="form_control_1">Yandex: Токен</label></div>
	<button class="btn btn-minw btn-square btn-primary waves-effect" onclick="goOther()">Сохранить</button>
	</div></div></div></div>
	<input type="hidden" id="goMain" name="goMain"><input type="hidden" id="goTheme" name="goTheme"><input type="hidden" id="goOther" name="goOther">
</div>

<div class="tab-pane" id="cloudflare">
	<?
		$ujson = $global->cloudflare('GET', 'https://api.cloudflare.com/client/v4/user');
		$json = $global->cloudflare('GET', 'https://api.cloudflare.com/client/v4/zones?name='.$_SERVER['HTTP_HOST']);
		$getsec = $global->cloudflare('GET', 'https://api.cloudflare.com/client/v4/zones/'.$json['result']['0']['id'].'/settings/security_level');
		$seclvl = $getsec['result']['value'];
		if($seclvl == 'essentially_off') { $cflvl = '<option value="essentially_off" selected="">Фактически выключено</option><option value="low">Низкий уровень защиты</option><option value="medium" >Средний уровень защиты</option><option value="high">Высокий уровень защиты</option><option value="under_attack">Заглушка</option>'; }
		if($seclvl == 'low') { $cflvl = '<option value="essentially_off">Фактически выключено</option><option value="low" selected="">Низкий уровень защиты</option><option value="medium" >Средний уровень защиты</option><option value="high">Высокий уровень защиты</option><option value="under_attack">Заглушка</option>'; }
		if($seclvl == 'medium') { $cflvl =  '<option value="essentially_off">Фактически выключено</option><option value="low">Низкий уровень защиты</option><option value="medium" selected="">Средний уровень защиты</option><option value="high">Высокий уровень защиты</option><option value="under_attack">Заглушка</option>'; }
		if($seclvl == 'high') { $cflvl = '<option value="essentially_off">Фактически выключено</option><option value="low">Низкий уровень защиты</option><option value="medium" >Средний уровень защиты</option><option value="high" selected="">Высокий уровень защиты</option><option value="under_attack">Заглушка</option>'; }
		if($seclvl == 'under_attack') { $cflvl = '<option value="essentially_off">Фактически выключено</option><option value="low">Низкий уровень защиты</option><option value="medium" >Средний уровень защиты</option><option value="high">Высокий уровень защиты</option><option value="under_attack" selected="">Заглушка</option>'; }
		if($json['result']['0']['paused'] == true) { $sitestatus = 'paused'; } else { $sitestatus = $json['result']['0']['status']; }
	?>

	<div id="cfInfo"></div>
	<div class="col-md-12 animated fadeIn">
	<div class="portlet light portlet-fit portlet-form bordered">
	<div class="portlet-title"><div class="caption"><i class="fa fa-cloud font-blue"></i>
	<span class="caption-subject font-dark sbold uppercase">CloudFlare</span>
	</div></div><div class="portlet-body"><div class="form-body">
	<div class="form-group form-md-line-input form-md-floating-label has-info">
	<input type="text" class="form-control input-md" disabled value="<?=$ujson['result']['email'];?>">
	<label for="form_control_1">Почта </label></div>
	<div class="form-group form-md-line-input form-md-floating-label has-primary">
	<input type="text" class="form-control input-md" disabled value="<?=$json['result']['0']['name'];?>">
	<label for="form_control_1">Домен сайта </label></div>
	<div class="form-group form-md-line-input form-md-floating-label has-primary">
	<input type="text" class="form-control input-md" disabled value="<?=$sitestatus;?>">
	<label for="form_control_1">Статус сайта </label></div>

	<div class="form-group form-md-line-input form-md-floating-label has-primary">
	<input type="text" class="form-control input-md" disabled value="<?=$json['result']['0']['plan']['name'];?>">
	<label for="form_control_1">Тарифный план </label></div>

	<center><h4>Настройки</h4></center>
	<?
	if($json['result']['0']['paused'] == true) {
		$sitestatus = '<option value="worked">Работает</option><option value="paused" selected="">Остановлен</option>';
	} else { $sitestatus = '<option value="worked" selected="">Работает</option><option value="paused">Остановлен</option>'; }
	?>

	<div class="form-group form-md-line-input form-md-floating-label has-error">
	<select class="form-control edited" id="cfSiteStatus" name="cfSecurityLVL"><?=$sitestatus;?></select>
	<label for="form_control_1">Статус сайта</label></div>

	<div class="form-group form-md-line-input form-md-floating-label has-error">
	<select class="form-control edited" id="cfSecurityLVL" name="cfSecurityLVL"><?=$cflvl;?></select>
	<label for="form_control_1">Уровень защиты</label></div>

	<button class="btn btn-minw btn-square btn-primary waves-effect" onclick="cfSave()">Сохранить</button>
	<button class="btn btn-minw btn-square btn-success waves-effect" onclick="cfPurge()">Очистить кеш</button>

	</div></div></div>
	<input type="hidden" id="cfMainSettings" name="cfMainSettings"><input type="hidden" id="cfPurgeCache" name="cfPurgeCache">
	</div>

</div>

<script>
function cfPurge() {
	var cfPurgeCache = $('#cfPurgeCache')['val']();
    $['ajax']({
	beforeSend: function() { $('#cfInfo').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
     type: 'POST',
     url: '/data/api.php',
     data: ({ cfPurgeCache: $("#cfPurgeCache").val() }),
     success: function (data) { $('#cfInfo').html (data + ""); $('#cfInfo').show (); },
			error: function (data) {
			toastr.options = {
			closeButton: false,
			showMethod: "fadeIn",
			positionClass: "toast-bottom-right",
			timeOut: 2000 };
			toastr.clear(); toastr.warning("Сервер недоступен", "Внимание");
			} });
}

function cfSave() {
	var cfMainSettings = $('#cfMainSettings')['val']();
	var cfSecurityLVL = $('#cfSecurityLVL')['val']();
	var cfSiteStatus = $('#cfSiteStatus')['val']();
    $['ajax']({
	beforeSend: function() { $('#cfInfo').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
     type: 'POST',
     url: '/data/api.php',
     data: ({ cfMainSettings: $("#cfMainSettings").val(), cfSiteStatus: $("#cfSiteStatus").val(), cfSecurityLVL: $("#cfSecurityLVL").val() }),
     success: function (data) { $('#cfInfo').html (data + ""); $('#cfInfo').show (); },
			error: function (data) {
			toastr.options = {
			closeButton: false,
			showMethod: "fadeIn",
			positionClass: "toast-bottom-right",
			timeOut: 2000 };
			toastr.clear(); toastr.warning("Сервер недоступен", "Внимание");
			} });
}

function goMain() {
	var goMain = $('#goMain')['val'](); var site_name = $('#site_name')['val']();
	var tags = $('#tags')['val'](); var desc = $('#desc')['val']();
	var mal = $('#mal')['val'](); var wal = $('#wal')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
     type: 'POST',
     url: '/data/api.php',
     data: ({ goMain: $("#goMain").val(), site_name: $("#site_name").val(),
     tags: $("#tags").val(), desc: $("#desc").val(),
	 mal: $("#mal").val(), wal: $("#wal").val() }),
	 success: function (data) { $('#info').html (data + ""); $('#info').show (); },
			error: function (data) {
			toastr.options = {
			closeButton: false,
			showMethod: "fadeIn",
			positionClass: "toast-bottom-right",
			timeOut: 2000 };
			toastr.clear(); toastr.warning("Сервер недоступен", "Внимание");
			} });
}
function goTheme() {
	var goTheme = $('#goTheme')['val']();
	var themeSite = $('#themeSite')['val']();
	var preloaderSite = $('#preloaderSite')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
     type: 'POST',
     url: '/data/api.php',
     data: ({ goTheme: $("#goTheme").val(), themeSite: $("#themeSite").val(),  preloaderSite: $("#preloaderSite").val() }),
     success: function (data) { $('#info').html (data + ""); $('#info').show (); },
			error: function (data) {
			toastr.options = {
			closeButton: false,
			showMethod: "fadeIn",
			positionClass: "toast-bottom-right",
			timeOut: 2000 };
			toastr.clear(); toastr.warning("Сервер недоступен", "Внимание");
			} });
}
function goOther() {
	var goOther = $('#goOther')['val']();
	var yaID = $('#yaID')['val']();
	var yaToken = $('#yaToken')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
     type: 'POST',
     url: '/data/api.php',
     data: ({ goOther: $("#goOther").val(), yaID: $("#yaID").val(), yaToken: $("#yaToken").val() }),
     success: function (data) { $('#info').html (data + ""); $('#info').show (); },
			error: function (data) {
			toastr.options = {
			closeButton: false,
			showMethod: "fadeIn",
			positionClass: "toast-bottom-right",
			timeOut: 2000 };
			toastr.clear(); toastr.warning("Сервер недоступен", "Внимание");
			} });
}
</script>

<? }
if(isset($_GET['users']) && isset($_GET['page'])){
	if($who < 4) { header("Location: /"); }
	$menu['usr'] = 'active animated fadeIn';
	$title = $site['Name'].' • Редактирование Пользователей';
	include($_SERVER['DOCUMENT_ROOT'].'/data/head.php');
?>

<div class="col-md-12 animated fadeIn">
<div class="portlet light portlet-fit portlet-form bordered">
<div class="portlet-title"><div class="caption"><i class="fa fa-users font-blue"></i>
<span class="caption-subject font-dark sbold uppercase">Редактирование пользователей</span>
</div></div><div class="portlet-body"><div class="form-body"><div class="tab-pane active">

<script>
function userscan() {
	var userscan = $('#userscan')['val']();
	var scanid = $('#scanid')['val']();
    $['ajax']({
        type: 'POST',
        url: '/data/api.php',
        data: ({
		beforeSend: function() { $('#info').html('<div class="animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
		userscan: $("#userscan").val(),
		scanid: $("#scanid").val(),
		}),
			success: function (data) {
				setTimeout("gocap()", 1);
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				toastr.options = {
				closeButton: false,
				progressBar: true,
				showMethod: "fadeIn",
				positionClass: "toast-bottom-right",
				timeOut: 2000 }; toastr.clear();
				toastr.warning("Сервер недоступен", "Внимание");
			}
    });
}
</script>

<div class="form-group form-md-line-input has-info form-md-floating-label">
<div class="input-group"><div class="input-group-control">
<input type="text" class="form-control" name="scanid" id="scanid">
<label for="form_control_1">Поиск по ID пользователя</label></div>
<span class="input-group-btn btn-right">
<input type="hidden" id="userscan" name="userscan" value="userscan">
<button type="button" class="btn btn-minw btn btn-circle btn-square btn-info" name="submit" id="submit" value="submit" onclick="userscan()">Найти</button></span>
</div></div>

<div class="mt-element-card mt-element-overlay" id="info" name="info">
<div class="row">
<?
$page = $_GET['page'];
$max = 16; // Кол-во записей на одной странице
$firstget = $mysqli->query('SELECT * FROM `users` ORDER BY id DESC');
$secondget = $mysqli->query('SELECT * FROM `users` ORDER BY `id` DESC LIMIT '.$max.' OFFSET '.($page - 1) * $max);
$rows = $firstget->fetch_row(); $num_pages = ceil($rows[0] / $max);

if($page > $num_pages) { echo '<div class="col-md-12"><div class="alert alert-danger alert-dismissable">Такой страницы не существует</div></div>'; }
while($row = $secondget->fetch_array()) {
if($row['who'] == 0){ $statusUser = '<span class="text-danger">Заблокирован</span>'; }
if($row['who'] == 5){ $statusUser = '<span class="text-danger">Разработчик</span>'; }
if($row['who'] == 4){ $statusUser = '<span class="text-warning">Администратор</span>'; }
if($row['who'] == 3){ $statusUser = '<span class="text-info">Редактор</span>'; }
if($row['who'] == 2){ $statusUser = '<span class="text-success">Агент Поддержки</span>'; }
if($row['who'] == 1){ $statusUser = 'Пользователь'; }

echo '<div class="col-md-3"><div class="panel">
<div class="panel-body"><div class="mt-overlay-3 mt-overlay-3-icons">
<img src="'.$row['photo'].'"><div class="mt-overlay"><h2>'.$row['first_name'].' '.$row['last_name'].' • ID'.$row['id'].'<br> '.$statusUser.'</h2><ul class="mt-info">
<li><a class="btn red btn-circle" href="/id'.$row['id'].'#getEdit"><i class="fa fa-cog"></i></a></li>
<li><a class="btn green btn-circle" href="/id'.$row['id'].'#getPush"><i class="fa fa-paper-plane-o"></i></a></li>
<li><a class="btn blue btn-circle" href="/id'.$row['id'].'"><i class="fa fa-user"></i></a></li></ul></div></div></div></div></div>'; }
?> </div></div></div></div></div></tbody></table></div></div>

<? # Выводим количество страниц
echo '<div class="col-md-12 animated fadeIn">
<div class="portlet light portlet-fit portlet-form bordered">
<div class="portlet-body"><div class="form-body"><center>';
for($i=1;$i<=$num_pages;$i++) {
  if($i != $page){
	echo '<a href="/data/admin.php?users&page='.$i.'" class="btn btn-danger btn-circle waves-effect">'.$i.'</a>';
	} else {
	echo '<a href="/data/admin.php?users&page='.$i.'" class="btn btn-danger btn-circle disabled">'.$i.'</a>';
  }
} echo '</center></div></div></div></div>'; }

if(isset($_GET['statistics'])){
 if($who < 4){ header("Location: /"); }
	$menu['stas'] = 'active animated fadeIn';
	$title = $site['Name'].' • Статистика';
	$Metrica = json_decode(file_get_contents('https://api-metrika.yandex.ru/stat/traffic/summary.json?id='.$metrica_id.'&oauth_token='.$metrica_token.'&date1='.date('Ymd', strtotime('-8 days')).'&date2='.date('Ymd')));
	$rows = $Metrica->rows; $go = $rows - 1;
	for($i = $go; $i >= 0; $i--) {
		$Visits[$i] = $Metrica->data[$i]->visits.'';
		$pViews[$i] = $Metrica->data[$i]->page_views.'';
		$Denial[$i] = $Metrica->data[$i]->denial.'';
		$Depth[$i] = $Metrica->data[$i]->depth.'';
	} include($_SERVER['DOCUMENT_ROOT'].'/data/head.php');
?>

<link rel="stylesheet" href="//cdn.jsdelivr.net/chartist.js/latest/chartist.min.css">
<script src="//cdn.jsdelivr.net/chartist.js/latest/chartist.min.js"></script>

<style>
#fullChart .ct-series-a .ct-line {
  stroke-width: 0px;
} #fullChart .ct-series-a .ct-area {
  fill: rgba(41, 78, 156, 0.61);
  fill-opacity: 1;
}

#fullChart .ct-series-b .ct-line {
  stroke-width: 0px;
} #fullChart .ct-series-b .ct-point {
  stroke-width: 0px;
} #fullChart .ct-series-b .ct-area {
  fill: #3872b9;
}

#fullChart .ct-series-c .ct-line {
  stroke-width: 0px;
} #fullChart .ct-series-c .ct-point {
  stroke-width: 1px;
} #fullChart .ct-series-c .ct-area {
  fill: #d34947;
  fill-opacity: 0.1;
}

#fullChart .ct-grid {
  stroke: rgba(0, 0, 0, 0.06);
  stroke-width: 1px;
  stroke-dasharray: 0;
}
</style>

<div class="col-md-12">
<div class="portlet light portlet-fit portlet-form bordered">
<div class="portlet-body"><div class="form-body"><center>
<a class="btn waves-effect" style="color: #7c93c3;">Глубина</a>
<a class="btn waves-effect" style="color: #3872b9;">Визиты</a>
<a class="btn waves-effect" style="color: #d34947;">Отказы</a>
</center></div></div></div></div>

<div class="col-md-12">
<div class="portlet light portlet-fit portlet-form bordered">
<div class="portlet-title"><div class="caption"><i class="fa fa-bar-chart-o font-blue"></i>
<span class="caption-subject font-dark sbold uppercase">Статистика посещений</span>
</div></div><div class="portlet-body"><div class="form-body">
<div id="fullChart" style="height: 400px" class="centered"></div>
<script>
jQuery(document).ready(function() {
    var options = {
		low: 0, showArea: true, showPoint: false, fullWidth: true,
        axisY: { labelInterpolationFnc: function(value) {return value;}, scaleMinSpace: 100 }
	};
	var data = {
        labels: [<?='"'.date('d.m', strtotime('-7 days')).'", "'.date('d.m', strtotime('-6 days')).'", "'.date('d.m', strtotime('-5 days')).'", "'.date('d.m', strtotime('-4 days')).'", "'.date('d.m', strtotime('-3 days')).'", "'.date('d.m', strtotime('-2 days')).'", "'.date('d.m', strtotime('-1 days')).'", "'.date('d.m').'"'?>],
        series: [
		{name: 'se1', data: [<?=$Depth[$go-7]; ?>,<?=$Depth[$go-6]; ?>,<?=$Depth[$go-5]; ?>,<?=$Depth[$go-4]; ?>,<?=$Depth[$go-3]; ?>,<?=$Depth[$go-2]; ?>,<?=$Depth[$go-1]; ?>,<?=$Depth[$go]; ?>]},
		{name: 'se2', data: [<?=$Visits[$go-7]; ?>,<?=$Visits[$go-6]; ?>,<?=$Visits[$go-5]; ?>,<?=$Visits[$go-4]; ?>,<?=$Visits[$go-3]; ?>,<?=$Visits[$go-2]; ?>,<?=$Visits[$go-1]; ?>,<?=$Visits[$go]; ?>]},
		{name: 'se3', data: [<?=$Denial[$go-7]; ?>,<?=$Denial[$go-6]; ?>,<?=$Denial[$go-5]; ?>,<?=$Denial[$go-4]; ?>,<?=$Denial[$go-3]; ?>,<?=$Denial[$go-2]; ?>,<?=$Denial[$go-1]; ?>,<?=$Denial[$go]; ?>]}
	]}; new Chartist.Line("#fullChart", data, options);
});</script></div></div></div></div>


<div class="col-md-6">
<div class="portlet light portlet-fit portlet-form bordered">
<div class="portlet-title"><div class="caption">
<span class="caption-subject font-dark sbold uppercase">Информация о работоспособности сайта</span>
<? $work_time = $mysqli->query('SELECT * FROM work_time')->fetch_array(); ?>
</div></div><div class="portlet-body"><div class="form-body">

<div class="form-group form-md-line-input form-md-floating-label has-primary">
<input type="text" class="form-control input-md edited" value="<?=$work_time['load_site'];?> сек." disabled>
<label>Среднее время загрузки сайта</label></div>

<div class="form-group form-md-line-input form-md-floating-label has-success">
<input type="text" class="form-control input-md edited" value="<?=$work_time['status'];?> сек." disabled>
<label>Среднее время работы Авто Статусов</label></div>

<div class="form-group form-md-line-input form-md-floating-label has-info">
<input type="text" class="form-control input-md edited" value="<?=$work_time['userfunc'];?> сек." disabled>
<label>Среднее время работы Функций для Профиля</label></div>

<div class="form-group form-md-line-input form-md-floating-label has-warning">
<input type="text" class="form-control input-md edited" value="<?=$work_time['online'];?> сек." disabled>
<label>Среднее время работы Вечного Онлайна</label></div>

<div class="form-group form-md-line-input form-md-floating-label has-error">
<input type="text" class="form-control input-md edited" value="<?=$work_time['status_group'];?> сек." disabled>
<label>Среднее время работы АвтоСтатуса для Группы</label></div>

<div class="form-group form-md-line-input form-md-floating-label has-info">
<input type="text" class="form-control input-md edited" value="<?=$work_time['liker'];?> сек." disabled>
<label>Среднее время работы Лайкера</label></div>
</div></div></div></div>

<div class="col-md-6">
<div class="portlet light portlet-fit portlet-form bordered">
<div class="portlet-title"><div class="caption">
<span class="caption-subject font-dark sbold uppercase">Статистика отказов</span>
</div></div><div class="portlet-body"><div class="form-body">
<div id="denials" style="height: 400px" class="centered"></div>

<style>
#denials .ct-series-a .ct-line { stroke-width: 0px; }
#denials .ct-series-a .ct-point { stroke-width: 1px; }
#denials .ct-series-a .ct-area { fill: #d34947; fill-opacity: 0.4; }
</style>

<script>
jQuery(document).ready(function() {
    var options = {
	high: <?=number_format($Denial[$go]+$Denial[$go-1]+$Denial[$go-2]+$Denial[$go-3]+$Denial[$go-4]+$Denial[$go-5]+$Denial[$go-6]+$Denial[$go-7] / 8 + 2, 1);?>,
		low: 0, showArea: true, showPoint: false, fullWidth: true,
        axisY: { labelInterpolationFnc: function(value) {return value;}, scaleMinSpace: 100 }
	};
	var data = {
        labels: [<?='"'.date('d.m', strtotime('-7 days')).'", "'.date('d.m', strtotime('-6 days')).'", "'.date('d.m', strtotime('-5 days')).'", "'.date('d.m', strtotime('-4 days')).'", "'.date('d.m', strtotime('-3 days')).'", "'.date('d.m', strtotime('-2 days')).'", "'.date('d.m', strtotime('-1 days')).'", "'.date('d.m').'"'?>],
        series: [
		{name: 'se1', data: [<?=$Denial[$go-7]; ?>,<?=$Denial[$go-6]; ?>,<?=$Denial[$go-5]; ?>,<?=$Denial[$go-4]; ?>,<?=$Denial[$go-3]; ?>,<?=$Denial[$go-2]; ?>,<?=$Denial[$go-1]; ?>,<?=$Denial[$go]; ?>]},
	]}; new Chartist.Line("#denials", data, options);
});
</script>
</div></div></div></div><? } ?>

<? include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>

<? /* кодел Flazzer */ ?>