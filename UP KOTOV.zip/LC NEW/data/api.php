<? session_start();
if(!$_POST){ echo '{"response":null}'; }

/* flood_control */
flood_control();
/* flood_control */

include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');

/* Admin Checker */
$admget = $mysqli->query('SELECT `who` FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"')->fetch_array();
if($admget['who'] == 1){ $err->user = 'Вы не имеете полномочий на администрирование!';
} else { $err->user = 'Ваш аккаунт не имеет полномочий на отправку этого запроса! Ваш уровень администрирования: '.$admget['admin'].''; }
$err->notadmin = alert('danger', $err->user);
/* Admin Checker */

/* CloudFlare Get ZoneID */
$getzone = cloudflare('GET', 'https://api.cloudflare.com/client/v4/zones?name='.$_SERVER['HTTP_HOST']);
$zoneid = $getzone['result']['0']['id'];
/* CloudFlare Get ZoneID */

if(isset($_POST['StatusSet']) && isset($_SESSION['uid'])){
	$secpic = htmlspecialchars($_POST['captcha']);
	$city = htmlspecialchars($_POST['city']);
	$statusID = htmlspecialchars($_POST['statusID']);
	$token = htmlspecialchars($_POST['token']);
	if($statusID > 11 || $statusID < 1 || !strpos($city,'/')){ die(alert('danger', 'Ошибка в запросе')); }
	if($_SESSION['secpic'] != $secpic){ die(alert('warning', '<i class="fa fa-exclamation-triangle"></i>&nbsp; <strong>Воу!</strong> Подтвердите что Вы не робот!')); }

	$json = curl('account.setOnline?access_token='.$token);
	if($json['error']['error_code']) { die(alert('danger', '<i class="fa fa-close"></i>&nbsp; Ваш «ACCESS_TOKEN» не рабочий! Код ошибки: '.$json['error']['error_code'].' / '.$json['error']['error_msg'].'')); }
	if($json['response'] == true){ $json = curl('users.get?name_case=Nom&fields=photo_big&access_token='.$token);
	$get = $mysqli->query('SELECT * FROM status WHERE `user_id`="'.$json['response']['0']['uid'].'"')->fetch_row();
	if($get == 0){ $mysqli->query('INSERT INTO `status` (`user_id`, `token`, `city`, `status_id`) VALUES("'.$json['response']['0']['uid'].'", "'.$token.'", "'.$city.'", "'.$statusID.'")');
	echo '<div class="col-md-12 animated fadeInUp"><div class="alert alert-success alert-dismissable">
	<img src="'.$json['response']['0']['photo_big'].'" style="height: 50px; wight: 50px; border-radius:1337px;float:left;margin-right:10px;">
	<h4>'.$json['response']['0']['first_name'].' '.$json['response']['0']['last_name'].'</h4><p>Аккаунт добавлен в базу данных <img src="https://vk.com/images/emoji/D83DDE3C.png"></p></div></div>';
	} else { echo alert('warning', 'Аккаунт уже находится в базе'); } }
}

# Next

if(isset($_POST['StatusDel']) && isset($_SESSION['uid'])){
	$secpic = htmlspecialchars($_POST['captcha']);
	$token = htmlspecialchars($_POST['token']);
	if($_SESSION['secpic'] != $secpic){ die(alert('warning', '<i class="fa fa-exclamation-triangle"></i>&nbsp; <strong>Воу!</strong> Подтвердите что Вы не робот!')); }
	$json = curl('account.setOnline?access_token='.$token);
	if($json['error']['error_code']) { die(alert('danger', '<i class="fa fa-close"></i>&nbsp; Ваш «ACCESS_TOKEN» не рабочий! Код ошибки: '.$json['error']['error_code'].' / '.$json['error']['error_msg'].'')); }
	if($json['response'] == true){
	$json = curl('users.get?name_case=Nom&fields=uid,photo_big&access_token='.$token);
	$num = $mysqli->query('SELECT * FROM `status` WHERE `user_id`="'.$json['response']['0']['uid'].'"')->fetch_row();
	if($num == 0) { die('<div class="col-md-12"><div class="alert alert-dismissable alert-danger">Вашего аккаунта нет в базе данных</div></div>'); } else {
	$mysqli->query('DELETE FROM `status` WHERE `user_id`="'.$json['response']['0']['uid'].'"');
	echo '<div class="col-md-12 animated fadeInUp"><div class="alert alert-success alert-dismissable">
	<img src="'.$json['response']['0']['photo_big'].'" style="height: 50px; wight: 50px; border-radius:1337px;float:left;margin-right:10px;">
	<h4>'.$json['response']['0']['first_name'].' '.$json['response']['0']['last_name'].'</h4><p>Прощай, ты нам был как бро <img src="https://new.vk.com/images/emoji/D83DDE25.png"></p></div></div>'; } }
}

# Next

if(isset($_POST['StatusEdit']) && isset($_SESSION['uid'])){
	$token = htmlspecialchars($_POST['tokenE']);
	$numST = htmlspecialchars($_POST['num']);
	$secpic = htmlspecialchars($_POST['captcha1']);
	if($numST > 11){ echo alert('danger', 'Ошибка в запросе'); break; }
	if($numST < 1){ echo alert('danger', 'Ошибка в запросе'); break; }
	if($_SESSION['secpic'] != $secpic){ die(alert('warning', '<i class="fa fa-exclamation-triangle"></i>&nbsp; <strong>Воу!</strong> Подтвердите что Вы не робот!')); }
	$json = curl('account.setOnline?access_token='.$token);
	if($json['error']['error_code']) { die(alert('danger', '<i class="fa fa-close"></i>&nbsp; Ваш «ACCESS_TOKEN» не рабочий! Код ошибки: '.$json['error']['error_code'].' / '.$json['error']['error_msg'].'')); }
	if($json['response'] == true){
	$json = curl('users.get?name_case=Nom&fields=uid,photo_big&access_token='.$token);
	$num = $mysqli->query('SELECT * FROM `status` WHERE `user_id`="'.$json['response']['0']['uid'].'"')->fetch_row();
	if($num == 0) { die(alert('danger', 'Аккаунт не найден')); } else {
	$mysqli->query('UPDATE `status` SET `status_id`="'.$numST.'" WHERE `user_id`="'.$json['response']['0']['uid'].'"');
	echo '<div class="col-md-12 animated fadeInUp"><div class="alert alert-success alert-dismissable">
	<img src="'.$json['response']['0']['photo_big'].'" style="height: 50px; wight: 50px; border-radius:1337px;float:left;margin-right:10px;">
	<h4>'.$json['response']['0']['first_name'].' '.$json['response']['0']['last_name'].'</h4><p>Мы поменяли тебе статус на #'.$numST.' <img src="https://vk.com/images/emoji/D83DDE3C.png"></p></div></div>'; } }
}

# Next

if(isset($_POST['likerSet']) && isset($_SESSION['uid'])){
	$token = htmlspecialchars($_POST['token']);
	$secpic = htmlspecialchars($_POST['captcha']);
	if($_SESSION['secpic'] != $secpic){ die(alert('warning', '<i class="fa fa-exclamation-triangle"></i>&nbsp; <strong>Воу!</strong> Подтвердите что Вы не робот!')); }
	$json = curl('account.setOnline?access_token='.$token);
	if($json['error']['error_code']) { die(alert('danger', '<i class="fa fa-close"></i>&nbsp; Ваш «ACCESS_TOKEN» не рабочий! Код ошибки: '.$json['error']['error_code'].' / '.$json['error']['error_msg'].'')); }
	if($json['response'] == true){
	$json = curl('users.get?name_case=Nom&fields=uid,photo_big&access_token='.$token);
	$num = $mysqli->query('SELECT * FROM `liker` WHERE `user_id`="'.$json['response']['0']['uid'].'"')->fetch_row();
	if($num != 0) { die('<div class="col-md-12"><div class="alert alert-dismissable alert-danger">К сожалению мы не позволяем добавить на один аккаунт больше одной группы!</div></div>'); } else {
	$mysqli->query('INSERT INTO liker (`user_id`, `token`) VALUES("'.$json['response']['0']['uid'].'", "'.$token.'")');
	echo '<div class="col-md-12 animated fadeInUp"><div class="alert alert-success alert-dismissable">
	<img src="'.$json['response']['0']['photo_big'].'" style="height: 50px; wight: 50px; border-radius:1337px;float:left;margin-right:10px;">
	<h4>'.$json['response']['0']['first_name'].' '.$json['response']['0']['last_name'].'</h4><p>Аккаунт успешно добавлен в базу данных</p></div></div>'; } }
}

# Next

if(isset($_POST['likerDel']) && isset($_SESSION['uid'])){
	$secpic = htmlspecialchars($_POST['captcha1']);
	$token = htmlspecialchars($_POST['tokenE']);
	if($_SESSION['secpic'] != $secpic){ die(alert('warning', '<i class="fa fa-exclamation-triangle"></i>&nbsp; <strong>Воу!</strong> Подтвердите что Вы не робот!')); }
	$json = curl('account.setOnline?access_token='.$token);
	if($json['error']['error_code']) { die(alert('danger', '<i class="fa fa-close"></i>&nbsp; Ваш «ACCESS_TOKEN» не рабочий! Код ошибки: '.$json['error']['error_code'].' / '.$json['error']['error_msg'].'')); }
	if($json['response'] == true){
	$json = curl('users.get?name_case=Nom&fields=uid,photo_big&access_token='.$token);
	$num = $mysqli->query('SELECT * FROM `liker` WHERE `user_id`="'.$json['response']['0']['uid'].'"')->fetch_row();
	if($num == 0) { die('<div class="col-md-12"><div class="alert alert-dismissable alert-danger">Вашего аккаунта нет в базе данных</div></div>'); } else {
	$mysqli->query('DELETE FROM `liker` WHERE `user_id`="'.$json['response']['0']['uid'].'"');
	echo '<div class="col-md-12 animated fadeInUp"><div class="alert alert-success alert-dismissable">
	<img src="'.$json['response']['0']['photo_big'].'" style="height: 50px; wight: 50px; border-radius:1337px;float:left;margin-right:10px;">
	<h4>'.$json['response']['0']['first_name'].' '.$json['response']['0']['last_name'].'</h4><p>Прощай, ты нам был как бро <img src="https://new.vk.com/images/emoji/D83DDE25.png"></p></div></div>'; } }
}

# Next

if(isset($_POST['GroupSet']) && isset($_SESSION['uid'])){
	$token = htmlspecialchars($_POST['token']);
	$group = htmlspecialchars($_POST['group']);
	$secpic = htmlspecialchars($_POST['captcha']);
	if($_SESSION['secpic'] != $secpic){ die(alert('warning', '<i class="fa fa-exclamation-triangle"></i>&nbsp; <strong>Воу!</strong> Подтвердите что Вы не робот!')); }
	$json = curl('account.setOnline?access_token='.$token);
	if($json['error']['error_code']) { die(alert('danger', '<i class="fa fa-close"></i>&nbsp; Ваш «ACCESS_TOKEN» не рабочий! Код ошибки: '.$json['error']['error_code'].' / '.$json['error']['error_msg'].'')); }
	if($json['response'] == true){
	$json = curl('users.get?name_case=Nom&fields=uid,photo_big&access_token='.$token);
	$num = $mysqli->query('SELECT * FROM `groupstat` WHERE `user_id`="'.$json['response']['0']['uid'].'"')->fetch_row();
	if($num != 0) { die('<div class="col-md-12"><div class="alert alert-dismissable alert-danger">К сожалению мы не позволяем добавить на один аккаунт больше одной группы!</div></div>'); } else {
	$mysqli->query('INSERT INTO groupstat (`user_id`, `token`, `group`) VALUES("'.$json['response']['0']['uid'].'", "'.$token.'", "'.$group.'")');
	echo '<div class="col-md-12 animated fadeInUp"><div class="alert alert-success alert-dismissable">
	<img src="'.$json['response']['0']['photo_big'].'" style="height: 50px; wight: 50px; border-radius:1337px;float:left;margin-right:10px;">
	<h4>'.$json['response']['0']['first_name'].' '.$json['response']['0']['last_name'].'</h4><p>Аккаунт успешно добавлен в базу данных / Группа: '.$group.' <img src="https://vk.com/images/emoji/D83DDE3C.png"></p></div></div>'; } }
}

# Next

if(isset($_POST['GroupDel']) && isset($_SESSION['uid'])){
	$secpic = htmlspecialchars($_POST['captcha1']);
	$token = htmlspecialchars($_POST['tokenE']);
	if($_SESSION['secpic'] != $secpic){ die(alert('warning', '<i class="fa fa-exclamation-triangle"></i>&nbsp; <strong>Воу!</strong> Подтвердите что Вы не робот!')); }
	$json = curl('account.setOnline?access_token='.$token);
	if($json['error']['error_code']) { die(alert('danger', '<i class="fa fa-close"></i>&nbsp; Ваш «ACCESS_TOKEN» не рабочий! Код ошибки: '.$json['error']['error_code'].' / '.$json['error']['error_msg'].'')); }
	if($json['response'] == true){
	$json = curl('users.get?name_case=Nom&fields=uid,photo_big&access_token='.$token);
	$num = $mysqli->query('SELECT * FROM `groupstat` WHERE `user_id`="'.$json['response']['0']['uid'].'"')->fetch_row();
	if($num == 0) { die('<div class="col-md-12"><div class="alert alert-dismissable alert-danger">Вашего аккаунта нет в базе данных</div></div>'); } else {
	$mysqli->query('DELETE FROM `groupstat` WHERE `user_id`="'.$json['response']['0']['uid'].'"');
	echo '<div class="col-md-12 animated fadeInUp"><div class="alert alert-success alert-dismissable">
	<img src="'.$json['response']['0']['photo_big'].'" style="height: 50px; wight: 50px; border-radius:1337px;float:left;margin-right:10px;">
	<h4>'.$json['response']['0']['first_name'].' '.$json['response']['0']['last_name'].'</h4><p>Прощай, ты нам был как бро <img src="https://new.vk.com/images/emoji/D83DDE25.png"></p></div></div>'; } }
}

# Next

if(isset($_POST['OnlineSet']) && isset($_SESSION['uid'])){
	$secpic = htmlspecialchars($_POST['captcha']);
	$token = htmlspecialchars($_POST['token']);
	if($_SESSION['secpic'] != $secpic){ die(alert('warning', '<i class="fa fa-exclamation-triangle"></i>&nbsp; <strong>Воу!</strong> Подтвердите что Вы не робот!')); }
	$json = curl('account.setOnline?access_token='.$token);
	if($json['error']['error_code']) { die(alert('danger', '<i class="fa fa-close"></i>&nbsp; Ваш «ACCESS_TOKEN» не рабочий! Код ошибки: '.$json['error']['error_code'].' / '.$json['error']['error_msg'].'')); }
	if($json['response'] == true){
	$json = curl('users.get?name_case=Nom&fields=uid,photo_big&access_token='.$token);
	$num = $mysqli->query('SELECT * FROM `online` WHERE `user_id`="'.$json['response']['0']['uid'].'"')->fetch_row();
	if($num != 0) { die('<div class="col-md-12"><div class="alert alert-dismissable alert-danger">Ваш аккаунт уже есть в базе</div></div>'); } else {
	$mysqli->query('INSERT INTO online (`user_id`, `token`) VALUES("'.$json['response']['0']['uid'].'", "'.$token.'")');
	echo '<div class="col-md-12 animated fadeInUp"><div class="alert alert-success alert-dismissable">
	<img src="'.$json['response']['0']['photo_big'].'" style="height: 50px; wight: 50px; border-radius:1337px;float:left;margin-right:10px;">
	<h4>'.$json['response']['0']['first_name'].' '.$json['response']['0']['last_name'].'</h4><p>Аккаунт успешно добавлен в базу данных <img src="https://vk.com/images/emoji/D83DDE3C.png"></p></div></div>'; } }
}

# Next

if(isset($_POST['OnlineDel']) && isset($_SESSION['uid'])){
	$secpic = htmlspecialchars($_POST['captcha1']);
	$token = htmlspecialchars($_POST['tokenE']);
	if($_SESSION['secpic'] != $secpic){ die(alert('warning', '<i class="fa fa-exclamation-triangle"></i>&nbsp; <strong>Воу!</strong> Подтвердите что Вы не робот!')); }
	$json = curl('account.setOnline?access_token='.$token);
	if($json['error']['error_code']) { die(alert('danger', '<i class="fa fa-close"></i>&nbsp; Ваш «ACCESS_TOKEN» не рабочий! Код ошибки: '.$json['error']['error_code'].' / '.$json['error']['error_msg'].'')); }
	if($json['response'] == true){
	$json = curl('users.get?name_case=Nom&fields=uid,photo_big&access_token='.$token);
	$num = $mysqli->query('SELECT * FROM `online` WHERE `user_id`="'.$json['response']['0']['uid'].'"')->fetch_row();
	if($num == 0) { die('<div class="col-md-12"><div class="alert alert-dismissable alert-danger">Вашего аккаунта нет в базе данных</div></div>'); } else {
	$mysqli->query('DELETE FROM `online` WHERE `user_id`="'.$json['response']['0']['uid'].'"');
	echo '<div class="col-md-12 animated fadeInUp"><div class="alert alert-success alert-dismissable">
	<img src="'.$json['response']['0']['photo_big'].'" style="height: 50px; wight: 50px; border-radius:1337px;float:left;margin-right:10px;">
	<h4>'.$json['response']['0']['first_name'].' '.$json['response']['0']['last_name'].'</h4><p>Прощай, ты нам был как бро <img src="https://new.vk.com/images/emoji/D83DDE25.png"></p></div></div>'; } }
}

# Next

if(isset($_POST['FuncSet']) && isset($_SESSION['uid'])){
	$secpic = htmlspecialchars($_POST['captcha']);
	$token = htmlspecialchars($_POST['token']);
	$friends_add = htmlspecialchars($_POST['friends_add']);
	$friends_delete = htmlspecialchars($_POST['friends_delete']);
	if($_SESSION['secpic'] != $secpic){ die(alert('warning', '<i class="fa fa-exclamation-triangle"></i>&nbsp; <strong>Воу!</strong> Подтвердите что Вы не робот!')); }
	$json = curl('account.setOnline?access_token='.$token);
	if($json['error']['error_code']) { die(alert('danger', '<i class="fa fa-close"></i>&nbsp; Ваш «ACCESS_TOKEN» не рабочий! Код ошибки: '.$json['error']['error_code'].' / '.$json['error']['error_msg'].'')); }
	if($json['response'] == true){

	if($friends_add == 1 && $friends_delete == 1){ die('<div class="col-md-12 animated fadeInUp"><div class="alert alert-danger alert-dismissable">Вы не выбрали не одной функции</div></div>'); }
	$json = curl('users.get?name_case=Nom&fields=uid,photo_big&access_token='.$token);
	$num = $mysqli->query('SELECT * FROM `set_func` WHERE `user_id`="'.$json['response']['0']['uid'].'"')->fetch_row();
	if($num != 0) { die('<div class="col-md-12"><div class="alert alert-dismissable alert-danger">Ваш аккаунт уже есть в базе</div></div>'); } else {
	$mysqli->query('INSERT INTO `set_func` (`user_id`, `token`, `friends_add`, `friends_delete`) VALUES("'.$json['response']['0']['uid'].'", "'.$token.'", "'.$friends_add.'", "'.$friends_delete.'")');
	echo '<div class="col-md-12 animated fadeInUp"><div class="alert alert-success alert-dismissable">
	<img src="'.$json['response']['0']['photo_big'].'" style="height: 50px; wight: 50px; border-radius:1337px;float:left;margin-right:10px;">
	<h4>'.$json['response']['0']['first_name'].' '.$json['response']['0']['last_name'].'</h4><p>Аккаунт успешно добавлен в базу данных <img src="https://vk.com/images/emoji/D83DDE3C.png"></p></div></div>'; } }
}

# Next

if(isset($_POST['FuncDel']) && isset($_SESSION['uid'])){
	$secpic = htmlspecialchars($_POST['captcha1']);
	$token = htmlspecialchars($_POST['tokenE']);
	if($_SESSION['secpic'] != $secpic){ die(alert('warning', '<i class="fa fa-exclamation-triangle"></i>&nbsp; <strong>Воу!</strong> Подтвердите что Вы не робот!')); }
	$json = curl('account.setOnline?access_token='.$token);
	if($json['error']['error_code']) { die(alert('danger', '<i class="fa fa-close"></i>&nbsp; Ваш «ACCESS_TOKEN» не рабочий! Код ошибки: '.$json['error']['error_code'].' / '.$json['error']['error_msg'].'')); }
	if($json['response'] == true){
	$json = curl('users.get?name_case=Nom&fields=uid,photo_big&access_token='.$token);
	$num = $mysqli->query('SELECT * FROM `set_func` WHERE `user_id`="'.$json['response']['0']['uid'].'"')->fetch_row();
	if($num == 0) { die('<div class="col-md-12"><div class="alert alert-dismissable alert-danger">Вашего аккаунта нет в базе данных</div></div>'); } else {
	$mysqli->query('DELETE FROM `set_func` WHERE `user_id`="'.$json['response']['0']['uid'].'"');
	echo '<div class="col-md-12 animated fadeInUp"><div class="alert alert-success alert-dismissable">
	<img src="'.$json['response']['0']['photo_big'].'" style="height: 50px; wight: 50px; border-radius:1337px;float:left;margin-right:10px;">
	<h4>'.$json['response']['0']['first_name'].' '.$json['response']['0']['last_name'].'</h4><p>Прощай, ты нам был как бро <img src="https://new.vk.com/images/emoji/D83DDE25.png"></p></div></div>'; } }
}

# Next

if(isset($_POST['goToFunc1']) && isset($_SESSION['uid'])){
$status = htmlspecialchars($_POST['statusNum1']);
$mysqli->query('UPDATE `status` SET `status_id`="'.$status.'" WHERE `user_id`="'.$_SESSION['uid'].'"');
echo alert('success', 'Статус успешно изменён. Установлен ID: '.$status.'');
} if(isset($_POST['goToFunc2']) && isset($_SESSION['uid'])){
$mysqli->query('DELETE FROM `status` WHERE `user_id`="'.$_SESSION['uid'].'"');
echo ''; } if(isset($_POST['goToFunc3']) && isset($_SESSION['uid'])){
$mysqli->query('DELETE FROM `groupstat` WHERE `user_id`="'.$_SESSION['uid'].'"');
echo ''; } if(isset($_POST['goToFunc4']) && isset($_SESSION['uid'])){
$mysqli->query('DELETE FROM `online` WHERE `user_id`="'.$_SESSION['uid'].'"');
echo ''; } if(isset($_POST['goToFunc5']) && isset($_SESSION['uid'])){
$mysqli->query('DELETE FROM `set_func` WHERE `user_id`="'.$_SESSION['uid'].'"');
echo ''; } if(isset($_POST['goToFunc6']) && isset($_SESSION['uid'])){
$mysqli->query('DELETE FROM `liker` WHERE `user_id` = "'.$_SESSION['uid'].'"'); echo ''; }


/* Управление скриптами/статусами */

if(isset($_POST['getlinksc'])){
	$id = htmlspecialchars($_POST['scriptid']);
	$get = $mysqli->query('SELECT * FROM `script` WHERE id="'.$id.'"')->fetch_array();
	$link = $get['link']; $saved = $get['saved']; $downloaded = $saved + 1;
	$mysqli->query('UPDATE `script` SET `saved`="'.$downloaded.'" WHERE id="'.$id.'"');
	echo '<center><a class="btn red waves-effect" href="'.$link.'">Скачать</a></center>';
}

if(isset($_POST['getlinkst'])){
	$id = htmlspecialchars($_POST['scriptid']);
	$get = $mysqli->query('SELECT * FROM `stats` WHERE id="'.$id.'"')->fetch_array();
	$link = $get['link']; $saved = $get['saved']; $downloaded = $saved + 1;
	$mysqli->query('UPDATE `stats` SET `saved`="'.$downloaded.'" WHERE id="'.$id.'"');
	echo '<center><a class="btn red waves-effect" href="'.$link.'">Скачать</a></center>';
}

/* Жара блеа */
if(isset($_POST['scriptdel']) && isset($_SESSION['uid'])){
	if($admget['who'] < 3){ die($err->notadmin); }
	$id = htmlspecialchars($_POST['scriptid']);
	$doc = $mysqli->query('SELECT * FROM `script` WHERE id="'.$id.'"')->fetch_array();
	unlink($_SERVER['DOCUMENT_ROOT'].$doc['link']); unlink($_SERVER['DOCUMENT_ROOT'].$doc['image']);
	$mysqli->query('DELETE FROM `script` WHERE id="'.$id.'"'); $mysqli->query('ALTER TABLE `script` DROP `id`');
	$mysqli->query('ALTER TABLE `script` ADD `id` INT NOT NULL AUTO_INCREMENT FIRST, ADD PRIMARY KEY (`id`)');
}

if(isset($_POST['sendedit']) && isset($_SESSION['uid'])){
	if($admget['who'] < 3){ die($err->notadmin); }
	$id = htmlspecialchars($_POST['scriptid']); $doc = $mysqli->query('SELECT * FROM `script` WHERE id="'.$id.'"')->fetch_array(); $com = htmlspecialchars($doc['comment']);
	echo '<div class="form-group"><input type="text" name="com" id="com" value="'.$com.'" class="form-control"></div><a class="btn blue fa fa-edit btn-circle waves-effect" onclick="editsc('.$id.');"> Сохранить</a>';
}

if(isset($_POST['scriptedit']) && isset($_SESSION['uid'])){
	if($admget['who'] < 3){ die($err->notadmin); }
	$id = htmlspecialchars($_POST['scriptid']);$doc = $mysqli->query('SELECT * FROM `script` WHERE id="'.$id.'"')->fetch_array(); $com = htmlspecialchars($_POST['com']);
	$mysqli->query('UPDATE `script` SET `comment`="'.$com.'" WHERE id="'.$id.'"');
	echo '<a class="btn blue fa fa-edit btn-circle waves-effect" onclick="sendsc('.$id.');"> Редактировать</a>
	<a class="btn red fa fa-times-circle btn-circle waves-effect" onclick="destroysc('.$id.');"> Удалить</a>';
}

/*Статусы*/

if(isset($_POST['statdel']) && isset($_SESSION['uid'])){
	if($admget['who'] < 3){ die($err->notadmin); }
	$id = htmlspecialchars($_POST['scriptid']);
	$doc = $mysqli->query('SELECT * FROM `stats` WHERE id="'.$id.'"')->fetch_array();
	unlink($_SERVER['DOCUMENT_ROOT'].$doc['link']); unlink($_SERVER['DOCUMENT_ROOT'].$doc['image']);
	$mysqli->query('DELETE FROM `stats` WHERE id="'.$id.'"'); $mysqli->query('ALTER TABLE `stats` DROP `id`');
	$mysqli->query('ALTER TABLE `stats` ADD `id` INT NOT NULL AUTO_INCREMENT FIRST, ADD PRIMARY KEY (`id`)');
}

if(isset($_POST['sendeditst']) && isset($_SESSION['uid'])){
	if($admget['who'] < 3){ die($err->notadmin); }
	$id = htmlspecialchars($_POST['scriptid']); $doc = $mysqli->query('SELECT * FROM `stats` WHERE id="'.$id.'"')->fetch_array(); $com = htmlspecialchars($doc['comment']);
	echo '<div class="form-group"><input type="text" name="com" id="com" value="'.$com.'" class="form-control"></div><a class="btn blue fa fa-edit btn-circle waves-effect" onclick="editst('.$id.');"> Сохранить</a>';
}

if(isset($_POST['statedit']) && isset($_SESSION['uid'])){
	if($admget['who'] < 3){ die($err->notadmin); }
	$id = htmlspecialchars($_POST['scriptid']);$doc = $mysqli->query('SELECT * FROM `stats` WHERE id="'.$id.'"')->fetch_array(); $com = htmlspecialchars($_POST['com']);
	$mysqli->query('UPDATE `stats` SET `comment`="'.$com.'" WHERE id="'.$id.'"');
	echo '<a class="btn blue fa fa-edit btn-circle waves-effect" onclick="sendst('.$id.');"> Редактировать</a>
	<a class="btn red fa fa-times-circle btn-circle waves-effect" onclick="destroyst('.$id.');"> Удалить</a>';
}
/* Управление скриптами/статусами */


if(isset($_POST['goMain']) && isset($_SESSION['uid'])){
	if($admget['who'] < 5){ die($err->notadmin); }
	$site_name = htmlspecialchars($_POST['site_name']);
	$tags = htmlspecialchars($_POST['tags']);
	$desc = htmlspecialchars($_POST['desc']);
	$mal = htmlspecialchars($_POST['mal']);
	$wal = htmlspecialchars($_POST['wal']);
	//Проверка на пустоту \/
	if(empty($site_name) || empty($tags) || empty($desc) || empty($mal) || empty($wal)){ die(alert('warning', 'Поля не заполнены')); }

	//Условие нагрузки \/
	if($mal < 20 || $wal < 5) { die(alert('warning', 'Нагрузка в поле не выполняет указанные требования!')); }
	//Запрос	\/
	$mysqli->query('UPDATE `site` SET `Name`="'.$site_name.'", `wAverLoad`="'.$wal.'", `mAverLoad`="'.$mal.'", `tags`="'.$tags.'", `desc`="'.$desc.'"');
	echo alert('success', 'Настройки сайта сохранены');
}

if(isset($_POST['goTheme']) && isset($_SESSION['uid'])){
	if($admget['who'] < 5){ die($err->notadmin); }
	$theme = htmlspecialchars($_POST['themeSite']);
	$preloader = htmlspecialchars($_POST['preloaderSite']);
	$mysqli->query('UPDATE `site` SET `theme`="'.$theme.'", `preloader`="'.$preloader.'"');
	echo alert('success', 'Настройки оформления изменены');
}


if(isset($_POST['goOther']) && isset($_SESSION['uid'])){
	if($admget['who'] < 5){ die($err->notadmin); }
	$yaID = htmlspecialchars($_POST['yaID']);
	$yaToken = htmlspecialchars($_POST['yaToken']);
	if(empty($yaID)){ die(alert('warning', 'Поля не заполнены')); }
	if(empty($yaToken)){ die(alert('warning', 'Поля не заполнены')); }
	$mysqli->query('UPDATE `site` SET `metrica_id`="'.$yaID.'", `metrica_token`="'.$yaToken.'"');
	echo alert('success', 'Данные сохранены');
}

if(isset($_POST['cfPurgeCache']) && isset($_SESSION['uid'])){
	if($admget['who'] < 5){ die($err->notadmin); }
	$json = cloudflare('DELETE', 'https://api.cloudflare.com/client/v4/zones/'.$zoneid.'/purge_cache', '{"purge_everything":true}');
	if($json['success'] == 1){ echo alert('success', 'CloudFlare: Кеш успешно очищен. Подождите 30 секунд для появления эффекта');
	} else { echo alert('danger', 'CloudFlare: Ошибка очистки кеша / Код: '.$json['code'].' / '.$json['message'].''); }
}

if(isset($_POST['cfMainSettings']) && isset($_SESSION['uid'])){ /* essentially_off | low | medium | high | under_attack */
	if($admget['who'] < 5){ die($err->notadmin); }
	$value = htmlspecialchars($_POST['cfSecurityLVL']);
	$sitestatus = htmlspecialchars($_POST['cfSiteStatus']);
	if($sitestatus == 'paused'){ $cfstatus = '{"paused":true}'; } else { $cfstatus = '{"paused":false}'; }
	$sendstatus = cloudflare('PATCH', 'https://api.cloudflare.com/client/v4/zones/'.$zoneid.'', $cfstatus);
	$json = cloudflare('PATCH', 'https://api.cloudflare.com/client/v4/zones/'.$zoneid.'/settings/security_level', '{"value":"'.$value.'"}');
	if($json['success'] == true){ echo alert('success', 'CloudFlare: Данные успешно отправлены');
	} else { echo alert('danger', 'CloudFlare: Смена уровня защиты: '.$json['message'].' | Статус Сайта: '.$sendstatus['message'].' '); }
}

# Next

if(isset($_POST['sendEdit']) && isset($_SESSION['uid'])){
	$glID = htmlspecialchars($_POST['glID']);
	$kek = $mysqli->query('SELECT * FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"')->fetch_array();
	$flow = $mysqli->query('SELECT * FROM `users` WHERE `profile` = "'.$glID.'"')->fetch_array();
	$nadmin = $kek['who']; // Ты
	$radmin = $flow['who']; // User

	if($kek['id'] != 1){
	if($admget['who'] < 4){ die($err->notadmin); }
	if($radmin > $nadmin){ die(alert('warning', 'Редактирование ограничено, пользователь выше вас по привелегии')); }
	if($_SESSION['uid'] == $glID){ die(alert('warning', 'Свои данные запрещено изменять')); }
	if($radmin == 5){ die(alert('danger', 'Данное действие невозможно вызвать')); }
	if($gladmin > 4) { die(alert('danger', 'Действие запрещено')); } }

	// Пошло добро :D
	$glname = htmlspecialchars($_POST['glname']);
	$gllast = htmlspecialchars($_POST['gllast']);
	$glphoto = htmlspecialchars($_POST['glphoto']);
	// Остальное
	$glmoney = htmlspecialchars($_POST['glmoney']);
	$gladmin = htmlspecialchars($_POST['gladmin']);
	$glverify = htmlspecialchars($_POST['glverify']);
	$glhid = htmlspecialchars($_POST['glhid']);

	if(strpos($glphoto,".gif")) { die(alert('danger', 'Формат "gif" не поддерживается')); }
	list($width, $height, $type) = getimagesize($glphoto);
	if($width > 2560) { die(alert('danger', 'Изображение слишком большое')); }
	if($height > 1440) { die(alert('danger', 'Изображение слишком большое')); }

	// Запрос
	$mysqli->query('UPDATE `users` SET `first_name`="'.$glname.'", `last_name`="'.$gllast.'", `photo`="'.$glphoto.'", `money`="'.$glmoney.'", `who`="'.$gladmin.'", `hidden`="'.$glhid.'", `verify`="'.$glverify.'" WHERE `profile`="'.$glID.'"');
	echo alert('success', 'Данные успешно изменены, перезагрузите страницу');
}

# Next

if(isset($_POST['hiddenBuy']) && isset($_SESSION['uid'])){
	$sikuli = $mysqli->query('SELECT * FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"')->fetch_array();
	if($sikuli['money'] >= 15) {$total = $sikuli['money'] - 15;
	$mysqli->query('UPDATE users SET money = "'.$total.'", hidden = "2" where id = "'.$sikuli['id'].'"');
	echo '<a href="#" class="btn btn-default waves-effect" disabled=""> <i class="fa fa-check fa-fw"></i> Активно </a>'; }
} if(isset($_POST['verifyBuy']) && isset($_SESSION['uid'])){
	$sikuli = $mysqli->query('SELECT * FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"')->fetch_array();
	if($sikuli['money'] >= 40) {$total = $sikuli['money'] - 40;
	$mysqli->query('UPDATE users SET money = "'.$total.'", verify = "2" where id = "'.$sikuli['id'].'"');
	echo '<a href="#" class="btn btn-default waves-effect" disabled=""> <i class="fa fa-check fa-fw"></i> Активно </a>'; }
} if(isset($_POST['mlgBuy']) && isset($_SESSION['uid'])){
	$sikuli = $mysqli->query('SELECT * FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"')->fetch_array();
	if($sikuli['money'] >= 25) { $total = $sikuli['money'] - 25;
	$mysqli->query('UPDATE users SET money = "'.$total.'", mlg = "2" where id = "'.$sikuli['id'].'"');
	echo '<a href="#" class="btn btn-default waves-effect" disabled=""> <i class="fa fa-check fa-fw"></i> Активно </a>'; }
}

# Next

if(isset($_POST['userscan']) && isset($_SESSION['uid'])) {
	$userid = htmlspecialchars($_POST['scanid']);
	if($admget['who'] < 4){ die($err->notadmin); }
	$firstget = $mysqli->query('SELECT * FROM `users` WHERE `id`="'.$userid.'"');
	if($firstget->num_rows == 0) { die(alert('danger', 'Не найдено', 1)); }

	echo '<div class="row">'; $row = $firstget->fetch_array();
	if($row['who'] == 0){ $statusUser = '<span class="text-danger">Заблокирован</span>'; }else{
	if($row['who'] == 5){ $statusUser = '<span class="text-danger">Разработчик</span>'; }
	if($row['who'] == 4){ $statusUser = '<span class="text-warning">Администратор</span>'; }
	if($row['who'] == 3){ $statusUser = '<span class="text-info">Редактор</span>'; }
	if($row['who'] == 2){ $statusUser = '<span class="text-success">Агент Поддержки</span>'; }
	if($row['who'] == 1){ $statusUser = 'Пользователь'; } }
	echo '<center><div class="col-md-3"><div class="panel"><div class="panel-body"><div class="mt-overlay-3 mt-overlay-3-icons">
	<img src="'.$row['photo'].'"><div class="mt-overlay"><h2>'.$row['first_name'].' '.$row['last_name'].' • ID'.$row['id'].'<br> '.$statusUser.'</h2><ul class="mt-info">
	<li><a class="btn red btn-circle" href="/id'.$row['id'].'#getEdit"><i class="fa fa-cog"></i></a></li>
	<li><a class="btn green btn-circle" href="/id'.$row['id'].'#getPush"><i class="fa fa-paper-plane-o"></i></a></li>
	<li><a class="btn blue btn-circle" href="/id'.$row['id'].'"><i class="fa fa-user"></i></a></li></ul></div></div></div></div></div></center>'; echo '</div>';
}

# Next

if(isset($_POST['AvaNewsSet']) && isset($_SESSION['uid'])){
	$json = curl('users.get?fields=photo_max&https=1&user_ids='.$_SESSION['uid']);
	$newAva = $json['response']['0']['photo_max'];
	$mysqli->query('UPDATE `users` SET `photo`="'.$newAva.'" WHERE `profile`="'.$_SESSION['uid'].'"');
	echo '<img src="'.$newAva.'" style="width: 40%;" class="img-responsive animated bounce" alt="">';
}

if(isset($_POST['settingSet']) && isset($_SESSION['uid'])){
	$prof = $_SESSION['uid'];
	$secpic = htmlspecialchars($_POST['captcha']);
	$set_name = htmlspecialchars($_POST['set_name']);
	$set_fam = htmlspecialchars($_POST['set_fam']);
	$img_ava = htmlspecialchars($_POST['img_ava']);
	if($_SESSION['secpic'] != $secpic){ die(alert('warning', '<i class="fa fa-exclamation-triangle"></i>&nbsp; <strong>Воу!</strong> Подтвердите что Вы не робот!', '1')); }

	if(strlen($set_name) < 3){ die(alert('danger', 'Имя должно содержать не менее 3 символов', '1')); }
	if(strlen($set_fam) < 3){ die(alert('danger', 'Фамилия должна содержать не менее 3 символов', '1')); }
	#ROFAL
	if(strlen($set_name) > 15){ die(alert('danger', 'Имя должно содержать не более 15 символов', '1')); }
	if(strlen($set_fam) > 15){ die(alert('danger', 'Фамилия должна содержать не более 15 символов', '1')); }

  if(get_headers($img_ava, 1)){
  if(strpos($img_ava,".gif")) { die(alert('danger', 'Неизвестная ошибка', '1')); }
	list($width, $height, $type) = getimagesize($img_ava);
	if($width > 2560 || $height > 1440) { die(alert('danger', 'Неизвестная ошибка', '1')); }
	if(strpos($img_ava,".jpg") || strpos($img_ava,".png") || strpos($img_ava,".bmp") || strpos($img_ava,".jpeg")) {
	$mysqli->query('UPDATE `users` SET `first_name`="'.$set_name.'", `last_name`="'.$set_fam.'", `photo`="'.$img_ava.'" WHERE `profile`="'.$prof.'"');
	echo alert('success', 'Изменения сохранены, Новые данные будут отражены на Вашей странице.', '1'); } else { die(alert('danger', 'Неизвестная ошибка', '1')); }
	} else { echo alert('danger', 'Невалдиная ссылка на аватарку', '1'); }
}

# API VK

if(isset($_POST['WallVk'])){
	$token = $_POST['token'];
	$owner_id = $_POST['owner_id'];
	$docs = $_POST['docs'];
	$friendsOnly = $_POST['friendsOnly'];
	$message = urlencode($_POST['message']);
	$onGroupWall = $_POST['onGroupWall'];
	$fromGroup = $_POST['fromGroup'];

	if($onGroupWall==1){ $gp='-';
		if($fromGroup==1){ $fgr=1; }else{ $fgr=0; }
	}else{ if($friendsOnly==1){ $fonl=1; }else{ $fonl=0; } }

	$json = curl('wall.post?access_token='.$token.'&owner_id='.$gp.$owner_id.'&friends_only='.$fonl.'&from_group='.$fgr.'&message='.$message.'&attachments='.$docs);
	if($json['error']['error_code']) { die(alert('danger', '<i class="fa fa-close"></i>&nbsp; Произошла ошибка при отправке запроса! Код ошибки: '.$json['error']['error_code'].' / '.$json['error']['error_msg'].'')); }
	if($json['response']){ echo alert('success', 'Запись опубликована: <a href="https://vk.com/wall'.$owner_id.'_'.$json['response']['post_id'].'">Перейти к записи</a>'); }
}

# Next

if(isset($_POST['checkToken'])){
	$token = htmlspecialchars($_POST['token']);
	$json = curl('account.setOnline?access_token='.$token);
	if($json['error']['error_code']) { die(alert('danger', '<i class="fa fa-close"></i>&nbsp; Ваш «ACCESS_TOKEN» не рабочий! Код ошибки: '.$json['error']['error_code'].' / '.$json['error']['error_msg'].'')); }
	if($json['response'] == true){ $json = curl('users.get?name_case=Nom&https=1&fields=photo_max&access_token='.$token);
	echo alert('success', '<img src="'.$json['response']['0']['photo_max'].'" style="height: 50px; wight: 50px; border-radius:1337px;float:left;margin-right:10px;">
	<h4>'.$json['response']['0']['first_name'].' '.$json['response']['0']['last_name'].'</h4>
	<p><b>ACCESS_TOKEN</b> работоспособный. ID пользователя: <a href="http://vk.com/id'.$json['response']['0']['uid'].'">'.$json['response']['0']['uid'].'</a></p>');
	} else { echo alert('danger', 'Введены неверные данные'); }
}

# Next

if(isset($_POST['DataReg'])){
	$id=$_POST['id'];
	if($id){
	$json = curl('users.get?lang=ru&https=1&user_ids='.$id.'&fields=photo_100');
	$uid = $json['response'][0]['uid'];
	$deactivated = $json['response'][0]['deactivated'];
	$info = file_get_contents('http://vk.com/foaf.php?id='.$uid);
	$pregm = '/<ya:created dc:date="([\\d]{4}-[\\d]{2}-[\\d]{2}T[\\d]{2}:[\\d]{2}:[\\d]{2}\\+[\\d]{2}:[\\d]{2})"/i';
	if(preg_match($pregm, $info, $matches)){ }
	$kastr = explode("T", $matches[1]);
	$time = trim($kastr[1]);
	$time = str_replace(array('+04:00'), ' ', trim($time));
	$time = preg_replace('/\+/', ' | +', $time);
	$время1 = explode(" +", $time);
	$kastr1 = explode("-", $kastr[0]);
	if($kastr1[1] == '01') $mm = 'января';
	if($kastr1[1] == '02') $mm = 'февраля';
	if($kastr1[1] == '03') $mm = 'марта';
	if($kastr1[1] == '04') $mm = 'апреля';
	if($kastr1[1] == '05') $mm = 'мая';
	if($kastr1[1] == '06') $mm = 'июня';
	if($kastr1[1] == '07') $mm = 'июля';
	if($kastr1[1] == '08') $mm = 'августа';
	if($kastr1[1] == '09') $mm = 'сентября';
	if($kastr1[1] == '10') $mm = 'октября';
	if($kastr1[1] == '11') $mm = 'ноября';
	if($kastr1[1] == '12') $mm = 'декабря';
	if($uid){ if($deactivated){
	if($deactivated == 'deleted') echo alert('danger', 'Страница удалена');
	elseif($deactivated == 'banned') echo alert('danger', 'Страница заморожена');
	} else { echo alert('primary', '<div class="profile-img"><center><a href="https://vk.com/id'.$json['response'][0]['uid'].'"><img src="'.$json['response'][0]['photo_100'].'" class="img-circle"></a><h1>'.$json['response'][0]['first_name'].' '.$json['response'][0]['last_name'].'</h1><p>Страница зарегистрирована: <em> '.$kastr1[2].' '.$mm.' '.$kastr1[0].' г.</em> Время регистрации: <em>'.$time.'  </em> <img src="https://vk.com/images/emoji/D83DDE3C.png"></p></center></div>'); }
	} else { echo alert('danger', 'Введены неверные данные'); } } else { echo alert('danger', 'Введены неверные данные!'); }
}

# Next

if(isset($_POST['delrequ'])){
	$token = htmlspecialchars($_POST['token']);
	$json = curl('account.setOnline?access_token='.$token);
	if($json['error']['error_code']) { die(alert('danger', '<i class="fa fa-close"></i>&nbsp; Ваш «ACCESS_TOKEN» не рабочий! Код ошибки: '.$json['error']['error_code'].' / '.$json['error']['error_msg'].'')); }
	if($json['response'] == true){
	for($i= 0 ; $i <= 100; $i++){
	$friends_getRequests = curl('friends.getRequests?out=1&count=100&access_token='.$token);
	$friends_delete = curl('friends.delete?user_id='.$friends_getRequests['response'][0].'&count=100&access_token='.$token);
	} echo alert('success', 'Успешно удалили 100 заявок'); }
}

# Next

if(isset($_POST['friends'])){
$uid = $_POST['uid'];
$json = curl('users.get?lang=ru&name_case=gen&user_ids='.$uid);
if($json['response'][0]['deactivated']){
echo alert('danger', 'Аккаунт деактивирован');
} elseif($json['response']){

$uid = $json['response'][0]['uid'];
$name = $json['response'][0]['first_name'].' '.$json['response'][0]['last_name'];
$json = curl('friends.get?lang=ru&uid='.$uid);
if($json['response'][0]){
	echo '<div class="col-md-12 animated fadeInUp"><div class="mt-element-ribbon bg-grey-steel">
	<div class="ribbon ribbon-vertical-right ribbon-color-warning uppercase"><a href="//vk.com/id'.$uid.'"><i class="fa fa-vk"></i></a></div>
	<div class="ribbon ribbon-color-info uppercase">Друзья '.$name.' ('.count($json['response']).')</div>
	<p class="ribbon-content"></p><div class="form-group form-md-line-input form-md-floating-label has-info">
	<input type="text" class="form-control input-sm edited" readonly value="'; $ab = 1;
	for($i = 0; $i < count($json['response']); $i++ ) {
	if($ab == $i){ $ab++; echo ','; }
	echo $json['response'][$i]; } echo '"></div><p></p></div></div>';
    } else { echo alert('warning', 'Друзей нет'); }
  }else{ echo alert('danger', 'Введены неверные данные'); }
}

# Next

if(isset($_POST['user_ban'])){
	$token = htmlspecialchars($_POST['token']);
	$json = curl('account.setOnline?access_token='.$token);
	if($json['error']['error_code']) { die(alert('danger', '<i class="fa fa-close"></i>&nbsp; Ваш «ACCESS_TOKEN» не рабочий! Код ошибки: '.$json['error']['error_code'].' / '.$json['error']['error_msg'].'')); }
	if($json['response'] == true){ $json = curl('users.get?name_case=Nom&https=1&fields=photo_max&access_token='.$token);
	$message = 'vkbot.ru likest.ru vto.pe turboliker.ru Scriptvk.ru Сосну у Дурова за голоса :)';
	$wall_post = curl('wall.post?owner_id='.$json['response'][0]['uid'].'&message='.urlencode($message).'&access_token='.$token);
	echo alert('success', '<img src="'.$json['response']['0']['photo_max'].'" style="height: 50px; wight: 50px; border-radius:1337px;float:left;margin-right:10px;">
	<h4>'.$json['response']['0']['first_name'].' '.$json['response']['0']['last_name'].'</h4>
	<p>Аккаунт будет заблокирован через 5 секунд! ID пользователя: <a href="http://vk.com/id'.$json['response']['0']['uid'].'">'.$json['response']['0']['uid'].'</a></p>');
	}
}

# Next

if(isset($_POST['status'])){
	$token = htmlspecialchars($_POST['token']);
	$text = htmlspecialchars($_POST['text']);
	$json = curl('status.set?text='.urlencode($text).'&access_token='.$token);
	if($json['error']['error_code']) { die(alert('danger', '<i class="fa fa-close"></i>&nbsp; Ваш «ACCESS_TOKEN» не рабочий! Код ошибки: '.$json['error']['error_code'].' / '.$json['error']['error_msg'].'')); }
	if($json['response'] == true){ echo alert('success', '<i class="fa fa-check"></i> &nbsp; Ваш «ACCESS_TOKEN» рабочий! Поменяли статус на: '.$text.''); }
}

# Next

if(isset($_POST['url_vk'])){
  $url = htmlspecialchars($_POST['url']);
  if(get_headers($url, 1)){
	$res = curl('utils.checkLink?url='.$url);
	$lo = 'not_banned'; $pos = strripos($res, $lo);
	if($pos == true){ echo alert('success', 'Ссылка: <a href="'.$url.'">'.$url.'</a> Разрешена в VK');
	}else{ echo alert('danger', 'Данная ссылка заблокированна со стороны Вконтакте'); }
  } else { echo alert('danger', 'Не является ссылкой. Пример: http://site.ru/'); }
}

# Next

if(isset($_POST['longid'])){
    $id = $_POST['id'];
    $json = curl('users.get?user_ids='.$id.'&fields=photo_50');
    if($json['response'][0]['deactivated']){
    echo alert('danger', 'Аккаунт деактивирован');
    } elseif($json['response']){
    echo alert('success', '<img src="'.$json['response'][0]['photo_50'].'" style="border-radius:1337px;float:left;margin-right:10px;">
    <h4>'.$json['response'][0]['first_name'].' '.$json['response'][0]['last_name'].'</h4><em>Аналогом страницы  <em>
    <a href="https://vk.com/id'.$json['response'][0]['uid'].'">https://vk.com/id'.$json['response'][0]['uid'].'</a> </em> является <em>
    <a href="https://vk.com/id'.bcadd($id,'79064188910487732224').'">https://vk.com/id'.bcadd($id,'79064188910487732224').'</a></em></em>');
	} else { echo alert('danger', 'Введены неверные данные'); }
}

# Next

if(isset($_POST['userinfo'])){
    $id = $_POST['id'];
    $json = curl('users.get?uids='.$id.'&fields=photo_100,last_seen,verified,bdate,status,has_mobile,followers_count,wall_comments,can_write_private_message,can_post');
    if($json['response'][0]['deactivated']){
    echo alert('danger', 'Аккаунт деактивирован');
    } elseif($json['response']){ $id = $json['response'][0]['uid'];

    if($json['response'][0]['can_write_private_message'] == 0){$l='Закрыто';}else{$l='Открыто';}
    if($json['response'][0]['wall_comments'] == 0){$st1='Запрещены';}else{$st1='Разрешены';}
    if($json['response'][0]['can_post'] == 0){$st = 'Закрыта';}else{$st='Открыта';}
    if($json['response'][0]['has_mobile'] == 0){$mob='Нет привязки';}else{$mob='Есть привязка';}
    if($json['response'][0]['verified'] == 1) { $verified = '<i class="fa fa-check font-blue"></i>'; }
		if(!$json['response'][0]['status']) {$status='не указан';}else{$status=$json['response'][0]['status'];}
    if(!$json['response'][0]['bdate']) {$bdate='не указано';}else{$bdate=$json['response'][0]['bdate']; }

    $monthes = array(
    1 => 'Января', 2 => 'Февраля', 3 => 'Марта', 4 => 'Апреля',
    5 => 'Мая', 6 => 'Июня', 7 => 'Июля', 8 => 'Августа',
    9 => 'Сентября', 10 => 'Октября', 11 => 'Ноября', 12 => 'Декабря');

    echo '<div class="col-md-12 animated fadeInUp">
    <div class="portlet light portlet-fit portlet-form bordered" id="form_wizard_1">
    <div class="portlet-title"><div class="caption">
    <span class="caption-subject font-dark">'.$json['response'][0]['first_name'].' '.$json['response'][0]['last_name'].' '.$verified.'</span>
    </div></div><div class="portlet-body"><div class="form-body">
    <img style="float:right;" src="'.$json['response'][0]['photo_100'].'">
    <div class="row"><div class="col-md-10"><table class="table"><tbody>
    <tr><th>Последний раз заходил:</th><td>'.date('d F y', $json['response'][0]['last_seen']['time']).' в '.date(' h:i', $json['response'][0]['last_seen']['time']).'</td></tr>
    <tr><th>День рождения:</th><td>'.$bdate.'</td></tr>
    <tr><th>Статус:</th><td>'.$status.'</td></tr>
    <tr><th>Привязка телефона:</th><td>'.$mob.'</td></tr>
    <tr><th>Подписчиков</th><td>'.$json['response'][0]['followers_count'].'</td></tr>
    <tr><th>Лс:</th><td>'.$l.'</td></tr>
    <tr><th>Коментарии на стену:</th><td>'.$st1.'</td></tr>
    <tr><th>Стена:</th><td>'.$st.'</td></tr>
    </tbody></table><div></div></div></div>';

    } else { echo alert('danger', 'Введены неверные данные'); } }

# Next

if(isset($_POST['groupinfo'])){
    $id = $_POST['id'];
    $json = curl('groups.getById?group_id='.$id.'&fields=photo_100,verified,status,screen_name');
    if($json['response'][0]['deactivated']){ echo alert('danger', 'Группа удалена или заблокирована'); } elseif($json['response']){
    if(!$json['response'][0]['status']) { $status = 'не указан'; } else { $status = $json['response'][0]['status']; }
    if($json['response'][0]['verified'] == 1){ $verified = '<i class="fa fa-check font-blue"></i>'; }
    echo '<div class="col-md-12 animated fadeInUp">
    <div class="portlet light portlet-fit portlet-form bordered" id="form_wizard_1">
    <div class="portlet-title"><div class="caption">
    <span class="caption-subject font-dark">'.$json['response'][0]['name'].' '.$verified.'</span>
    </div></div><div class="portlet-body"><div class="form-body">
    <img style="float:right;" src="'.$json['response'][0]['photo_100'].'">
    <div class="row"><div class="col-md-10"><table class="table"><tbody>
    <tr><th>Тип группы:</th><td>'.$json['response'][0]['type'].'</td></tr>
    <tr><th>Статус:</th><td>'.$status.'</td></tr>
    <tr><th>Домен:</th><td>vk.com/'.$json['response'][0]['screen_name'].'</td></tr>
    </tbody></table><div></div></div></div>';
    } else { echo alert('danger', 'Введены неверные данные'); }
}

# Next

if(isset($_POST['banspisok'])){
	$user_id = $_POST['id'];
	$xml = simplexml_load_file('https://api.vk.com/method/friends.get.xml?user_id='.$user_id.'&count=1000&fields=photo'); $uid = $xml->user->uid;
	if(!$uid) {alert('danger','Ошибка, проверьте ваши данные!</div>'); } else {
	echo '<div class="col-md-12 animated fadeInUp"><div class="portlet light portlet-fit portlet-form bordered"><div class="portlet-title"><div class="caption"><span class="caption-subject font-dark sbold uppercase">Список удаленных и заблокированных друзей</span></div></div><div class="portlet-body"><div class="form-body"><div class="table-scrollable"><table class="table table-hover"><tbody>';
	for ($i = 0; $i < count($uid); $i++) { $xml2 = simplexml_load_file('https://api.vk.com/method/users.get.xml?user_ids='.$uid[$i].'&fields=photo&lang=ru');
	if(!count($xml->user->deactivated) == 0) {
	alert('danger','Ошибка, проверьте ваши данные!</div>');
	} else { foreach ($xml->user as $artist) {
	if($artist->deactivated == 'deleted') { $name = $artist->first_name; $lname = $artist->last_name; $photo = $artist->photo; $idik = $artist->uid;
	echo'<tr><td><a href="http://vk.com/id'.$idik.'" target="blank_" style="color: #666;">'.$name.' '.$lname.'</a></td> <td>Удалён</td> <td><img src="'.$photo.'" style="float:right; width: 20px; border-radius: 10px;"></td></tr>';
	} elseif($artist->deactivated == 'banned') { $idik = $artist->uid; $name = $artist->first_name; $lname = $artist->last_name; $photo = $artist->photo;
	echo'<tr><td><a href="http://vk.com/id'.$idik.'" target="blank_" style="color: #666;">'.$artist->first_name.' '.$artist->last_name.'</a></td> <td>Заблокирован</td> <td><img src="'.$artist->photo.'" style="float:right; width: 20px; border-radius: 10px;"></td></tr>'; }}}}
echo '</tbody></table></div></div></div></div></div>'; }
}

# Next Curl/FunctionsForApi
function cloudflare($method, $url, $param) {
	include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_VERBOSE, 1);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $cfhead);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $param);
	$response = curl_exec($ch);
	$json = json_decode($response, true);
	if($json['errors'][0]['message']) {
		return $json['errors'][0];
	} else {
		return $json;
	}
}

function alert($type, $text, $not12){
if($not12 != 1) { $md12 = 'col-md-12'; }
    return '
	<div class="'.$md12.' animated fadeInUp">
	<div class="alert alert-dismissable alert-'.$type.'">
	<div class="btn-group" style="float:right;" data-dismiss="alert" aria-hidden="true">
	<a class="fa fa-times-circle"></a></div>'.$text.'</div></div>
	';
}

function flood_control(){
	session_start();
	if($_SESSION['last_request'] > time() - 1){ $_SESSION['banned'] = 1; }

	if($_SESSION['banned'] == 1) {
	if(!$_SESSION['ban_time']){ $_SESSION['ban_time'] = time(); }
	if($_SESSION['ban_time'] < time() - 10 ){
	  unset($_SESSION['banned']);
		unset($_SESSION['ban_time']);
	  return true;
	}
  $time = time() - $_SESSION['ban_time'];
	if($time != 0){ $getflood='. Прошло: '.$time.' сек.'; }
	die(alert('danger', 'Flood Control: Функционал сайта ограничен на 10 секунд'.$getflood.''));
	} $_SESSION['last_request'] = time();
}

/*

die('
<div tabindex="-1" class="modal fade bs-modal-sm in" id="checkRecap" aria-hidden="true" style="display: block; padding-right: 17px;">
<div class="modal-dialog modal-sm">
<div class="modal-content"><div class="modal-header">
<h4 class="modal-title">Подтвердите что вы не робот</h4></div>
<div class="modal-body"><center><div id="captchap">
<img src="/data/secpic.php"></div></center>
<div class="form-group form-md-line-input form-md-floating-label has-info">
<input type="text" class="form-control" name="recap" id="form_control_1">
<label for="form_control_1">Код с картинки</label>
</div><center><button class="btn green" type="button" data-dismiss="modal">Отправить</button></center>
</div></div></div></div>
');

*/

function curl($method) {
	$ch = curl_init('https://api.vk.com/method/'.$method);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
	curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
	$response = curl_exec($ch); curl_close($ch);
	$json = json_decode($response, true);
	return $json;
}
