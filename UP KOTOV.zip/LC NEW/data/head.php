<?
	session_start();
	include($_SERVER['DOCUMENT_ROOT'].'/data/global.php');
	$global = new systems;
	$global->security();
	$global->online();
	#Слил скрипт: vk.com/one.user  // Крч Котов собственной персоны.
?>
<!DOCTYPE html>
<html lang="ru" class="no-js">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title><?=$title;?></title>
  <meta content="width=device-width, initial-scale=0.7" name="viewport" />

  <meta http-equiv="pragma" content="no-cache"/>
  <meta name="theme-color" content="#00bbd3">
  
    <meta name="description" content="<? echo $site['desc']; ?>">
	<meta name="keywords" content="<? echo $site['tags']; ?>">  
	<meta name="author" content="vk.com/flazzerr">

  <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet" type="text/css"/>
  <script src="/resources/css/pace.min.js" type="text/javascript"></script>
  <link href="/resources/css/pace-theme-minimal.css" rel="stylesheet" type="text/css"/>
  <link href="/resources/css/progress_bar.css" rel="stylesheet" type="text/css"/>
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
  <link href="/resources/css/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css"/>
  <link href="/resources/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
  <link href="/resources/css/uniform/css/uniform.default.css" rel="stylesheet" type="text/css"/>
  <link href="/resources/css/components-themes-md.css" rel="stylesheet" type="text/css"/>
  <link href="/resources/css/plugins-md.css" rel="stylesheet" type="text/css"/>
  <link href="/resources/css/page-layouts.css" rel="stylesheet" type="text/css"/>
  <link href="/resources/css/themes/cyan.css" rel="stylesheet" type="text/css" />
  <script src="/resources/js/jquery.min.js" type="text/javascript"></script>
  <script src='https://www.google.com/recaptcha/api.js'></script>
  <link id="icon" rel="shortcut icon" href="/resources/images/favicon.png"/>
</head> 

<body id="all" class="page-header-fixed page-quick-sidebar-over-content page-sidebar-closed-hide-logo page-container-bg-blue">

<body class="page-md page-header-fixed page-sidebar-closed-hide-logo">
  <div class="page-header md-shadow-z-1-i navbar navbar-fixed-top">
    <div class="page-header-inner">
      <div class="page-logo">
	  <a href="/">KOTOV</a>
	  <div class="menu-toggler sidebar-toggler"></div></div>
	  <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse"></a>
        		    	<?
						$sys = $menu['sys']; $usr = $menu['usr']; $stas = $menu['stas'];
						if(isset($_SESSION['uid'])) { $admsql = $mysqli->query('SELECT * FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"')->fetch_array(); $admin = $admsql['who']; }
						$lvl5 = '<li class="mega-menu mega-menu-full hover-initialized waves-effect '.$sys.'" data-hover="megamenu" data-close-others="true"><a href="/data/admin.php?system" class="dropdown-toggle hover-initialized" data-hover="megamenu-dropdown" data-close-others="true">Управление сайтом</a></li>';
						$lvl4 = '<li class="mega-menu mega-menu-full hover-initialized waves-effect '.$usr.'" data-hover="megamenu" data-close-others="true"><a href="/data/admin.php?users&page=1" class="dropdown-toggle hover-initialized" data-hover="megamenu-dropdown" data-close-others="true">Пользователи</a></li><li class="mega-menu mega-menu-full hover-initialized waves-effect '.$stas.'" data-hover="megamenu" data-close-others="true"><a href="/data/admin.php?statistics" class="dropdown-toggle hover-initialized" data-hover="megamenu-dropdown" data-close-others="true">Статистика</a></li>';
						$lvl3 = '<li class="classic-menu-dropdown"><a data-toggle="dropdown" href="javascript:;">Скрипты <i class="fa fa-angle-down"></i></a><ul class="dropdown-menu pull-left ">
						<li><a href="/pages/files.php?p"><i class="fa fa-commenting-o"></i> Статусы </a></li><li><a href="/pages/files.php?d"><i class="fa fa-file-zip-o"></i> Прочие </a></li></ul></li>';
						echo '<div class="hor-menu hidden-xs hidden-sm"><ul class="nav navbar-nav">';
						if($admin==5){ echo $lvl5.$lvl4.$lvl3; }elseif($admin==4){ echo $lvl4.$lvl3; }elseif($admin==3){ echo $lvl3; }
						echo '</ul></div>';
						?>           
		   <div class="page-top">
			
	<div class="hor-menu hor-menu-light hidden-xs"></div>


	    	<?
	if(isset($_SESSION['uid'])) {
	$getUser = $mysqli->query('SELECT * FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"')->fetch_array();
	$first_name = $getUser['first_name'];
	$last_name = $getUser['last_name'];
	$photo = $getUser['photo'];
	$profile = $getUser['profile'];
	$money = $getUser['money'];
	        ?>

			<? /* ЭТА КАТОВ СУ4КА  */?>
        <div class="top-menu">
        <ul class="nav navbar-nav pull-right">
            			 <li class="dropdown dropdown-user <?=$bd;?>">
                      <a href="/" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true" aria-expanded="false">
                        <img alt="" class="img-circle" src="<?=$photo;?>">
			            <span class="username"> <?=$first_name.' '.$last_name; ?></span>
                              <i class="fa fa-angle-down"></i>
                                </a>
			    <ul class="dropdown-menu dropdown-menu-default"><li><a href="/id<?=$id;?>"><i class="icon-user"></i> Профиль </a></li>
				<li><a href="/pages/wallet.php"><i class="icon-wallet"></i> Магазин<span class="badge badge-danger"> <?=$money;?> </span></a></li>
				<li><a href="https://vk.com/id<?=$profile;?>"><i class="fa fa-vk"></i> Вконтакте </a></li>
				<li><a href="/act?logout" data-toggle="modal"><i class="fa fa-align-right"></i> Выход </a></li>
        </div>
		</ul>
	</ul>
</div> 
</div>
   <? } else { ?>
      <div class="page-top">
        <div class="top-menu">
        <ul class="nav navbar-nav pull-right" style="margin-top: 10%"> 
		<a class="btn blue btn-circle animated shake" href="/data/auth.php"><i class="fa fa-vk"></i> Авторизация</a> 
		</ul>    
		</div>
		</ul>
	</ul>
</div>
      </div>
    </div>
   <? } ?>
  </div><div class="clearfix"></div>
  <div class="page-container">
    <div class="page-sidebar-wrapper">
      <div class="page-sidebar md-shadow-z-2-i navbar-collapse collapse">
        <ul class="page-sidebar-menu " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200">
          <li class="<?=$menu['home'];?>"><a href="/"><i class="fa fa-tv"></i><span class="title"> Главная</span><span class="<? echo $span['home']; ?> title"></span></a></li>
          <li class="<?=$menu['help'];?>"><a href="/pages/help.php"><i class="fa fa-info-circle"></i><span class="title"> Помощь</span></a></li>
          <li class="<?=$menu['api'];?>"><a href="/pages/api_vk.php"><i class="fa fa-vk"></i><span class="title"> API Вконтакте</span></a></li>
          <li class="">
		<li class="nav-item <?=$menu['set'];?>">
			<a href="#autoSet" class="nav-link nav-toggle waves-effect"><i class="fa fa-database"></i>
			<span class="title">Установка</span>
			<span class="<? if($span['set'] == 'arrow open'){ echo 'arrow open'; } else { echo 'arrow'; } ?>"></span>
		</a>
		<ul class="sub-menu" style="<?=$style['set'];?>">
			<?
				$menuarray = array(
				array('link' => '/autoSet/avtostatus.php', 'icon' => 'fa fa-commenting-o', 'name' => 'Авто-Статус'),
				array('link' => '/autoSet/avtostatus_group.php', 'icon' => 'fa fa-comments-o', 'name' => 'Авто-Статус в группу'),
				array('link' => '/autoSet/liker.php', 'icon' => 'fa fa-heart', 'name' => 'Лайкер'),
				array('link' => '/autoSet/online.php', 'icon' => 'fa fa-clock-o', 'name' => 'Вечный онлайн'),
				array('link' => '/autoSet/func.php', 'icon' => 'fa fa-cogs', 'name' => 'Функции'));
				for($i=0; $i < count($menuarray); $i++){
					echo '<li><a href="'.$menuarray[$i]['link'].'"><i class="'.$menuarray[$i]['icon'].'"></i> '.$menuarray[$i]['name'].'</a></li>';
				}
			?>
	  </ul></li>
          <li class="">
		  <?
	$stats = $mysqli->query('SELECT COUNT(*) as count FROM `stats`')->fetch_array()[0];
	$scripts = $mysqli->query('SELECT COUNT(*) as count FROM `script`')->fetch_array()[0];
	$heh = $stats + $scripts; if($heh > 0) {
	}		?>
            <a><span class="arrow"></span><i class="fa fa-file-code-o"></i><span class="title"> Скрипты</span></a>
              <ul class="sub-menu">
                <li><a href="/pages/files.php?stats">Авто-Статусы</a></li>
                <li><a href="/pages/files.php?scripts">Прочие скрипты</a></li>
              </ul>
          </li>
        </ul>
      </div>
    </div>
  <script>reqapi='/data/api.php';</script>

  <div class="page-content-wrapper">
    <div class="page-content animated fadeInUp">
  <div id="pageinfo"></div>
  <? /* Увидомление чито ты первый раз зашел */ ?> 
<div id="pages" class="animated fadeInUp"> 
<? $global->firstreg(); ?> 
<? /* один раз не пидорас.. шучу */ ?>
  <script>
  jQuery(document).ready(function(){
      Backbones.init();
      Layout.init();
      Demo.init();
      Index.init();
  });
  </script>
<? /* Котов ебать  */ ?>
</html>