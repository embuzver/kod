<? try { 
$secret = ''; 
$recode = ''; 
$host='site.ru';
$cfhead = array('X-Auth-Email: параша@gmail.com', 'X-Auth-Key: ', 'Content-Type: application/json');
$mysqli = new mysqli('localhost', 'username', 'password', 'namebase');
$mysqli->query('SET NAMES utf8'); $site = $mysqli->query('SELECT * from `site`')->fetch_array();
$metrica_id = $site['metrica_id']; $metrica_token = $site['metrica_token'];

if($mysqli->connect_errno) { throw new mysqli_sql_exception("<center>Ошибка подключения<br><br>Код ошибки: #".$mysqli->connect_errno."<br>".$mysqli->connect_error."</center>"); }
} catch(mysqli_sql_exception $e) { echo $e->getMessage(); exit(); }

#Получить токен приложения: https://oauth.yandex.ru/authorize?response_type=token&client_id=ИД_ПРИЛОЖЕНИЯ&client_secret=ПАРОЛЬ_ПРИЛОЖЕНИЯ
