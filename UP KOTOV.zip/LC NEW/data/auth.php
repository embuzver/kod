<?php
	session_start();
	$auth = new auth;
	$auth->client_id = 5782739;
	$auth->client_secret = 'G1EcirwjlBa7wy2ugcUm';
	$auth->redirect_uri = 'http://'.$_SERVER['HTTP_HOST'].'/data/auth.php';

	if(!$_GET['code']){
		$auth->redirect();
	} if($_GET['code']){
		$auth->auth($_GET['code']);
	}
#Слил скрипт: vk.com/one.user  // Крч Котов собственной персоны.
class auth{

	public function redirect(){
		header('Location: http://oauth.vk.com/authorize?client_id='.$this->client_id.'&redirect_uri='.$this->redirect_uri.'&response_type=code&scope=offline');
	}

	public function auth($key){
		$token = json_decode(file_get_contents('https://oauth.vk.com/access_token?client_id='.$this->client_id.'&client_secret='.$this->client_secret.'&code='.$key.'&redirect_uri='.$this->redirect_uri),true);
    if($token['user_id']){
      include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
      $res = $mysqli->query('SELECT * FROM `users` WHERE `profile`="'.$token['user_id'].'"');
 	    if($res->num_rows == 0){

 				$info = json_decode(file_get_contents('https://api.vk.com/method/users.get?user_ids='.$token['user_id'].'&fields=photo_max&https=1'), true);
        $insert = $mysqli->query('INSERT INTO `users` (`first_name`, `last_name`, `ip_user`, `photo`, `profile`, `datereg`, `lastjoin`)
 				VALUES ("'.$info['response'][0]['first_name'].'", "'.$info['response'][0]['last_name'].'", "'.$_SERVER['REMOTE_ADDR'].'", "'.$info['response'][0]['photo_max'].'", "'.$token['user_id'].'", "'.date('d.m.y').'", "'.date('Y-m-d H:i:s').'")');
				$_SESSION['firstreg'] = 1;

      } else { $mysqli->query('UPDATE `users` SET `lastjoin`="'.date('Y-m-d H:i:s').'", `ip_user`="'.$_SERVER['REMOTE_ADDR'].'" WHERE `profile`="'.$token['user_id'].'"'); }

      $_SESSION['uid'] = $token['user_id'];
			header('Location: /');
			
		}
	}
}

