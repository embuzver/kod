<? include($_SERVER['DOCUMENT_ROOT'].'/data/router.php');
   if(!isset($_SESSION['uid'])) { echo '<div class="col-md-12"><div class="alert alert-danger alert-dismissable">Для использования данного раздела нужно авторизироваться</div></div>'; } else {?>
<input type="hidden" id="likerSet" name="likerSet" value="likerSet">
<input type="hidden" id="likerDel" name="likerDel" value="likerDel">

<div id="info"></div>
<div class="col-md-12 animated fadeIn">
<div class="portlet light">
<div class="portlet-title tabbable-line">
<div class="caption">
<i class="icon-bubbles font-dark hide"></i>
<span class="caption-subject font-dark uppercase">Лайкер V2 (Всего установило: <? $count = $mysqli->query('SELECT COUNT(*) as count FROM `liker`')->fetch_row(); echo $count[0];  ?>)</span></div>
<ul class="nav nav-tabs">
<li class="active"><a aria-expanded="true" href="#portlet_tab2_2" data-toggle="tab">Установка</a></li>
<li><a aria-expanded="false" href="#portlet_tab2_1" data-toggle="tab">Удаление</a></li>
</ul></div>
<div class="portlet-body">
<div class="tab-content"><div class="tab-pane" id="portlet_tab2_1">
<li class="list-group-item"><b>1.</b> Получаем <b>access_token</b> тут: </li>
<li class="list-group-item"><center><button type="button" class="btn btn-minw btn btn-circle btn-square btn-info" onclick="window.open('http://oauth.vk.com/authorize?client_id=4986954&scope=wall,offline&redirect_uri=http://api.vk.com/blank.html&display=page&response_type=token')">Токен</button></center></li>
			<li class="list-group-item">
				<div class="form-group form-md-line-input has-info form-md-floating-label">
					<div class="input-group left-addon">
						<span class="input-group-addon">
							<i class="fa fa-key"></i>
						</span>
						<input type="text" name="tokenE" id="tokenE" class="form-control">
						<label for="form_control_1">ACCESS_TOKEN</label>
					</div>
				</div>
			</li>
				<li class="list-group-item">
					<b>2.</b> Подтвердите что Вы не робот
				</li>
			<li class="list-group-item"><center>
			<div id="captchap1">
			<img src="/data/secpic.php"></div></center></li>
				<li class="list-group-item">
					<div class="form-group form-md-line-input has-info form-md-floating-label">
						<div class="input-group">
							<div class="input-group-control">
								<input name="captcha1" class="form-control" id="captcha1" type="text">
								<label for="form_control_1">Введите код с картинки</label>
							</div>
							<span class="input-group-btn btn-right">
								<button name="submit" class="btn btn-minw btn btn-circle btn-square btn-info waves-effect" id="submit" onclick="likerDel()" type="button" value="submit">Удаление</button>
							</span>
						</div>
					</div>
				</li><br>
			</div>
			<div class="tab-pane active" id="portlet_tab2_2">
				<div class="form-body">
					<li class="list-group-item">
						<b>1.</b> Получите свой <b>ACCESS_TOKEN</b> от приложения:
					</li>
					<li class="list-group-item">
						<center>
						<button type="button" class="btn btn-minw btn btn-circle btn-square btn-info" onclick="window.open('https://oauth.vk.com/authorize?client_id=3087106&amp;scope=wall,offline&amp;redirect_uri=https://api.vk.com/blank.html&amp;display=page&amp;response_type=token')">Токен</button></center>
					</li>
			<li class="list-group-item">
				<div class="form-group form-md-line-input has-info form-md-floating-label">
					<div class="input-group left-addon">
						<span class="input-group-addon">
							<i class="fa fa-key"></i>
						</span>
						<input type="text" name="token" id="token" class="form-control">
						<label for="form_control_1">ACCESS_TOKEN</label>
					</div>
				</div>
			</li>
				<li class="list-group-item">
					<b>2.</b> Подтвердите что Вы не робот
				</li>
			<li class="list-group-item"><center>
			<div id="captchap">
			<img src="/data/secpic.php"></div></center></li>
					<li class="list-group-item">
						<div class="form-group form-md-line-input has-info form-md-floating-label">
							<div class="input-group">
								<div class="input-group-control">
									<input name="captcha" class="form-control" id="captcha" type="text">
									<label for="form_control_1">Введите код с картинки</label>
								</div>
								<span class="input-group-btn btn-right">
								<button name="submit" class="btn btn-minw btn btn-circle btn-square btn-info waves-effect" id="submit" onclick="likerSet()" type="button" value="submit">Установка</button>
								</span>
							</div>
						</div>
					</li><br>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
<? } include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>
