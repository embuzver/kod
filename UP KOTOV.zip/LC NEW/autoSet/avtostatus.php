<? include($_SERVER['DOCUMENT_ROOT'].'/data/router.php'); $col= 11;
	 if (!isset($_SESSION['uid'])) { echo '<div class="col-md-12"><div class="alert alert-danger alert-dismissable">Для использования данного раздела нужно авторизироваться</div></div>'; } else {
	 if(!$_GET) { $count = $mysqli->query('SELECT COUNT(*) as count FROM `status`')->fetch_row(); ?>

<div id="info"></div>
<div class="col-md-12 col-sm-12 animated fadeIn">
<div class="portlet light ">
<div class="portlet-title tabbable-line">
<div class="caption">
<i class="icon-bubbles hide"></i>
<span class="caption-subject uppercase">Автостатусы (Всего установило: <?=$count[0];?>)</span></div>
<ul class="nav nav-tabs"><li class="active">
<a aria-expanded="true" href="#StatSet" data-toggle="tab">Установка</a></li><li>
<a aria-expanded="false" href="#StatDel" data-toggle="tab">Удаление</a></li><li>
<a aria-expanded="false" href="#StatEdt" data-toggle="tab">Редактирование</a></li></ul></div> 
<div class="portlet-body"><div class="tab-content">

<div class="tab-pane" id="StatDel">
<li class="list-group-item"><b>1.</b> Получаем <b>access_token</b> тут: </li>
<li class="list-group-item"><center><button type="button" class="btn btn-minw btn btn-circle btn-square btn-info" onclick="window.open('http://oauth.vk.com/authorize?client_id=4986954&scope=wall,offline&redirect_uri=http://api.vk.com/blank.html&display=page&response_type=token')">Токен</button></center></li>
<li class="list-group-item"><div class="form-group form-md-line-input has-info form-md-floating-label"><div class="input-group left-addon"><span class="input-group-addon">
<i class="fa fa-key"></i></span><input type="text" name="token" id="token" class="form-control"><label for="form_control_1">ACCESS_TOKEN</label></div></div></li>
<li class="list-group-item"><b>2.</b> Подтвердите что Вы не робот</li>
<li class="list-group-item"><center><div id="captchap"><img src="/data/secpic.php"></div></center></li>

<li class="list-group-item">
<div class="form-group form-md-line-input has-info form-md-floating-label">
<div class="input-group"><div class="input-group-control">
<input name="captcha" class="form-control" id="captcha" type="text">
<label for="form_control_1">Введите код с картинки</label></div><span class="input-group-btn btn-right">
<button name="submit" class="btn btn-minw btn btn-circle btn-square btn-info waves-effect" id="submit" onclick="StatusDel()" type="button" value="submit">Удаление</button>
</span></div></div></li><input type="hidden" id="StatusDel" name="StatusDel" value="StatusDel"></div>

<div class="tab-pane" id="StatEdt">
<li class="list-group-item"><b>1.</b> Получаем <b>access_token</b> тут: </li>
<li class="list-group-item"><center><button type="button" class="btn btn-minw btn btn-circle btn-square btn-info" onclick="window.open('http://oauth.vk.com/authorize?client_id=4986954&scope=wall,offline&redirect_uri=http://api.vk.com/blank.html&display=page&response_type=token')">Токен</button></center></li>
<li class="list-group-item">
<div class="form-group form-md-line-input has-info form-md-floating-label">
<div class="input-group left-addon">
<span class="input-group-addon">
<i class="fa fa-key"></i></span>
<input type="text" name="tokenE" id="tokenE" class="form-control">
<label for="form_control_1">ACCESS_TOKEN</label></div>
</div></li><li class="list-group-item">
<b>2.</b> Выберите статус.</li>

<li class="list-group-item">
<div class="form-group has-info form-md-line-input">
<select name="num" class="form-control" id="num">
<?for($i = $col; $i<=$col; --$i){
	if($i < 1){  break; }
	echo '<option value="'.$i.'">Статус №'.$i.'</option>';
} ?></select></div></li>

<li class="list-group-item">
<b>3.</b> Подтвердите что Вы не робот</li>
<li class="list-group-item"><center>
<div id="captchap1">
<img src="/data/secpic.php"></div></center></li>
<li class="list-group-item">
<div class="form-group form-md-line-input has-info form-md-floating-label">
<div class="input-group">
<div class="input-group-control">
<input name="captcha1" class="form-control" id="captcha1" type="text">
<label for="form_control_1">Введите код с картинки</label></div>
<span class="input-group-btn btn-right">
<button name="submit" class="btn btn-minw btn btn-circle btn-square btn-info waves-effect" id="submit" onclick="StatusEdit()" value="submit">Изменить</button>
</span></div></div></li><input type="hidden" id="StatusEdit" name="StatusEdit" value="StatusEdit"></div>

<div class="tab-pane active" id="StatSet"><div class="form-body">
<?for($i = $col; $i<=$col; --$i){
	if($i < 1){  break; }
/* TRUE КАДИР MODE ACTIVATED */
$count = $mysqli->query('SELECT COUNT(*) as count FROM `status` WHERE `status_id`="'.$i.'"')->fetch_row();
echo '<div class="portlet box blue-hoki"><div class="portlet-title"><div class="caption">Автостатус #'.$i.' </div>
<div class="actions"><div class="btn-group"><a class="btn btn-circle btn-default btn-sm" style="color: #FFFFFF">
<i style="color: #FFFFFF;" class="fa fa-cloud-download"></i> Установило:  '.$count[0].'</a>
</div></div></div><div class="portlet-body"><div class="table-responsive"><table class="table table-bordered"><tbody><tr>
<td class="web-inspector-hide-shortcut"><center><a class="waves-effect" href="/autoSet/avtostatus.php?id='.$i.'"><img src="/resources/img_site/status/status-'.$i.'.png"></a></center></td>
</tr></tbody></table></div></div></div>'; } ?> </div></div></div></div></div></div> <? } ?>



<? if(isset($_GET['id'])){ $stid = $_GET['id'];
if($_GET['id'] > $col) { die('<div class="col-md-12 animated fadeIn"><div class="alert alert-danger alert-dismissable">Данного автостатуса не существует!</div></div>'); }
if($_GET['id'] < 1) { die('<div class="col-md-12 animated fadeIn"><div class="alert alert-danger alert-dismissable">Данного автостатуса не существует!</div></div>'); }
$count = $mysqli->query('SELECT COUNT(*) as count FROM `status` WHERE `status_id`="'.$stid.'"')->fetch_row();
date_default_timezone_set('Europe/Moscow'); $time1=date("H:i");
date_default_timezone_set('Europe/Kiev'); $time2=date("H:i");
date_default_timezone_set('Asia/Almaty'); $time3=date("H:i");
date_default_timezone_set('Asia/Omsk'); $time4=date("H:i");
date_default_timezone_set('Asia/Yekaterinburg'); $time5=date("H:i");
date_default_timezone_set('Asia/Yakutsk'); $time6=date("H:i");
date_default_timezone_set('Europe/Madrid'); $time7=date("H:i");
date_default_timezone_set('Asia/Krasnoyarsk'); $time8=date("H:i");
date_default_timezone_set('Europe/Samara'); $time9=date("H:i");
date_default_timezone_set('Asia/Bishkek'); $time10=date("H:i"); ?>

<div id="info"></div>
<div class="col-md-12">
<div class="portlet light"><div class="portlet-title">
<div class="caption"><i class="icon-bubbles hide"></i>
<span class="caption-subject uppercase">Автостатус #<?=$stid; ?> (Установило: <?=$count[0];?>)</span>
</div></div><div class="portlet-body">

<li class="list-group-item"><center>Перед установкой прочтите <a href="/pages/help.php"> FAQ </a></center></li>

<li class="list-group-item">
<center><li class="list-group-item" style="display: none;"><select class="form-control" id="statusID" name="statusID"><option value="<?=$stid;?>"></option></select></li>
<img class="img-responsive" src="/resources/img_site/status/status-<?=$stid;?>.png"></center></li>

<li class="list-group-item"><b>1.</b> Получаем <b>access_token</b> тут: </li>
<li class="list-group-item"><center><button type="button" class="btn btn-minw btn btn-circle btn-square btn-info" onclick="window.open('http://oauth.vk.com/authorize?client_id=4986954&scope=wall,offline&redirect_uri=http://api.vk.com/blank.html&display=page&response_type=token')">Токен</button></center></li>
<li class="list-group-item">
<div class="form-group form-md-line-input has-info form-md-floating-label">
<div class="input-group left-addon"><span class="input-group-addon">
<i class="fa fa-key"></i></span>
<input type="text" name="token" id="token" class="form-control">
<label for="form_control_1">ACCESS_TOKEN</label></div></div></li>

<li class="list-group-item"><b>2</b>. Выберите часовой пояс</li>
<li class="list-group-item">
<div class="form-group has-info form-md-line-input">
<select class="form-control" id="city" name="city">
<option value="Europe/Moscow">Москва (Россия • Текущее время: <?=$time1;?>)</option>
<option value="Europe/Kiev">Киев (Украина • Текущее время: <?=$time2;?>)</option>
<option value="Asia/Almaty">Алматы (Азия • Текущее время: <?=$time3;?>)</option>
<option value="Asia/Omsk">Омск (Азия • Текущее время: <?=$time4;?>)</option>
<option value="Asia/Yekaterinburg">Екатеринбург (Азия • Текущее время: <?=$time5;?>)</option>
<option value="Asia/Yakutsk">Якутск (Азия • Текущее время: <?=$time6;?>)</option>
<option value="Europe/Madrid">Мадрид (Испания/Европа • Текущее время: <?=$time7;?>)</option>
<option value="Asia/Krasnoyarsk">Красноярск (Азия • Текущее время: <?=$time8;?>)</option>
<option value="Europe/Samara">Cамара (Европа • Текущее время: <?=$time9;?>)</option>
<option value="Asia/Bishkek">Казахстан/Астана (Азия • Текущее время: <?=$time10;?>)</option>
</select></div></li>

<li class="list-group-item"><b>3.</b> Подтвердите что Вы не робот</li>
<li class="list-group-item"><center><div id="captchap">
<img src="/data/secpic.php"></div></center></li><li class="list-group-item">
<div class="form-group form-md-line-input has-info form-md-floating-label">
<div class="input-group"><div class="input-group-control">
<input type="text" class="form-control" name="captcha" id="captcha">
<label for="form_control_1">Введите код с картинки</label></div>
<span class="input-group-btn btn-right">
<input type="hidden" id="StatusSet" name="StatusSet" value="StatusSet">
<button type="button" class="btn btn-minw btn btn-circle btn-square btn-info" name="submit" id="submit" value="submit" onclick="StatusSet()">Установка</button></span>
</div></div></li></div></div></div>
<? } } include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>
