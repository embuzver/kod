  <?
  include($_SERVER['DOCUMENT_ROOT'].'/data/router.php');
  $global->content(12, 'О сайте', '<li class="list-group-item text-center">Приветствуем в нашем сервисе.</li><li class="list-group-item text-center">На этом сайте вы с можете установить <div class="label label-info">«Авто-статусы»</div> или же <div class="label label-info">«Функции»</div> для вашей странички ВКонтакте.</li><li class="list-group-item text-center"><div class="label label-info">Снизу расположена информация и статистика сайта</div></li>');
  #Скачано с паблика: vk.com/archive.sites  / Зайди,ну рил годнота )
  ?>

  <?
  echo '<div id="inform"><div class="panel-heading summary-head text-center"><i class="fa fa-circle-o-notch fa-spin text-info"></i></div></div>';
  include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php');
  ?>

