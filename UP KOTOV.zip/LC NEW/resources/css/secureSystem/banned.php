<html><head>
<title>Access Denied</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="/resources/css/secureSystem/main.css"></head>
<body class="landing"><div id="page-wrapper"><header id="header" class="reveal alt"><h1> Доступ к сайту ограничен</h1></header>

<section id="banner"><h2>IAROUSE.ML</h2>
<p class="web-inspector-hide-shortcut">Доступ к сайту прекращён по причине: </p>
<ul class="actions"><li><a href="https://vk.com/iarousetop" class="button">Группа Вконтакте</a></li></ul></section>

<section id="main" class="container">
<section class="box special"><header class="major"><h2>Design by RektCore</h2></header>
<span class="image featured"></span></section></section></div>
<script src="/resources/css/secureSystem/jquery.min.js"></script>
<script src="/resources/css/secureSystem/jquery.dropotron.min.js"></script>
<script src="/resources/css/secureSystem/jquery.scrollgress.min.js"></script>
<script src="/resources/css/secureSystem/skel.min.js"></script>
<script src="/resources/css/secureSystem/util.js"></script>
<script src="/resources/css/secureSystem/main.js"></script>
</body></html>
