var interval = null;
var a = 'ОСТАНОВИТЕСЬ!';
var b = 'Эта функция браузера предназначена для разработчиков. Если кто-то сказал вам скопировать и вставить что-то здесь, для получения прав администрирования или что-то подобного, это мошенники. Выполнив эти действия, вы предоставите им доступ к своим данным.';
$(window).load(function() { $('#loader-container').delay(500).fadeOut('slow'); });
$(document).ready(function () {$('#inform').load('/data/info.php');});
function pageinfo() { $('#pageinfo').load('/data/global.php?information'); }
$(document).ready(function () { $('#pageinfo').load('/data/global.php?information');
interval = setInterval("pageinfo()", 4000); });

console.log("\n"); console.log("%c"+a,"font-family:Comic-Sans,Helvetica,Arial,sans-serif;font-size:50px;font-weight:bold;text-transform:uppercase;color:#ffa834;-webkit-text-stroke:2px #26b;");
console.log("\n"); console.log("%c"+b,"font-family:Comic-Sans,Helvetica,Arial,sans-serif;font-size:25px;");

toastr.options = {
	closeButton: true,
	showMethod: "fadeIn",
	positionClass: "toast-bottom-right",
	timeOut: 2000
};

function err(){
	console.log('Error Request');
	toastr.clear(); toastr.warning("Сервер недоступен", "Внимание");
} function gocap(){
	$('#captcha').val('').focus();
	$('#captcha1').val('').focus();
	$('#captchap').html('<img src="/data/secpic.php">');
	$('#captchap1').html('<img src="/data/secpic.php">');
	return false;
}

// LET'S GOOO

function StatusSet() {
	var StatusSet = $('#StatusSet')['val']();
	var captcha = $('#captcha')['val']();
  var statusID = $('#statusID')['val']();
	var city = $('#city')['val']();
	var token = $('#token')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({StatusSet: $("#StatusSet").val(), captcha: $("#captcha").val(), statusID: $("#statusID").val(), city: $("#city").val(), token: $("#token").val()}),
			success: function (data) {
			console.log('Sended request | StatusSet');
			setTimeout("gocap()", 1);
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}
function StatusDel() {
	var captcha = $('#captcha')['val']();
	var StatusDel = $('#StatusDel')['val']();
	var token = $('#token')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({captcha: $("#captcha").val(), StatusDel: $("#StatusDel").val(), token: $("#token").val()}),
			success: function (data) {
				console.log('Sended request | StatusDel');
				setTimeout("gocap()", 1);
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}
function StatusEdit() {
	var captcha1 = $('#captcha1')['val']();
	var StatusEdit = $('#StatusEdit')['val']();
	var tokenE = $('#tokenE')['val']();
	var num = $('#num')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({captcha1: $("#captcha1").val(),StatusEdit: $("#StatusEdit").val(),tokenE: $("#tokenE").val(),num: $("#num").val()}),
			success: function (data) {
				console.log('Sended request | StatusEdit');
				setTimeout("gocap()", 1);
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}

function likerSet() {
	var captcha = $('#captcha')['val']();
	var likerSet = $('#likerSet')['val']();
	var token = $('#token')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({captcha: $("#captcha").val(),likerSet: $("#likerSet").val(),token: $("#token").val()}),
			success: function (data) {
				console.log('Sended request | likerSet');
				setTimeout("gocap()", 1);
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}
function likerDel() {
	var captcha1 = $('#captcha1')['val']();
	var likerDel = $('#likerDel')['val']();
	var tokenE = $('#tokenE')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({captcha1: $("#captcha1").val(),likerDel: $("#likerDel").val(),tokenE: $("#tokenE").val(),}),
			success: function (data) {
				console.log('Sended request | likerDel');
				setTimeout("gocap()", 1);
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}

function GroupSet() {
	var captcha = $('#captcha')['val']();
	var GroupSet = $('#GroupSet')['val']();
	var token = $('#token')['val']();
	var group = $('#group')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({captcha: $("#captcha").val(),GroupSet: $("#GroupSet").val(),token: $("#token").val(),group: $("#group").val()}),
			success: function (data) {
				console.log('Sended request | GroupSet');
				setTimeout("gocap()", 1);
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}
function GroupDel() {
	var captcha1 = $('#captcha1')['val']();
	var GroupDel = $('#GroupDel')['val']();
	var tokenE = $('#tokenE')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({captcha1: $("#captcha1").val(),GroupDel: $("#GroupDel").val(),tokenE: $("#tokenE").val(),}),
			success: function (data) {
				console.log('Sended request | GroupDel');
				setTimeout("gocap()", 1);
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}
function OnlineSet() {
	var captcha = $('#captcha')['val']();
	var OnlineSet = $('#OnlineSet')['val']();
	var token = $('#token')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({captcha: $("#captcha").val(),OnlineSet: $("#OnlineSet").val(),token: $("#token").val(),}),
			success: function (data) {
				console.log('Sended request | OnlineSet');
				setTimeout("gocap()", 1);
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}
function OnlineDel() {
	var captcha1 = $('#captcha1')['val']();
	var OnlineDel = $('#OnlineDel')['val']();
	var tokenE = $('#tokenE')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({captcha1: $("#captcha1").val(),OnlineDel: $("#OnlineDel").val(),tokenE: $("#tokenE").val()}),
			success: function (data) {
				console.log('Sended request | OnlineDel');
				setTimeout("gocap()", 1);
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}
function FuncSet() {
	var captcha = $('#captcha')['val']();
	var FuncSet = $('#FuncSet')['val']();
	var token = $('#token')['val']();
	var friends_add = $('#friends_add')['val']();
	var friends_delete = $('#friends_delete')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({captcha: $("#captcha").val(),token: $("#token").val(),friends_add: $("#friends_add").val(),FuncSet: $("#FuncSet").val(),friends_delete: $("#friends_delete").val()}),
			success: function (data) {
				console.log('Sended request | FuncSet');
				setTimeout("gocap()", 1);
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}
function FuncDel() {
	var captcha1 = $('#captcha1')['val']();
	var FuncDel = $('#FuncDel')['val']();
	var tokenE = $('#tokenE')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({captcha1: $("#captcha1").val(),FuncDel: $("#FuncDel").val(),tokenE: $("#tokenE").val(),}),
			success: function (data) {
				console.log('Sended request | FuncDel');
				setTimeout("gocap()", 1);
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}

// PROFILE API
function profileDelFunc() {
	var goToFunc5 = $('#goToFunc5')['val']();
		$.ajax ({
			url: '/data/api.php',
			type: 'POST',
			cache: false,
        data: ({ goToFunc5: $("#goToFunc5").val() }),
			success: function (data) {
			console.log('Sended request | FuncDel from Profile');
				$('#funcinfo').html (data + "");
				$('#funcinfo').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
		});
	}
	function likerDelFunc() {
		var goToFunc6 = $('#goToFunc6')['val']();
			$.ajax ({
				url: '/data/api.php',
				type: 'POST',
				cache: false,
	        data: ({ goToFunc6: $("#goToFunc6").val() }),
				success: function (data) {
				console.log('Sended request | LikerDel from Profile');
					$('#likerinfo').html (data + "");
					$('#likerinfo').show ();
				},
				error: function (data) {
					setTimeout("err()", 1);
				}
			});
		}
function onlineDelFunc() {
	var goToFunc4 = $('#goToFunc4')['val']();
		$.ajax ({
			url: '/data/api.php',
			type: 'POST',
			cache: false,
        data: ({ goToFunc4: $("#goToFunc4").val() }),
			success: function (data) {
			console.log('Sended request | OnlineDel from Profile');
				$('#onlineinfo').html (data + "");
				$('#onlineinfo').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
		});
	}

function groupDelFunc() {
	var goToFunc3 = $('#goToFunc3')['val']();
		$.ajax ({
			url: '/data/api.php',
			type: 'POST',
			cache: false,
        data: ({ goToFunc3: $("#goToFunc3").val() }),
			success: function (data) {
			console.log('Sended request | GroupDel from Profile');
				$('#groupstatusinfo').html (data + "");
				$('#groupstatusinfo').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
		});
	}

function statusChange() {
	var goToFunc1 = $('#goToFunc1')['val']();
	var statusNum1 = $('#statusNum1')['val']();
		$.ajax ({
		beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
			url: '/data/api.php',
			type: 'POST',
			cache: false,
            data: ({goToFunc1: $("#goToFunc1").val(),statusNum1: $("#statusNum1").val(),}),
			success: function (data) {
			console.log('Sended request | StatusChange from Profile');
				$('#info').html (data + "");
				$('#info').show (); },
			error: function (data) {
				setTimeout("err()", 1);
			}
		});
	}
function statusDel() {
	var goToFunc2 = $('#goToFunc2')['val']();
		$.ajax ({
			url: '/data/api.php',
			type: 'POST',
			cache: false,
            data: ({ goToFunc2: $("#goToFunc2").val() }),
			success: function (data) {
			console.log('Sended request | StatusDel from Profile');
				$('#statusinfo').html (data + "");
				$('#statusinfo').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
		});
	}

function settingSet() {
	var settingSet = $('#settingSet')['val']();
	var captcha = $('#captcha')['val']();
		var set_name = $("#set_name").val ();
		var set_fam = $("#set_fam").val ();
		var img_ava = $("#img_ava").val ();
		$.ajax ({
		beforeSend: function() { $('#gg').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
			url: '/data/api.php',
			type: 'POST',
			cache: false,
			data: {captcha: $("#captcha").val(),set_fam: $("#set_fam").val(),set_name: $("#set_name").val(),img_ava: $("#img_ava").val(),settingSet: $("#settingSet").val()},
			success: function (data) {
			console.log('Sended request | Change Profile Settings');
				setTimeout("gocap()", 1);
				$('#gg').html (data + "");
				$('#gg').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
		});
	}

function AvaNewsSet() {
	var AvaNewsSet = $('#AvaNewsSet')['val']();
	var profile = $("#profile").val ();
    $['ajax']({
        type: 'POST',
        url: '/data/api.php',
        data: ({AvaNewsSet: $("#AvaNewsSet").val(),profile: $("#profile").val()}),
			success: function (data) {
			console.log('Sended request | Take New Avatar');
				$('#ava').html (data + "");
				$('#ava').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}

function getlinksc(id) {
	var scriptid = id;
	var getlinksc = $('#getlinksc')['val']();
    $['ajax']({
     type: 'POST',
     url: '/data/api.php',
     data: ({ scriptid: id, getlinksc: $("#getlinksc").val() }),
	 success: function (data) {
	     console.log('Sended request | GetLink');
	     $('#info'+id).html (data + "");
		 $('#info'+id).show ();
	 },
			error: function (data) {
				setTimeout("err()", 1);
			}
	});
}

function getlinkst(id) {
	var scriptid = id;
	var getlinkst = $('#getlinkst')['val']();
    $['ajax']({
     type: 'POST',
     url: '/data/api.php',
     data: ({ scriptid: id, getlinkst: $("#getlinkst").val() }),
	 success: function (data) {
		 console.log('Sended request | GetLink');
		 $('#info'+id).html (data + "");
		 $('#info'+id).show ();
	 },
			error: function (data) {
				setTimeout("err()", 1);
			}
	});
}

function buyHidden() {
	var hiddenBuy = $('#hiddenBuy')['val']();
    $['ajax']({
        type: 'POST',
        url: '/data/api.php',
        data: ({ hiddenBuy: $("#hiddenBuy").val() }),
			success: function (data) {
				console.log('Sended request | Buy HiddenProfile');
				$('#thxHidden').html (data + "");
				$('#thxHidden').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}

function buyVerify() {
	var verifyBuy = $('#verifyBuy')['val']();
    $['ajax']({
        type: 'POST',
        url: '/data/api.php',
        data: ({ verifyBuy: $("#verifyBuy").val() }),
			success: function (data) {
				console.log('Sended request | Buy Verify');
				$('#thxVerify').html (data + "");
				$('#thxVerify').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}

function buyMLG() {
	var mlgBuy = $('#mlgBuy')['val']();
    $['ajax']({
        type: 'POST',
        url: '/data/api.php',
        data: ({ mlgBuy: $("#mlgBuy").val() }),
			success: function (data) {
				console.log('Sended request | Buy MLG');
				$('#thxMLG').html (data + "");
				$('#thxMLG').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}

// API VKONTAKTE
function WallVk() {
	var WallVk = $('#WallVk')['val']();
    var owner_id = $('#owner_id')['val']();
	var message = $('#message')['val']();
	var token = $('#token')['val']();

	var docs = $('#docs')['val']();
	var friendsOnly = $('input[id="friendsOnly"]:checked')['val']();
	var onGroupWall = $('input[id="onGroupWall"]:checked')['val']();
	var fromGroup = $('input[id="fromGroup"]:checked')['val']();

    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({WallVk: $("#WallVk").val(), owner_id: $("#owner_id").val(), message: $("#message").val(), token: $("#token").val(), friendsOnly: friendsOnly, onGroupWall: onGroupWall, fromGroup: fromGroup, docs: $("#docs").val()}),
			success: function (data) {
				console.log('Sended request | WallOff');
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}
function checkToken() {
	var checkToken = $('#checkToken')['val']();
    var token = $('#token')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({checkToken: $("#checkToken").val(),token: $("#token").val()}),
			success: function (data) {
				console.log('Sended request | Check Token');
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}
function DataReg() {
	var DataReg = $('#DataReg')['val']();
    var id = $('#id')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({DataReg: $("#DataReg").val(),id: $("#id").val()}),
			success: function (data) {
				console.log('Sended request | Profile Data Reg');
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}
function delrequ() {
	var delrequ = $('#delrequ')['val']();
    var token = $('#token')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({delrequ: $("#delrequ").val(),token: $("#token").val()}),
			success: function (data) {
				console.log('Sended request | Delete Requests');
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}
function friends() {
	var friends = $('#friends')['val']();
    var uid = $('#uid')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({friends: $("#friends").val(),uid: $("#uid").val()}),
			success: function (data) {
				console.log('Sended request | Give All Friends');
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}
function user_ban() {
	var user_ban = $('#user_ban')['val']();
    var token = $('#token')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({user_ban: $("#user_ban").val(),token: $("#token").val()}),
			success: function (data) {
				console.log('Sended request | User Ban by Token');
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}
function status() {
	var status = $('#status')['val']();
    var token = $('#token')['val']();
	var text = $('#text')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({status: $("#status").val(),token: $("#token").val(),text: $("#text").val()}),
			success: function (data) {
				console.log('Sended request | Change Status');
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}
function url_vk() {
    var url_vk = $('#url_vk')['val']();
    var url = $('#url')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({url_vk: $("#url_vk").val(),url: $("#url").val()}),
			success: function (data) {
				console.log('Sended request | Check URL');
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}
function longid() {
	var longid = $('#longid')['val']();
    var id = $('#id')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({longid: $("#longid").val(),id: $("#id").val()}),
			success: function (data) {
				console.log('Sended request | Give LongID');
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}
function userinfo() {
	var userinfo = $('#userinfo')['val']();
    var id = $('#id')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({userinfo: $("#userinfo").val(),id: $("#id").val()}),
			success: function (data) {
				console.log('Sended request | UserInfo');
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}
function groupinfo() {
	var groupinfo = $('#groupinfo')['val']();
    var id = $('#id')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({groupinfo: $("#groupinfo").val(),id: $("#id").val()}),
			success: function (data) {
				console.log('Sended request | GroupInfo');
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}
function banspisok() {
	var banspisok = $('#banspisok')['val']();
    var id = $('#id')['val']();
    $['ajax']({
	beforeSend: function() { $('#info').html('<div class="col-md-12 animated fadeIn"><div class="alert alert-dismissable alert-primary"> <i class="fa fa-refresh fa-spin"></i> Загрузка, пожалуйста подождите</div></div>'); },
        type: 'POST',
        url: '/data/api.php',
        data: ({banspisok: $("#banspisok").val(),id: $("#id").val()}),
			success: function (data) {
				console.log('Sended request | Give Banned Friends');
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				setTimeout("err()", 1);
			}
    });
}
