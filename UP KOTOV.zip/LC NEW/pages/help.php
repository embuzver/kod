<?
  include($_SERVER['DOCUMENT_ROOT'].'/data/router.php');
  $global->content(12, 'Помощь по сайту', '
  <div class="panel panel-default">
  <div class="panel-heading"><h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion1" href="#collapse_1" aria-expanded="false">1. Что такое токен? </a></h4></div>
  <div id="collapse_1" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;"><div class="panel-body">Это часть ссылки от <code>access_token=</code> до <code>&amp; </code></div>
  </div></div>

  <div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title">
  <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion1" href="#collapse_2" aria-expanded="false">2. Где взять токен? </a></h4>
  </div><div id="collapse_2" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
  <div class="panel-body">Получить токен можно по этой <button type="button" class="btn btn-info btn-xs" href="http://vk.cc/2r7WXp">ссылке</button>
  </div></div></div>

  <div class="panel panel-default"><div class="panel-heading"><h4 class="panel-title">
  <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion1" href="#collapse_3" aria-expanded="false"> 3. У меня не рабочий токен, что делать? </a>
  </h4></div><div id="collapse_3" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;"><div class="panel-body">Зайдите <button type="button" class="btn btn-info btn-xs" href="https://vk.com/apps?act=settings">сюда</button> и удалите все приложения, после этого получите токен.
  </div></div></div>', 'info-circle');

  include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php');
?>
