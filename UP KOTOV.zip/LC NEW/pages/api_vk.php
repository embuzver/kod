<?
  include($_SERVER['DOCUMENT_ROOT'].'/data/router.php');
  $global->content(12, 'API Вконтакте', '
  <a class="list-group-item text-center" href="/pages/api/wall.php">Пишем через официальное приложение</a>
  <a class="list-group-item text-center" href="/pages/api/data.php">Узнай сколько дней ВКонтакте</a>
  <a class="list-group-item text-center" href="/pages/api/del_request.php">Удаляем исходящие заявки</a>
  <a class="list-group-item text-center" href="/pages/api/checkToken.php">Чекер токена</a>
  <a class="list-group-item text-center" href="/pages/api/friends.php">Узнаем список друзей</a>
  <a class="list-group-item text-center" href="/pages/api/user_ban.php">Баним пользователя по токену</a>
  <a class="list-group-item text-center" href="/pages/api/status.php">Смена статуса / Чекер капчи в статусе</a>
  <a class="list-group-item text-center" href="/pages/api/cheker_link.php">Чекнуть ссылку</a>
  <a class="list-group-item text-center" href="/pages/api/longid.php">Длинный ID</a>
  <a class="list-group-item text-center" href="/pages/api/groupinfo.php">Информация о группе</a>
  <a class="list-group-item text-center" href="/pages/api/userinfo.php">Информация о пользователях</a>
  <a class="list-group-item text-center" href="/pages/api/banspisok.php">Список забаненых друзей</a>', 'vk');
  include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php');
?>
