<? include($_SERVER['DOCUMENT_ROOT'].'/data/router.php'); ?>

<div class="col-md-12">
<?
if(isset($_SESSION['uid'])) {
	$genx = $mysqli->query('SELECT * FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"')->fetch_array();
	$who = $genx['who'];
	$name = $genx['first_name'];
	$surname = $genx['last_name'];
} if($who > 2) { $date = date('d.m.y');
/* Проверяем админку */

//Управление дифферентами
if(isset($_GET['adds1'])){
if(isset($_POST['add']) && isset($_POST['com'])){ $com = htmlspecialchars($_POST['com']);

if($_POST['nonimg'] != true){
if($_FILES["goimage"]["size"] > 1024*3*1024) { echo 'Размер файла превышает 3 мегабайта'; exit; }
if(is_uploaded_file($_FILES["goimage"]["tmp_name"])) {
$extension = strtolower(substr(strrchr($_FILES['goimage']['name'], '.'), 1));
$filename = uniqid().'.'.$extension;
move_uploaded_file($_FILES["goimage"]["tmp_name"], $_SERVER['DOCUMENT_ROOT'].'/files/scripts/img/'.$filename);
$image = '/files/scripts/img/'.$filename; $success = true;
} else { $success = false; echo '<div class="col-md-12"><div class="alert alert-danger alert-dismissable">Ошибка загрузки изображения</div></div>'; }
} else { $success = true; $image = ''; }


if($_FILES["gofile"]["size"] > 1024*10*1024) { echo 'Размер файла превышает 10 мегабайт'; exit; }
if(is_uploaded_file($_FILES["gofile"]["tmp_name"])) {
$extension = strtolower(substr(strrchr($_FILES['gofile']['name'], '.'), 1));
$filename = uniqid().'.'.$extension;
move_uploaded_file($_FILES["gofile"]["tmp_name"], $_SERVER['DOCUMENT_ROOT'].'/files/scripts/'.$filename);
$file = '/files/scripts/'.$filename; $success1 = true;
} else { $success1 = false; echo '<div class="col-md-12"><div class="alert alert-danger alert-dismissable">Ошибка загрузки файла</div></div>'; }

if($success == true && $success1 == true) {
$mysqli->query('INSERT INTO `script` (`id`, `image`, `comment`, `link`, `date`, `byOwn`) VALUES("", "'.$image.'", "'.$com.'", "'.$file.'", "'.$date.'", "'.$_SESSION['uid'].'")');
echo '<div class="alert alert-info alert-dismissable">Успешно добавлено в базу</div></div>'; } }
?>
<form method="post" enctype="multipart/form-data">
<div class="col-md-12 animated fadeIn"><div class="portlet light bordered"><div class="portlet-title">
<div class="caption"><i class="icon-bar-chart font-dark hide"></i><span class="caption-subject font-dark uppercase">Добавление Скрипта</span></div></div>
<div class="portlet-body"><div class="form-body">

<div class="form-group form-md-line-input">
<label class="col-md-3 control-label" for="form_control_1">Коментарий</label>
<div class="col-md-9"><input type="text" class="form-control" placeholder="" name="com" id="com">
<div class="form-control-focus"> </div></div></div>

<div class="form-group form-md-line-input">
<label class="col-md-3 control-label" for="form_control_1">Фотография</label>
<div class="col-md-3"><input type="file" name="goimage" id="goimage"></input></div>
<div class="col-md-3"><input type="checkbox" id="nonimg" name="nonimg"> Нет фотографии?</input></div>
</div>

<div class="form-group form-md-line-input">
<label class="col-md-3 control-label" for="form_control_1">Файл</label>
<div class="col-md-9"><input type="file" name="gofile" id="gofile"></div></div>

</div><div class="form-actions"><div class="row"><div class="col-md-offset-3 col-md-9">
<br><button class="btn btn-minw btn-square btn-primary waves-effect" type="add" id="add" name="add">Добавить</button>
</div></div></div></div></div></div></form>
<? } if(isset($_GET['d'])) {
$check = $mysqli->query('SELECT * FROM `script` ORDER BY `id` DESC');
echo '<form method="post">
<div class="col-md-12 animated fadeIn"><li class="list-group-item"><center><a href="/pages/files.php?adds1" class="btn btn-minw btn-square btn-primary btn-circle">Добавить новый скрипт</a></center></li></div>
<div class="col-md-12"><div class="portlet light ">
<div class="portlet-title tabbable-line"><div class="caption">
<i class="icon-bubbles font-dark hide"></i>
<span class="caption-subject font-dark bold uppercase">Скрипты: Different</span></div></div>
<div class="portlet-body">
<div class="table-scrollable">
<table class="table table-striped table-bordered table-advance table-hover">
<thead><tr><th><center><i class="fa fa-bars"></i></center></th>
<th><i class="fa fa-cog"></i> Действия</th>
<th class=""><i class="fa fa-file-image-o"></i> Изображение</th>
<th class=""><i class="fa fa-comment-o"></i> Коментарий</th>
</tr></thead><tbody>';
while($row = $check->fetch_array()) {
$id = $row["id"];
$image = $row["image"];
$link = $row["link"];
$comment = $row["comment"];
$type = random(array('success', 'danger', 'info', 'warning'));
echo '
<tr id="info'.$id.'" class="wow fadeInUp"><td class="highlight">
<div class="'.$type.'"></div>
<a href="javascript:;">#'.$id.'</a></td>
<td><center><div id="com'.$id.'">
<a class="btn blue fa fa-edit btn-circle waves-effect" onclick="sendsc('.$id.');"> Редактировать</a>
<a class="btn red fa fa-times-circle btn-circle waves-effect" onclick="destroysc('.$id.');"> Удалить</a>
</div></center></td>
<td class=""><img src="'.$image.'" style="wight: auto; height: auto"></td>
<td class="">'.$comment.'</td></tr>';
} echo '</tbody></table></div></div></div></div>'; ?>
<input class="hidden" id="sendedit" name="sendedit" value="sendedit">
<input class="hidden" id="scriptedit" name="scriptedit" value="scriptedit">
<input class="hidden" id="scriptdel" name="scriptdel" value="scriptdel">
<script>
function sendsc(id) {
	Pace.restart()
	var scriptid = id;
	var sendedit = $('#sendedit')['val']();
    $['ajax']({
     type: 'POST',
     url: '/data/api.php',
     data: ({ scriptid: id, sendedit: $("#sendedit").val() }),
	 success: function (data) { $('#com'+id).html (data + ""); $('#com'+id).show (); },
			error: function (data) {
				toastr.options = {
				closeButton: false,
				progressBar: true,
				showMethod: "fadeIn",
				positionClass: "toast-bottom-right",
				timeOut: 2000 }; toastr.clear();
				toastr.warning("Сервер недоступен", "Внимание");
			} });
}
function editsc(id) {
	Pace.restart()
	var scriptid = id;
	var com = $('#com')['val']();
	var scriptedit = $('#scriptedit')['val']();
    $['ajax']({
     type: 'POST',
     url: '/data/api.php',
     data: ({ scriptid: id, scriptedit: $("#scriptedit").val(), com: $("#com").val() }),
	 success: function (data) { $('#com'+id).html (data + ""); $('#com'+id).show (); },
			error: function (data) {
				toastr.options = {
				closeButton: false,
				progressBar: true,
				showMethod: "fadeIn",
				positionClass: "toast-bottom-right",
				timeOut: 2000 }; toastr.clear();
				toastr.warning("Сервер недоступен", "Внимание");
			} });
}
function destroysc(id) {
	Pace.restart()
	var scriptid = id;
	var scriptdel = $('#scriptdel')['val']();
    $['ajax']({
     type: 'POST',
     url: '/data/api.php',
     data: ({ scriptid: id, scriptdel: $("#scriptdel").val() }),
	 success: function (data) { $('#info'+id).html (data + ""); $('#info'+id).show (); },
			error: function (data) {
				toastr.options = {
				closeButton: false,
				progressBar: true,
				showMethod: "fadeIn",
				positionClass: "toast-bottom-right",
				timeOut: 2000 }; toastr.clear();
				toastr.warning("Сервер недоступен", "Внимание");
			} });
}
</script>

<? }

//Управление статусами
if(isset($_GET['adds'])){
if(isset($_POST['add']) && isset($_POST['com'])){ $com = htmlspecialchars($_POST['com']);

if($_POST['nonimg'] != true){
if($_FILES["goimage"]["size"] > 1024*3*1024) { echo 'Размер файла превышает 3 мегабайта'; exit; }
if(is_uploaded_file($_FILES["goimage"]["tmp_name"])) {
$extension = strtolower(substr(strrchr($_FILES['goimage']['name'], '.'), 1));
$filename = uniqid().'.'.$extension;
move_uploaded_file($_FILES["goimage"]["tmp_name"], $_SERVER['DOCUMENT_ROOT'].'/files/scripts/img/'.$filename);
$image = '/files/scripts/img/'.$filename; $success = true;
} else { $success = false; echo '<div class="col-md-12"><div class="alert alert-danger alert-dismissable">Ошибка загрузки изображения</div></div>'; }
} else { $success = true; $image = ''; }

if($_FILES["gofile"]["size"] > 1024*10*1024) { echo 'Размер файла превышает 10 мегабайт'; exit; }
if(is_uploaded_file($_FILES["gofile"]["tmp_name"])) {
$extension = strtolower(substr(strrchr($_FILES['gofile']['name'], '.'), 1));
$filename = uniqid().'.'.$extension;
move_uploaded_file($_FILES["gofile"]["tmp_name"], $_SERVER['DOCUMENT_ROOT'].'/files/scripts/'.$filename);
$file = '/files/scripts/'.$filename; $success1 = true;
} else { $success1 = false; echo '<div class="col-md-12"><div class="alert alert-danger alert-dismissable">Ошибка загрузки файла</div></div>'; }

if($success == true && $success1 == true) {
$mysqli->query('INSERT INTO `stats` (`id`, `image`, `comment`, `link`, `date`, `byOwn`) VALUES("", "'.$image.'", "'.$com.'", "'.$file.'", "'.$date.'", "'.$_SESSION['uid'].'")');
echo '<div class="alert alert-info alert-dismissable">Успешно добавлено в базу</div></div>'; } }
?>
<form method="post" enctype="multipart/form-data">
<div class="col-md-12 animated fadeIn"><div class="portlet light bordered"><div class="portlet-title">
<div class="caption"><i class="icon-bar-chart font-dark hide"></i><span class="caption-subject font-dark uppercase">Добавление Статуса</span></div></div>
<div class="portlet-body"><div class="form-body">

<div class="form-group form-md-line-input">
<label class="col-md-3 control-label" for="form_control_1">Коментарий</label>
<div class="col-md-9"><input type="text" class="form-control" placeholder="" name="com" id="com">
<div class="form-control-focus"> </div></div></div>

<div class="form-group form-md-line-input">
<label class="col-md-3 control-label" for="form_control_1">Фотография</label>
<div class="col-md-3"><input type="file" name="goimage" id="goimage"></input></div>
<div class="col-md-3"><input type="checkbox" id="nonimg" name="nonimg"> Нет фотографии?</input></div>
</div>

<div class="form-group form-md-line-input">
<label class="col-md-3 control-label" for="form_control_1">Файл</label>
<div class="col-md-9"><input type="file" name="gofile" id="gofile"></div></div>

</div><div class="form-actions"><div class="row"><div class="col-md-offset-3 col-md-9">
<br><button class="btn btn-minw btn-square btn-primary waves-effect" type="add" id="add" name="add">Добавить</button>
</div></div></div></div></div></div></form>
<?} if(isset($_GET['p'])) {
$check = $mysqli->query('SELECT * FROM `stats` ORDER BY `id` DESC');
echo '<form method="post">
<div class="col-md-12 animated fadeIn"><li class="list-group-item"><center><a href="/pages/files.php?adds" class="btn btn-minw btn-square btn-primary btn-circle">Добавить новый статус</a></center></li></div>
<div class="col-md-12"><div class="portlet light ">
<div class="portlet-title tabbable-line"><div class="caption">
<i class="icon-bubbles font-dark hide"></i>
<span class="caption-subject font-dark bold uppercase">Автостатусы</span></div></div>
<div class="portlet-body">
<div class="table-scrollable">
<table class="table table-striped table-bordered table-advance table-hover">
<thead><tr><th><center><i class="fa fa-bars"></i></center></th>
<th><i class="fa fa-cog"></i> Действия</th>
<th class=""><i class="fa fa-file-image-o"></i> Изображение</th>
<th class=""><i class="fa fa-comment-o"></i> Коментарий</th>
</tr></thead><tbody>';
while($row = $check->fetch_array()) {
$id = $row["id"];
$image = $row["image"];
$link = $row["link"];
$comment = $row["comment"];
$date = $row["date"];
$byOwn = $row["byOwn"];
$type = random(array('success', 'danger', 'info', 'warning'));
echo '
<tr id="info'.$id.'" class="wow fadeInUp"><td class="highlight">
<div class="'.$type.'"></div>
<a href="javascript:;">#'.$id.'</a></td>
<td><center><div id="com'.$id.'">
<a class="btn blue fa fa-edit btn-circle waves-effect" onclick="sendst('.$id.');"> Редактировать</a>
<a class="btn red fa fa-times-circle btn-circle waves-effect" onclick="destroyst('.$id.');"> Удалить</a>
</div></center></td>
<td class=""><img src="'.$image.'" style="wight: auto; height: auto"></td>
<td class="">'.$comment.'</td></tr>';
} echo '</tbody></table></div></div></div></div>'; ?>
<input class="hidden" id="sendeditst" name="sendeditst" value="sendeditst">
<input class="hidden" id="statedit" name="statedit" value="statedit">
<input class="hidden" id="statdel" name="statdel" value="statdel">
<script>
function sendst(id) {
	Pace.restart()
	var scriptid = id;
	var sendeditst = $('#sendeditst')['val']();
    $['ajax']({
     type: 'POST',
     url: '/data/api.php',
     data: ({ scriptid: id, sendeditst: $("#sendeditst").val() }),
	 success: function (data) { $('#com'+id).html (data + ""); $('#com'+id).show (); },
			error: function (data) {
				toastr.options = {
				closeButton: false,
				progressBar: true,
				showMethod: "fadeIn",
				positionClass: "toast-bottom-right",
				timeOut: 2000 }; toastr.clear();
				toastr.warning("Сервер недоступен", "Внимание");
			} });
}
function editst(id) {
	Pace.restart()
	var scriptid = id;
	var com = $('#com')['val']();
	var statedit = $('#statedit')['val']();
    $['ajax']({
     type: 'POST',
     url: '/data/api.php',
     data: ({ scriptid: id, statedit: $("#statedit").val(), com: $("#com").val() }),
	 success: function (data) { $('#com'+id).html (data + ""); $('#com'+id).show (); },
			error: function (data) {
				toastr.options = {
				closeButton: false,
				progressBar: true,
				showMethod: "fadeIn",
				positionClass: "toast-bottom-right",
				timeOut: 2000 }; toastr.clear();
				toastr.warning("Сервер недоступен", "Внимание");
			} });
}
function destroyst(id) {
	Pace.restart()
	var scriptid = id;
	var statdel = $('#statdel')['val']();
    $['ajax']({
     type: 'POST',
     url: '/data/api.php',
     data: ({ scriptid: id, statdel: $("#statdel").val() }),
	 success: function (data) { $('#info'+id).html (data + ""); $('#info'+id).show (); },
			error: function (data) {
				toastr.options = {
				closeButton: false,
				progressBar: true,
				showMethod: "fadeIn",
				positionClass: "toast-bottom-right",
				timeOut: 2000 }; toastr.clear();
				toastr.warning("Сервер недоступен", "Внимание");
			} });
}
</script>

<? } } else { header('Location: /'); }

if (isset($_GET['stats'])) {
$check = $mysqli->query('SELECT * FROM `stats` ORDER BY `id` DESC');
echo '<div class="portlet light"><div class="portlet-title tabbable-line">
<div class="caption"><i class="icon-bubbles font-dark hide"></i>
<span class="caption-subject font-dark bold uppercase">Статусы</span>
</div></div><div class="portlet-body">';

while($row = $check->fetch_array()) {
$id = $row["id"];
$image = $row["image"];
$link = $row["link"];
$comment = $row["comment"];
$date = $row["date"];
$by = $row["byOwn"];
$saved = $row["saved"];

$type = random(array('fadeInUp'));
$info = $mysqli->query('SELECT * FROM `users` WHERE `profile`="'.$by.'"')->fetch_array();
$name1 = $info['first_name']; $surname1 = $info['last_name'];
echo '<div class="portlet box blue-chambray wow '.$type.'"><div class="portlet-title">
<div class="tools"><span class="day"><i class="fa fa-download"> </i> '.$saved.' | <i class="fa fa-calendar"> </i> '.$date.' | <i class="fa fa-user"> '.$name1.' '.$surname1.'</i></span>
</div><div class="caption">Скрипт #'.$id.'</div></div>
<div class="portlet-body"><div class="table-responsive">
<table class="table table-bordered"><tbody><tr><td class="web-inspector-hide-shortcut"><center><img src="'.$image.'"></center></td>
</tr><tr>	<td class="web-inspector-hide-shortcut"><center>'.$comment.'</center></td></tr><tr>
<td><div class="btn-group btn-group-circle btn-group btn-group-justified"> <div id="info'.$id.'">
<center><a class="btn blue-dark waves-effect" onclick="getlinkst('.$id.')">Показать Ссылку </a></center></div></div></td>
<input type="hidden" id="script" name="script" value="'.$id.'"></tr></tbody></table></div></div></div>';
} echo '</div></div></div><input class="hidden" id="getlinkst" name="getlinkst">'; }


if(isset($_GET['scripts'])) {
$res = $mysqli->query('SELECT * FROM `script` ORDER BY `id` DESC');
echo '<div class="portlet light"><div class="portlet-title tabbable-line">
<div class="caption"><i class="icon-bubbles font-dark hide"></i>
<span class="caption-subject font-dark bold uppercase">Скрипты</span>
</div></div><div class="portlet-body">';

while($row = $res->fetch_array()) {
$id = $row["id"];
$image = $row["image"];
$link = $row["link"];
$comment = $row["comment"];
$date = $row["date"];
$by = $row["byOwn"];
$saved = $row["saved"];

$type = random(array('fadeInUp'));
$info = $mysqli->query('SELECT * FROM `users` WHERE `profile`="'.$by.'"')->fetch_array();
$name1 = $info['first_name']; $surname1 = $info['last_name'];
echo '<div class="portlet box blue-chambray wow '.$type.'"><div class="portlet-title">
<div class="tools"><span class="day"><i class="fa fa-download"> </i> '.$saved.' | <i class="fa fa-calendar"> </i> '.$date.' | <i class="fa fa-user"> '.$name1.' '.$surname1.'</i></span>
</div><div class="caption">Скрипт #'.$id.'</div></div>
<div class="portlet-body"><div class="table-responsive">
<table class="table table-bordered"><tbody><tr><td class="web-inspector-hide-shortcut"><center><img src="'.$image.'"></center></td>
</tr><tr>	<td class="web-inspector-hide-shortcut"><center>'.$comment.'</center></td></tr><tr>
<td><div class="btn-group btn-group-circle btn-group btn-group-justified"> <div id="info'.$id.'">
<center><a class="btn blue-dark waves-effect" onclick="getlinksc('.$id.')">Показать Ссылку </a></center></div></div></td>
<input type="hidden" id="script" name="script" value="'.$id.'"></tr></tbody></table></div></div></div>';
} echo '</div></div></div><input class="hidden" id="getlinksc" name="getlinksc">'; } ?>

</div>
<?
function random($array) {
$num = rand(0, count($array)-1);
return $array[$num]; }
include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php');
?>
