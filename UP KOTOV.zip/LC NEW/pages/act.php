<? session_start();
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
if (isset($_GET['logout']) && isset($_SESSION['uid'])) {
$mysqli->query('UPDATE `users` SET `lastjoin`="'.date('Y-m-d H:i:s').'", `ip_user`="'.$_SERVER['REMOTE_ADDR'].'" WHERE `profile`="'.$_SESSION["uid"].'"');
session_destroy(); header("Location: /"); } else { header("Location: /"); }
