<? include($_SERVER['DOCUMENT_ROOT'].'/data/router.php'); ?>

<div id="info"></div>
<div class="col-md-12">
<div class="portlet light portlet-fit portlet-form bordered">
<div class="portlet-title"><div class="caption"><i class="fa fa-user font-blue"></i>
<span class="caption-subject font-dark sbold uppercase">Информация о пользователе</span>
</div></div><div class="portlet-body"><div class="form-body">
<div class="form-group form-md-line-input has-info form-md-floating-label">
<div class="input-group"><div class="input-group-control">
<input type="text" class="form-control" id="id">
<label for="form_control_1">Введите ID или домен пользователя</label></div>
<span class="input-group-btn btn-right">
<button type="button" class="btn btn-minw btn btn-circle btn-square btn-info" value="userinfo" id="userinfo" onclick="userinfo()">Отправить</button></span>
</div></div></div></div></div></div>
<? include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>
