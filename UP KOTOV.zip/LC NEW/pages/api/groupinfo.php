<? include($_SERVER['DOCUMENT_ROOT'].'/data/router.php'); ?>

<div id="info"></div>
<div class="col-md-12">
<div class="portlet light portlet-fit portlet-form bordered">
<div class="portlet-title"><div class="caption"><i class="fa fa-group font-blue"></i>
<span class="caption-subject font-dark sbold uppercase">Информация о группе</span>
</div></div><div class="portlet-body"><div class="form-body">
<div class="form-group form-md-line-input has-info form-md-floating-label">
<div class="input-group"><div class="input-group-control">
<input type="text" class="form-control" id="id">
<label for="form_control_1">Введите ID или домен группы</label></div>
<span class="input-group-btn btn-right">
<button type="button" class="btn btn-minw btn btn-circle btn-square btn-info" value="groupinfo" id="groupinfo" onclick="groupinfo()">Отправить</button></span>
</div></div></div></div></div></div>
<? include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>
