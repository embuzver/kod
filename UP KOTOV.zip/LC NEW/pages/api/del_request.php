<? include($_SERVER['DOCUMENT_ROOT'].'/data/router.php'); ?>

<div id="info"></div>
<div class="col-md-12">
<div class="portlet light portlet-fit portlet-form bordered">
<div class="portlet-title"><div class="caption"><i class="fa fa-user-secret font-blue"></i>
<span class="caption-subject font-dark sbold uppercase">Удаляем исходящие заяки в друзья</span>
</div></div><div class="portlet-body"><div class="form-body">
<li class="list-group-item"><b>1.</b> Получаем <b>access_token</b> тут: </li>
<li class="list-group-item"><center><button type="button" class="btn btn-minw btn btn-circle btn-square btn-info" onclick="window.open('https://oauth.vk.com/authorize?client_id=3087106&amp;scope=wall,offline&amp;redirect_uri=https://api.vk.com/blank.html&amp;display=page&amp;response_type=token')">Токен</button></center></li>
<li class="list-group-item"><b>2.</b> Введите свой access_token</li>
<li class="list-group-item">
<div class="form-group form-md-line-input has-info form-md-floating-label">
<div class="input-group"><div class="input-group-control">
<input type="text" id="token" class="form-control">
<label for="form_control_1">Введите ACCESS_TOKEN</label></div>
<span class="input-group-btn btn-right">
<button type="button" class="btn btn-minw btn btn-circle btn-square btn-info" id="delrequ" value="delrequ" onclick="delrequ()">Отправить</button></span>
</div></div></li></div></div></div></div>
<? include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>
