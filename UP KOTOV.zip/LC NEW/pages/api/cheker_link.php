<? include($_SERVER['DOCUMENT_ROOT'].'/data/router.php'); ?>

<div id="info"></div>
<div class="col-md-12">
<div class="portlet light portlet-fit portlet-form bordered">
<div class="portlet-title"><div class="caption"><i class="fa fa-times-circle-o font-blue"></i>
<span class="caption-subject font-dark sbold uppercase">Забанена ли ссылка в Вконтакте?</span>
</div></div><div class="portlet-body"><div class="form-body">
<div class="form-group form-md-line-input has-info form-md-floating-label">
<div class="input-group"><div class="input-group-control">
<input type="text" class="form-control" id="url">
<label for="form_control_1">Введите ссылку на сайт</label></div>
<span class="input-group-btn btn-right">
<button type="button" class="btn btn-minw btn btn-circle btn-square btn-info" value="url_vk" id="url_vk" onclick="url_vk()">Отправить</button></span>
</div></div></div></div></div></div>
<? include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>
