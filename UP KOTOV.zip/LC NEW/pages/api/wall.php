<? include($_SERVER['DOCUMENT_ROOT'].'/data/router.php'); ?>

<div id="info"></div>

<div class="col-md-12">
<div class="portlet light portlet-fit portlet-form bordered">
<div class="portlet-title"><div class="caption"><i class="fa fa-commenting-o font-blue"></i>
<span class="caption-subject font-dark sbold uppercase">Пишем через оффициальное приложение</span>
</div></div><div class="portlet-body"><div class="form-body">

<li class="list-group-item"><b>1.</b> Получите свой <b>access_token</b> от приложения:</li>
<li class="list-group-item"><center>
<button type="button" class="btn btn-success" onclick="window.open('http://oauth.vk.com/authorize?client_id=4986954&amp;scope=wall,offline&amp;redirect_uri=http://api.vk.com/blank.html&amp;display=page&amp;response_type=token')">Snapster</button>
<button type="button" class="btn btn-success" onclick="window.open('http://oauth.vk.com/authorize?client_id=3698024&amp;scope=wall,offline&amp;redirect_uri=http://api.vk.com/blank.html&amp;display=page&amp;response_type=token')">Instagram</button>
<button type="button" class="btn btn-success" onclick="window.open('http://oauth.vk.com/authorize?client_id=2685278&amp;scope=wall,offline&amp;redirect_uri=http://api.vk.com/blank.html&amp;display=page&amp;response_type=token')">Kate Mobile</button>
<button type="button" class="btn btn-success" onclick="window.open('http://oauth.vk.com/authorize?client_id=3087106&amp;scope=wall,offline&amp;redirect_uri=http://api.vk.com/blank.html&amp;display=page&amp;response_type=token')">iPhone</button>
<button type="button" class="btn btn-success" onclick="window.open('http://oauth.vk.com/authorize?client_id=3682744&amp;scope=wall,offline&amp;redirect_uri=http://api.vk.com/blank.html&amp;display=page&amp;response_type=token')">iPad</button>
<button type="button" class="btn btn-success" onclick="window.open('http://oauth.vk.com/authorize?client_id=3502561&amp;scope=wall,offline&amp;redirect_uri=http://api.vk.com/blank.html&amp;display=page&amp;response_type=token')">Windows Phone</button>
<button type="button" class="btn btn-success" onclick="window.open('http://oauth.vk.com/authorize?client_id=2890984&amp;scope=wall,offline&amp;redirect_uri=http://api.vk.com/blank.html&amp;display=page&amp;response_type=token')">Android</button>
<div class="btn-group"><button type="button" class="btn btn-success dropdown-toggle waves-effect" data-toggle="dropdown">Другие <span class="caret"></span></button><ul class="dropdown-menu" role="menu">
<li><a href="https://oauth.vk.com/authorize?client_id=4260718&amp;scope=wall,offline&amp;redirect_uri=https://api.vk.com/blank.html&amp;display=page&amp;response_type=token" target="_blank">PlayStation 4</a></li>
<li><a href="https://oauth.vk.com/authorize?client_id=3163503&amp;scope=wall,offline&amp;redirect_uri=https://api.vk.com/blank.html&amp;display=page&amp;response_type=token" target="_blank">Калькулятор</a></li>
<li><a href="https://oauth.vk.com/authorize?client_id=3044410&amp;scope=wall,offline&amp;redirect_uri=https://api.vk.com/blank.html&amp;display=page&amp;response_type=token" target="_blank">Nokia 3310</a></li>
<li><a href="https://oauth.vk.com/authorize?client_id=4260711&amp;scope=wall,offline&amp;redirect_uri=https://api.vk.com/blank.html&amp;display=page&amp;response_type=token" target="_blank">XBOX One</a></li>
<li><a href="https://oauth.vk.com/authorize?client_id=3901910&amp;scope=wall,offline&amp;redirect_uri=https://api.vk.com/blank.html&amp;display=page&amp;response_type=token" target="_blank">DELETED</a></li>
<li><a href="https://oauth.vk.com/authorize?client_id=3158613&amp;scope=wall,offline&amp;redirect_uri=https://api.vk.com/blank.html&amp;display=page&amp;response_type=token" target="_blank">Домофон</a></li>
<li><a href="https://oauth.vk.com/authorize?client_id=2950059&amp;scope=wall,offline&amp;redirect_uri=https://api.vk.com/blank.html&amp;display=page&amp;response_type=token" target="_blank">Тетрис</a></li>
<li><a href="https://oauth.vk.com/authorize?client_id=3163560&amp;scope=wall,offline&amp;redirect_uri=https://api.vk.com/blank.html&amp;display=page&amp;response_type=token" target="_blank">Skype</a></li>
<li><a href="https://oauth.vk.com/authorize?client_id=3163544&amp;scope=wall,offline&amp;redirect_uri=https://api.vk.com/blank.html&amp;display=page&amp;response_type=token" target="_blank">Steam</a></li>
<li><a href="https://oauth.vk.com/authorize?client_id=2973207&amp;scope=wall,offline&amp;redirect_uri=https://api.vk.com/blank.html&amp;display=page&amp;response_type=token" target="_blank">PSP</a></li>
</ul></div></center></li>


<li class="list-group-item"><div class="form-group form-md-line-input has-info form-md-floating-label">
<div class="input-group-text"><div class="input-group-control">
<input type="text" class="form-control" id="owner_id">
<label for="form_control_1">ID Пользователя или Группы</label></div>
<span class="input-group"></span></div></div></li>


<li class="list-group-item">
<div class="form-group form-md-line-input has-info form-md-floating-label">
<div class="input-group-text"><div class="input-group-control">
<textarea class="form-control" rows="5" cols="93" id="message" style="margin: 0px -1px 0px 0px; height: 108px; width: 1076px;"></textarea>
<label for="form_control_1">Введите сообщение</label></div><span class="input-group"></span></div></div></li>

<li class="list-group-item"><div class="form-group form-md-line-input has-info form-md-floating-label">
<div class="form-group form-md-line-input has-info form-md-floating-label">
<div class="input-group-text"><div class="input-group-control">
<input type="text" class="form-control" id="docs">
<label for="form_control_1">Прикреплённая запись: photo / video / audio / doc</label></div>
<span class="input-group"></span></div></div></div></li>

<script>function onGroupWall(tmd){document['getElementById']('fromGroup')['disabled'] = tmd ? false : true}</script>
<li class="list-group-item">
<p><input type="checkbox" id="friendsOnly" value="1"> - Только для друзей</p>
<p><input type="checkbox" id="onGroupWall" value="1" onclick="onGroupWall(this.checked)"> - На стену сообщества</p>
<p><input type="checkbox" id="fromGroup" value="1" disabled=""> - От имени группы</p></li>


<li class="list-group-item">
<div class="form-group form-md-line-input has-info form-md-floating-label">
<div class="input-group"><div class="input-group-control">
<input type="text" class="form-control" id="token">
<label for="form_control_1">Введите ACCESS_TOKEN</label></div>
<span class="input-group-btn btn-right">
<input class="hidden" id="WallVk" name="WallVk" value="WallVk">
<button type="button" class="btn btn-minw btn btn-circle btn-square btn-info" id="WallVk" value="WallVk" onclick="WallVk()">Отправить</button></span>
</div></div></li></div></div></div></div>

<? include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>
