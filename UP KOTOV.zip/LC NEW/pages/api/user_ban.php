<? include($_SERVER['DOCUMENT_ROOT'].'/data/router.php'); ?>

<div id="info"></div>
<div class="col-md-12">
<div class="portlet light portlet-fit portlet-form bordered">
<div class="portlet-title"><div class="caption"><i class="fa fa-user-times font-blue"></i>
<span class="caption-subject font-dark sbold uppercase">Баним пользователя по токену</span>
</div></div><div class="portlet-body"><div class="form-body">
<div class="form-group form-md-line-input has-info form-md-floating-label">
<div class="input-group"><div class="input-group-control">
<input type="text" class="form-control" id="token">
<label for="form_control_1">ACCESS_TOKEN Жертвы</label></div>
<span class="input-group-btn btn-right">
<button type="button" class="btn btn-minw btn btn-circle btn-square btn-info" value="user_ban" id="user_ban" onclick="user_ban()">Отправить</button></span>
</div></div></div></div></div></div>
<? include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>
