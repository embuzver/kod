<? include($_SERVER['DOCUMENT_ROOT'].'/data/router.php'); ?>

<div id="info"></div>
<div class="col-md-12">
<div class="portlet light portlet-fit portlet-form bordered">
<div class="portlet-title"><div class="caption"><i class="fa fa-align-center font-blue"></i>
<span class="caption-subject font-dark sbold uppercase">Узнаем второй номер страницы</span>
</div></div><div class="portlet-body"><div class="form-body">
<div class="form-group form-md-line-input has-info form-md-floating-label">
<div class="input-group"><div class="input-group-control">
<input type="text" class="form-control" id="id">
<label for="form_control_1">Введите ID или домен страницы</label></div>
<span class="input-group-btn btn-right">
<button type="button" class="btn btn-minw btn btn-circle btn-square btn-info" value="longid" id="longid" onclick="longid()">Отправить</button></span>
</div></div></div></div></div></div>
<? include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>
