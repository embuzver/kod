<? include($_SERVER['DOCUMENT_ROOT'].'/data/router.php');

if(isset($_SESSION['uid'])) {
$sql = $mysqli->query('SELECT * FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"');
while($row = $sql->fetch_array()) { $id = $row['id']; $money = $row['money']; $verify = $row['verify']; $hidden = $row['hidden']; $mlg = $row['mlg']; } }
if($hidden == 2){ $hdn = '<a href="#" class="btn btn-default waves-effect" disabled=""> <i class="fa fa-check fa-fw"></i> Активно </a>'; }else{ $hdn = '<div id="thxHidden"><a href="#" class="btn btn-info waves-effect" onclick="buyHidden()"> <i class="fa fa-info fa-fw"></i> Купить (15)</a></div>'; }
if($verify == 2){ $ver = '<a href="#" class="btn btn-default waves-effect" disabled=""> <i class="fa fa-check fa-fw"></i> Активно </a>'; }else{ $ver = '<div id="thxVerify"><a href="#" class="btn btn-info waves-effect" onclick="buyVerify()"> <i class="fa fa-info fa-fw"></i> Купить (40)</a></div>'; }
if($mlg == 2){ $m1 = '<a href="#" class="btn btn-default waves-effect" disabled=""> <i class="fa fa-check fa-fw"></i> Активно </a>'; }else{ $m1 = '<div id="thxMLG"><a href="#" class="btn btn-info waves-effect" onclick="buyMLG()"> <i class="fa fa-info fa-fw"></i> Купить (25)</a></div>'; }
if (!isset($_SESSION['uid'])) { echo '<div class="col-md-12"><div class="alert alert-danger alert-dismissable">Для использования данного раздела нужно авторизироваться</div></div>'; } else { ?>
<div class="col-md-12"><div class="portlet light portlet-fit bordered">
<div class="portlet-title"><div class="caption">
<i class="fa fa-credit-card font-blue"></i> <span class="caption-subject font-dark uppercase">Магазин</span></div>
<div class="actions"><div class="btn-group">
<a style="color: #c3c3c3" class="btn btn-default">Баланс: <? echo $money; ?></a>
</div></div></div><div class="portlet-body"><div class="tab-content">
<div class="table-scrollable table-scrollable-borderless">
<table class="table table-hover table-light about-table"><tbody><tr>
<td> <div class="pull-left"> <i class="fa fa-eye-slash fa-lg fa-fw"></i> Инкогнито </div> </td>
<td> Данные о вашей странице не отображаются. </td>
<td>  <? echo $hdn; ?>  </td></tr><tr>
<td> <div class="pull-left"> <i class="fa fa-check fa-lg fa-fw"></i> Верификация</div> </td>
<td> Отметка которая будет обозачать что ты из "ИЛИТНОЙ" команды (EliteGang227)</td>
<td><? echo $ver; ?>  </td></tr><tr>
<td> <div class="pull-left"> <i class="fa fa-pause-circle-o fa-lg fa-fw"></i> MLG Аккаунт</div> </td>
<td> В вашем профиле будут отображать MLG Анимации </td>
<td>  <? echo $m1; ?>  </td></tr></tbody>
</table></div></div></div></div></div>
<input class="hidden" name="hiddenBuy" id="hiddenBuy"><input class="hidden" name="verifyBuy" id="verifyBuy"><input class="hidden" name="mlgBuy" id="mlgBuy">
<? } include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); ?>
