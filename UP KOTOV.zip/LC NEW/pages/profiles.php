<? session_start();
include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
if(!$_GET){ header('Location: /'); }
if(isset($_GET['id'])) { $getid = $_GET['id'];
$wh = $mysqli->query('SELECT * FROM `users` WHERE id="'.$getid.'"');
if($wh->num_rows == 0) { $title = 'Не найдено'; }else{ $getinfo = $wh->fetch_array();
} $title = ''.$site['Name'].' • '.$getinfo['first_name'].' '.$getinfo['last_name'].'';

/* Вырываем информацию (Работаем над страничкой) */
include($_SERVER['DOCUMENT_ROOT'].'/data/head.php');

$info = $mysqli->query('SELECT * FROM `users` WHERE id="'.$_GET['id'].'"')->fetch_array();
$id = $info['id'];
$first_name = $info['first_name'];
$last_name = $info['last_name'];
$who = $info['who'];
$profile = $info['profile'];
$photo = $info['photo'];

$datereg = $info['datereg'];
$lastjoin = $info['lastjoin'];
$money = $info['money'];
$hidden = $info['hidden'];
$verify = $info['verify'];
$mlg = $info['mlg'];

if($who == 0){
$statusUser = "<span class='text-danger'>Заблокирован</span>";
$bylike = '<div class="profile-userbuttons"><input type="hidden" id="Likes_id" name="Likes_id" value="7"><div id="Likes"></div>'; } else{
$getLikes = curl('https://api.vk.com/method/photos.get?album_id=profile&rev=1&extended=1&count=1&uid='.$profile);
$getLikesJson = json_decode($getLikes,1);
$likes = $getLikesJson['response']['0']['likes']['count'];
$bylike = '<div class="profile-userbuttons"><input type="hidden" id="Likes_id" name="Likes_id" value="7">
<div id="Likes"><button type="button" class="btn btn-circle green-haze btn-sm waves-effect"><i class="fa fa-thumbs-o-up"> '.$likes.' </i></button></div>';

if($verify == 2){ $ver = '<span class="page_verified">'; }
if($who == 5){ $statusUser = "Разработчик"; }
if($who == 4){ $statusUser = "Администратор"; }
if($who == 3){ $statusUser = "Редактор"; }
if($who == 2){ $statusUser = "Агент Поддержки"; }
if($who == 1){ $statusUser = "Пользователь"; } }

if($_SESSION['uid'] == $profile){
$likeon = '<input type="hidden" id="AvaNewsSet" name="AvaNewsSet" value="AvaNewsSet"><div class="profile-userbuttons"><button name="submit" class="btn btn-circle green btn-sm waves-effect" id="submit" onclick="AvaNewsSet()" type="button" value="submit">Обновить аватар</button>
<a class="btn btn-circle btn-danger btn-sm waves-effect" href="#AvaUpdateFAQ" data-toggle="modal">&nbsp; ? &nbsp;</a></div>'; }

$uget = curl('https://api.vk.com/method/users.get?name_case=Nom&fields=status&uid='.$profile);
$json = json_decode($uget,1); $stat = $json['response']['0']['status'];
if($hidden == 2){ $status = ''; } else {
if(!$stat == '') { $status = '<div class="col-md-12"><li class="list-group-item bg-green" id="emojis"> '.$stat.' </li><br></div>'; } }

$d = time() - strtotime($lastjoin);
if($d < 60) $stamp = $d.' сек. назад';
elseif($d < 3600) $stamp = round($d / 60).' мин. назад';
elseif($d < 86400) $stamp = round($d / 3600).' ч. назад';
else $stamp = round($d / 86400).' дн. назад';

if($lastjoin < date('Y-m-d H:i:s', time() - 60 * 5)){ $onl='1'; }
if($lastjoin > date('Y-m-d H:i:s', time() - 60 * 5)){ $onl='2'; }

if($onl == 2) {
$onlinestatus = '<span class="fa fa-toggle-on text-success" value="Online"></span>';
}else { $onlinestatus = '<span class="fa fa-toggle-off text-danger" value="Offline"></span>'; }
$check = $mysqli->query('SELECT * FROM `users` WHERE id="'.$getid.'"');

if($onl == 2) { $stampTrue = '<div class="text-success">Онлайн</div>'; }else { $stampTrue = 'Последний вход '.$stamp.''; }
if($check->num_rows == 0) { ?>

<div class="col-md-10">
<div class="portlet light portlet-fit bordered">
<div class="portlet-title">
<div class="caption">
		<div class="profile-userpic">
			<div id="ava">
			<img src="/resources/img_site/deactivated_200.png" style="width:40%" class="img-responsive" alt=""></div>
			<input type="hidden" id="id_upd" name="id_upd" value="">
			</div>
				<div class="profile-userbuttons">
					<input type="hidden" id="Likes_id" name="Likes_id" value="1"><div id="Likes"></div>
					</div>
				<div class="profile-usermenu">
				<ul class="nav">
					<li class="active">
						<a class="waves-effect" data-toggle="tab" href="#tab_1-1" aria-expanded="true">
							<i class="icon-info"></i>Информация
						</a>
					</li>
<div class="col-md-9 animated fadeInUp">
	<div class="portlet light portlet-fit bordered">
		<div class="portlet-title">
			<div class="caption"><i class="fa fa-warning font-blue"></i> <span class="caption-subject uppercase">Информация</span>
			</div>
		</div>
		<div class="portlet-body">
			<ul class="list-group">
				<li class="list-group-item bg-blue"><center>Пользователь не найден</center></li>
			</ul>
		</div>
	</div>
</div>
</div>
<? }else{ ?>

<div id="info"></div>
<script>
$(window).load(function() {
	var emojis = document.getElementById("emojis");
	emojis.innerHTML = window.emoji.replace('<?=$stat;?>');
});
</script>
<div class="col-md-12">
<?=$status; ?>
<div class="col-md-3 animated fadeInUp">
	<div class="portlet light profile-sidebar-portlet">
		<div class="profile-userpic">
			<div id="ava">
			<img src="<?=$photo; ?>" style="width: 40%;" class="img-responsive" alt=""></div>
			<input type="hidden" id="id_upd" name="id_upd" value=""><?=$likeon; ?></div>
			<div class="profile-usertitle"><div class="profile-usertitle-name"> <?=$first_name.' '.$last_name; ?>  <?=$onlinestatus; ?> </div>
			<div class="profile-usertitle-job"> <?=$statusUser; ?> <?=$ver; ?> </div> </div><?=$bylike; ?></div>
			<div class="profile-usermenu">
			<ul class="nav">
				<li class="active">
					<a class="waves-effect" data-toggle="tab" href="#infos" aria-expanded="true"><i class="icon-info"></i> Информация </a>
				</li>
<?
if(isset($_SESSION['uid'])) {
$ul1 = $mysqli->query('SELECT `id` FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"')->fetch_array();
if($_GET['id'] == $ul1['id']) { ?>
<li><a class="waves-effect" data-toggle="tab" href="#settings" aria-expanded="false"><i class="icon-settings"></i>Настройки</a></li>
<li><a class="waves-effect" data-toggle="tab" href="#func" aria-expanded="false"><i class="icon-drawer"></i>Функции</a></li>
<? } } ?> <br>
</ul>
</div>
</div>
</div>
<div class="col-md-9 animated fadeInUp">
	<div class="portlet light portlet-fit bordered">
		<div class="portlet-title">
			<div class="caption">
				<i class="fa fa-user font-blue"></i> <span class="caption-subject uppercase">Информация</span>
			</div>
			<? $kek = $mysqli->query('SELECT `who` FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"')->fetch_array();
			$nadmin = $kek['who']; if($nadmin > 3){ ?>
				<div class="actions">
					<div class="btn-group">
						<a class="btn btn-default" style="color: #c3c3c3" href="javascript:;" data-toggle="dropdown" data-close-others="true" aria-expanded="false">Управление <i style="color: #c3c3c3;" class="fa fa-angle-down"></i></a>
						<ul class="dropdown-menu pull-right">
							<li><a href="#getEdit" data-toggle="modal"><i class="fa fa-pencil"></i> Редактировать</a></li>
						</ul>
					</div>
				</div>
				<? } ?>
			</div>
		<div class="portlet-body">
			<div class="tab-content">
<?
	if($who == 0){
	echo '<div class="portlet-body"><ul class="list-group"><center><div class="page_privacy"></div></center></ul><div class="text-primary text-center">Возможность просмотра этого профиля ограничена.</div></div>';
	}else{ $letgoId = $mysqli->query('SELECT `id` FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"'); $gotoId = $letgoId->fetch_array();
	if($_GET['id'] == $gotoId['id']) {
?>
<div id="infos" class="tab-pane active">
	<div class="table-scrollable table-scrollable-borderless">
		<table class="table table-hover table-light about-table">
			<tbody>
				<tr><td>Дата регистрации</td><td><?=$datereg;?></td></tr>
				<tr><td>Баланс</td><td><?=$money;?> Doge</td></tr>
				<tr><td>Страница Вконтакте</td><td><a href="https://vk.com/id<?=$profile;?>">Сcылка</a></td></tr>
				<tr><td>Статус</td><td> <?=$stampTrue;?> </td></tr>
			</tbody>
		</table>
	</div>
</div>
<div id="settings" class="tab-pane"><div id="gg"></div>
<input type="hidden" id="settingSet" name="settingSet" value="settingSet">
<li class="list-group-item">Имя</li>
<li class="list-group-item">
	<div class="form-group">
		<input type="text" name="set_name" id="set_name" value="<? echo $first_name; ?>" class="form-control">
	</div>
</li>

<li class="list-group-item">Фамилия</li>
<li class="list-group-item">
	<div class="form-group">
		<input type="text" name="set_fam" id="set_fam" value="<? echo $last_name; ?>" class="form-control">
	</div>
</li>

<li class="list-group-item">Аватарка</li>
<li class="list-group-item">
	<div class="form-group">
		<center><img src="<? echo $photo; ?>" style="padding-bottom: 9px;" alt=""></center>
		<input type="text" name="img_ava" id="img_ava" value="<? echo $photo; ?>" class="form-control">
	</div>
</li>
<li class="list-group-item">Подтвердите что Вы не робот</li>
<li class="list-group-item"><div class="captchap" align="center"><img src="/data/secpic.php"></div></li>
<li class="input-group"><input class="form-control" type="text" name="captcha" id="captcha" placeholder="Введите код с картинки. . .">
<span class="input-group-btn"><button class="btn btn-minw btn-square btn-primary" name="submit" id="submit" value="submit" onclick="settingSet()">Сохранить</button></span></li>
</div>

<div id="func" class="tab-pane">
<li class="list-group-item bg-red">Здесь приведены установленные скрипты</li><br>
<div id="func_res">
<? $go1 = $mysqli->query('SELECT * FROM `status` WHERE `user_id` = "'.$_SESSION['uid'].'"');
if($go1->num_rows != 0){$stat = $go1->fetch_array();
	$statid = $stat['status_id'];
	$statcity = $stat['city'];
	$stattoken = $stat['token'];
/* Проверка токена */
	$res = curl('https://api.vk.com/method/account.setOnline?access_token='.$stattoken);
	$lo = 'response';
	$pos = strripos($res, $lo);
	if($pos == true){
	$statusValide = '<div class="text-success">Статус работает</div>';
	$redakt = '<a href="#Status_del" data-toggle="modal" type="button" class="btn red">Удалить</a><a href="#status_edit" data-toggle="modal" type="button" class="btn blue">Редактировать</a>'; }else{
		$statusValide = '<div class="text-danger"><i class="fa fa-ban"></i> Токен невалидный</div>';
        $redakt = '<a href="#Status_del" data-toggle="modal" type="button" class="btn red">Удалить</a>'; }
/* Конец проверки */
echo '<div id="statusinfo">
<div class="portlet box blue">
<div class="portlet-title"><div class="caption">Автостатус #'.$statid.'</div></div>
<div class="portlet-body"><div class="table-responsive">
<table class="table table-bordered"><tbody>
<tr><td class="web-inspector-hide-shortcut"><center><img src="/resources/img_site/status/status-'.$statid.'.png"></center></td></tr>
<tr><td class="web-inspector-hide-shortcut"><center><div class="text-success">Автостатус работает</div></center></td></tr>
</tbody></table></div>'.$redakt.'</div></div></div>
<input type="hidden" id="goToFunc1" name="goToFunc1" value="goToFunc1">
<input type="hidden" id="goToFunc2" name="goToFunc2" value="goToFunc2">'; }

/* ААААА СЛОЖНА */
$go2 = $mysqli->query('SELECT * FROM `groupstat` WHERE `user_id` = "'.$_SESSION['uid'].'"');
if($go2->num_rows != 0){
$groupstat = $go2->fetch_array();
	$stattoken = $groupstat['token'];
	$group = $groupstat['group'];
/* Проверка токена */
	$res = curl('https://api.vk.com/method/account.setOnline?access_token='.$stattoken);
	$lo = 'response';
	$pos = strripos($res, $lo);
	if($pos == true){
	$statusValide = '<div class="text-success"> Статус в группе работает | Группа: '.$group.'</div>';
	$redakt1 = '<a href="#Group_del" data-toggle="modal" type="button" class="btn red">Удалить</a>'; }else{
		$statusValide = '<div class="text-danger"> Токен невалидный</div>';
        $redakt1 = '<a href="#Group_del" data-toggle="modal" type="button" class="btn red">Удалить</a>'; }

/* Конец проверки */
echo '<div id="groupstatusinfo">
<div class="portlet box yellow"><div class="portlet-title"><div class="caption">АвтоСтатус в Группу</div></div>
<div class="portlet-body"><div class="table-responsive"><table class="table table-bordered"><tbody><tr>
<td class="web-inspector-hide-shortcut"><center><img src="/resources/img_site/groupstat.png"></center></td></tr><tr>
<td class="web-inspector-hide-shortcut"><center>'.$statusValide.'</center></td>
</tr><input type="hidden" id="script" name="script" value="1">
</tr></tbody></table></div>'.$redakt1.'</div></div></div>';  }

/* ЛУКИР:D */

$go3 = $mysqli->query('SELECT * FROM `liker` WHERE `user_id` = "'.$_SESSION['uid'].'"');
if($go3->num_rows != 0){
$onlinestat = $go3->fetch_array();
	$stattoken = $onlinestat['token'];
/* Проверка токена */
	$res = curl('https://api.vk.com/method/account.setOnline?access_token='.$stattoken);
	$lo = 'response';
	$pos = strripos($res, $lo);
	if($pos == true){
	$statusValide = '<div class="text-success"> Лайкер работает</div>';
	$redakt2 = '<a href="#liker_del" data-toggle="modal" type="button" class="btn red">Удалить</a>'; }else{
		$statusValide = '<div class="text-danger"> Токен невалидный</div>';
        $redakt2 = '<a href="#liker_del" data-toggle="modal" type="button" class="btn red">Удалить</a>'; }
/* Конец проверки */
echo '<div id="likerinfo">
<input type="hidden" id="goToFunc6" name="goToFunc6" value="goToFunc6">
<div class="portlet box blue-hoki"><div class="portlet-title"><div class="caption">Лайкер</div></div>
<div class="portlet-body"><div class="table-responsive"><table class="table table-bordered"><tbody><tr></tr><tr>
<td class="web-inspector-hide-shortcut"><center>'.$statusValide.'</center></td>
</tr><input type="hidden" id="script" name="script" value="1">
</tr></tbody></table></div>'.$redakt2.'</div></div></div>';  }

/* ВЕЧНЫЙ АНЛАИН((( */

$go3 = $mysqli->query('SELECT * FROM `online` WHERE `user_id` = "'.$_SESSION['uid'].'"');
if($go3->num_rows != 0){
$onlinestat = $go3->fetch_array();
	$stattoken = $onlinestat['token'];
/* Проверка токена */
	$res = curl('https://api.vk.com/method/account.setOnline?access_token='.$stattoken);
	$lo = 'response';
	$pos = strripos($res, $lo);
	if($pos == true){
	$statusValide = '<div class="text-success"> Онлайн работает</div>';
	$redakt2 = '<a href="#Online_del" data-toggle="modal" type="button" class="btn red">Удалить</a>'; }else{
		$statusValide = '<div class="text-danger"> Токен невалидный</div>';
        $redakt2 = '<a href="#Online_del" data-toggle="modal" type="button" class="btn red">Удалить</a>'; }
/* Конец проверки */
echo '<div id="onlineinfo">
<input type="hidden" id="goToFunc4" name="goToFunc4" value="goToFunc4">
<div class="portlet box purple"><div class="portlet-title"><div class="caption">Вечный онлайн</div></div>
<div class="portlet-body"><div class="table-responsive"><table class="table table-bordered"><tbody><tr></tr><tr>
<td class="web-inspector-hide-shortcut"><center>'.$statusValide.'</center></td>
</tr><input type="hidden" id="script" name="script" value="1">
</tr></tbody></table></div>'.$redakt2.'</div></div></div>';  }

/* ФУНКЦИИ:D */

$go4 = $mysqli->query('SELECT * FROM `set_func` WHERE `user_id` = "'.$_SESSION['uid'].'"');
if($go4->num_rows != 0){
$funcstat = $go4->fetch_array();
	$stattoken = $funcstat['token'];
	$friends_add = $funcstat['friends_add'];
	$friends_delete = $funcstat['friends_delete'];
/* Проверка токена */
	$res = curl('https://api.vk.com/method/account.setOnline?access_token='.$stattoken);
	$lo = 'response';
	$pos = strripos($res, $lo);
	if($pos == true){

if($friends_add == 2){
	$friends_add1 = '<td class="list-group-item"><center><div class="text-info">Автодобавление в друзья: Включено</div></center></td>';
} else { $friends_add1 = '<td class="list-group-item"><center><div class="text-danger">Автодобавление в друзья: Выключено </div></center></td>'; }
if($friends_delete == 2){
	$friends_delete1 = '<td class="list-group-item"><center><div class="text-info">Автоудаление из подписок: Включено</div></center></td>';
} else { $friends_delete1 = '<td class="list-group-item"><center><div class="text-danger">Автоудаление из подписок: Выключено </div></center></td>'; }
	$statusValide = '<div class="text-success"><i class="fa fa-check-circle"></i> В активном состоянии</div>';
	$redakt3 = '<a href="#Func_del" data-toggle="modal" type="button" class="btn red">Удалить</a>'; }else{ $statusValide = '<div class="text-danger"> Токен невалидный</div>';
    $redakt3 = '<a href="#Func_del" data-toggle="modal" type="button" class="btn red">Удалить</a>'; }
/* Конец проверки */
echo '<div id="funcinfo"><div id="funcShow" class="portlet box green"><div class="portlet-title"><div class="caption">Функции</div></div>
<div class="portlet-body"><div class="table-responsive"><table class="table table-bordered"><tbody><tr></tr><tr>
'.$friends_add1.' '.$friends_delete1.' '.$online1.'
<li class="list-group-item"><center>'.$statusValide.'</center></li>
</tr><input type="hidden" id="script" name="script" value="1">
</tr></tbody></table></div>'.$redakt3.'</div></div></div>';  }
?>
</div></div></div>
<? } else {
if($hidden == 2){
$getAdminById = $mysqli->query('SELECT * FROM `users` WHERE `profile`="'.$_SESSION['uid'].'"')->fetch_array();
if($getAdminById['who'] > 3){
?>

<div id="infos" class="tab-pane active">
	<div class="table-scrollable table-scrollable-borderless">
		<ul class="list-group"><li class="list-group-item bg-blue"><center>Профиль открыт для Администраторов</center></li></ul>
		<table class="table table-hover table-light about-table">
			<tbody>
				<tr><td>Дата регистрации</td><td><?=$datereg; ?></td></tr>
				<tr><td>Баланс</td><td><?=$money; ?> Doge</td></tr>
				<tr><td>Страница Вконтакте</td><td><a href="https://vk.com/id<?=$profile; ?>">Сcылка</a></td></tr>
				<tr><td>Статус</td><td> <?=$stampTrue;?></td></tr>
			</tbody>
		</table>
	</div>
</div>

<? } else { echo '<div class="portlet-body"><ul class="list-group"><center><div class="page_privacy"></div></center></ul><div class="text-primary text-center">Профиль скрыт настройками приватности</div></div>'; } } else { ?>

<div id="infos" class="tab-pane active">
	<div class="table-scrollable table-scrollable-borderless">
		<table class="table table-hover table-light about-table">
			<tbody>
				<tr><td>Дата регистрации</td><td><?=$datereg; ?></td></tr>
				<tr><td>Баланс</td><td><?=$money;?> Doge</td></tr>
				<tr><td>Страница Вконтакте</td><td><a href="https://vk.com/id<?=$profile; ?>">Сcылка</a></td></tr>
				<tr><td>Статус</td><td> <?=$stampTrue; ?></td></tr>
			</tbody>
		</table>
	</div>
</div>
<? } } } } } ?>
</div></div></div></div></div></div>

<div tabindex="-1" class="modal fade bs-modal-sm" id="AvaUpdateFAQ" aria-hidden="true" style="display: none;">
	<div class="modal-dialog modal-sm">
		<div class="modal-content"><div class="modal-header">
		<h4 class="modal-title">Обновление аватара</h4></div>
		<div class="modal-body"> При нажатии на кнопку "Обновить аватар" ваш аватар из вконтакте установится на сайт </div>
		<div class="modal-footer"><button class="btn green" type="button" data-dismiss="modal">Закрыть</button></div>
		</div>
	</div>
</div>

<?
if($who != 0){ if($mlg == 2){ echo '<img src="/resources/img_site/gifs/Snoopy.gif" style="position: fixed;bottom: 0; right: 0" width="20%"><img src="/resources/img_site/gifs/ChikenMan.gif" style="position: fixed;bottom: 0; left: 0;" width="20%">'; } }
if($nadmin > 3){
if($who == 5){ $privelegy = '<option value="5" selected="">Разработчик</option><option value="4">Администратор</option><option value="3">Редактор</option><option value="2">Агент Поддержки</option><option value="1">Пользователь</option><option value="0">Заблокирован</option>'; }
if($who == 4){ $privelegy = '<option value="4" selected="">Администратор</option><option value="3">Редактор</option><option value="2">Агент Поддержки</option><option value="1">Пользователь</option><option value="0">Заблокирован</option>'; }
if($who == 3){ $privelegy = '<option value="3" selected="">Редактор</option><option value="4">Администратор</option><option value="2">Агент Поддержки</option><option value="1">Пользователь</option><option value="0">Заблокирован</option>'; }
if($who == 2){ $privelegy = '<option value="2" selected="">Агент Поддержки</option><option value="3">Редактор</option><option value="1">Пользователь</option><option value="4">Администратор</option><option value="0">Заблокирован</option>'; }
if($who == 1){ $privelegy = '<option value="1" selected="">Пользователь</option><option value="2">Агент Поддержки</option><option value="3">Редактор</option><option value="4">Администратор</option><option value="0">Заблокирован</option>'; }
if($who == 0){ $privelegy = '<option value="0" selected="">Заблокирован</option><option value="1">Пользователь</option><option value="2">Агент Поддержки</option><option value="3">Редактор</option><option value="4">Администратор</option>'; }
if($verify == 2){ $verity = '<option value="2" selected="">Есть</option><option value="1">Без верификации</option>'; } else {
$verity = '<option value="1" selected="">Без верификации</option><option value="2">Есть</option>'; }
if($who == 0){ $banify = '<option value="2" selected="">Заблокирован</option><option value="1">Без блокировки</option>'; } else {
$banify = '<option value="1" selected="">Без блокировки</option><option value="2">Заблокирован</option>'; }
if($hidden == 2){ $hideny = '<option value="2" selected="">Скрыт</option><option value="1">Открыт</option>'; } else {
$hideny = '<option value="1" selected="">Открыт</option><option value="2">Скрыт</option>'; }
?>

<script>
function sendEdit() {
	var glID = $('#glID')['val']();
	var sendEdit = $('#sendEdit')['val']();
    var glname = $('#glname')['val']();
	var gllast = $('#gllast')['val']();
	var glphoto = $('#glphoto')['val']();
	var glmoney = $('#glmoney')['val']();
	var gladmin = $('#gladmin')['val']();
	var glverify = $('#glverify')['val']();
	var glhid = $('#glhid')['val']();
    $['ajax']({
        type: 'POST',
        url: '/data/api.php',
        data: ({ glID: $("#glID").val(), sendEdit: $("#sendEdit").val(),
		glname: $("#glname").val(), gllast: $("#gllast").val(),
		glphoto: $("#glphoto").val(), glmoney: $("#glmoney").val(),
		gladmin: $("#gladmin").val(), glverify: $("#glverify").val(),
		glhid: $("#glhid").val() }),
			success: function (data) {
				$('#info').html (data + "");
				$('#info').show ();
			},
			error: function (data) {
				toastr.options = {
				closeButton: false,
				progressBar: true,
				showMethod: "fadeInUp",
				positionClass: "toast-bottom-right",
				timeOut: 2000 }; toastr.clear();
				toastr.warning("Сервер недоступен", "Внимание");
			}
    });
}
</script>

<input type="hidden" id="sendEdit" name="sendEdit" value="">
<input type="hidden" id="sendPush" name="sendPush" value="">
<input type="hidden" id="glID" name="glID" value="<? echo $profile; ?>">
<div tabindex="-1" class="modal fade bs-modal-md" id="getEdit" aria-hidden="true" style="display: none;">
<div class="modal-dialog modal-md"><div class="modal-content"><div class="modal-header">
<h4 class="modal-title">Изменение данных</h4></div>
<div class="modal-body">
<div class="portlet light bordered">
<div class="portlet-body"><div class="form-body">
<div class="form-group form-md-line-input form-md-floating-label has-info">
<input type="text" class="form-control input-md" id="glname" value="<?=$first_name;?>">
<label for="form_control_1">Имя</label></div>
<div class="form-group form-md-line-input form-md-floating-label has-info">
<input type="text" class="form-control input-md" id="gllast" value="<?=$last_name;?>">
<label for="form_control_1">Фамилия</label></div>
<div class="form-group form-md-line-input form-md-floating-label has-info">
<input type="text" class="form-control input-md" id="glphoto" value="<?=$photo;?>">
<label for="form_control_1">Фотография</label></div>
<div class="form-group form-md-line-input form-md-floating-label has-info">
<input type="text" class="form-control input-md" id="glmoney" value="<?=$money;?>">
<label for="form_control_1">Деньги</label></div></div></div></div>

<div class="portlet light bordered"><div class="portlet-body"><div class="form-body">
<div class="form-group form-md-line-input form-md-floating-label has-error">
<select class="form-control edited" id="gladmin" name="gladmin"><?=$privelegy;?></select>
<label for="form_control_1">Тип Аккаунта</label></div>
<div class="form-group form-md-line-input form-md-floating-label has-info">
<select class="form-control edited" id="glverify" name="glverify"><?=$verity;?></select>
<label for="form_control_1">Верификация</label></div>
<div class="form-group form-md-line-input form-md-floating-label has-info">
<select class="form-control edited" id="glhid" name="glhid"><?=$hideny;?></select>
<label for="form_control_1">Профиль</label></div></div></div></div>
</div><div class="modal-footer">
<button class="btn green btn-circle" type="button" data-dismiss="modal">Закрыть</button>
<button name="submit" class="btn red btn-circle" id="submit" onclick="sendEdit()" type="button" value="submit" data-dismiss="modal">Сохранить</button>
</div></div></div></div>
<? } ?>


<?
$ul1 = $mysqli->query('SELECT `id` FROM `users` WHERE `profile` = "'.$_SESSION['uid'].'"')->fetch_array();
if($_GET['id'] == $ul1['id']) {echo '
<div class="modal fade bs-modal-lg" id="status_edit" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header">
<h4 class="modal-title">Редактирование статуса</h4></div><div class="modal-body">
<li class="list-group-item">Выберете статус.</li><li class="list-group-item">
<select class="form-control" id="statusNum1" name="statusNum1">
<option value="1">1</option><option value="2">2</option>
<option value="3">3</option><option value="4">4</option>
<option value="5">5</option><option value="6">6</option>
<option value="7">7</option><option value="8">8</option>
<option value="9">9</option><option value="10">10</option>
<option value="11">11</option></select></li></div><div class="modal-footer">
<button type="button" class="btn green" data-dismiss="modal" name="submit" id="submit" value="submit" onclick="statusChange()">Изменить</button>
<button type="button" class="btn red" data-dismiss="modal">Отмена</button></div></div></div></div>

<div class="modal fade bs-modal-sm" id="Status_del" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog modal-sm"><div class="modal-content"><div class="modal-header">
<h4 class="modal-title">Удаление автостатуса</h4>
</div><div class="modal-body">Вы уверены что хотите удалить автостатус?</div><div class="modal-footer">
<button type="button" class="btn green" data-dismiss="modal" name="submit" id="submit" value="submit" onclick="statusDel()">Удалить</button>
<button type="button" class="btn red" data-dismiss="modal">Отмена</button></div></div></div></div>

<input type="hidden" id="goToFunc3" name="goToFunc3" value="goToFunc3">
<div class="modal fade bs-modal-sm" id="Group_del" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog modal-sm"><div class="modal-content"><div class="modal-header">
<h4 class="modal-title">Удаление автостатуса из группы</h4>
</div><div class="modal-body">Вы уверены что хотите удалить автостатус из группы?</div><div class="modal-footer">
<button type="button" class="btn green" data-dismiss="modal" name="submit" id="submit" value="submit" onclick="groupDelFunc()">Удалить</button>
<button type="button" class="btn red" data-dismiss="modal">Отмена</button></div></div></div></div>

<input type="hidden" id="goToFunc4" name="goToFunc4" value="goToFunc4">
<div class="modal fade bs-modal-sm" id="Online_del" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog modal-sm"><div class="modal-content"><div class="modal-header">
<h4 class="modal-title">Удаление онлайна</h4>
</div><div class="modal-body">Вы уверены что хотите удалить автостатус из группы?</div><div class="modal-footer">
<button type="button" class="btn green" data-dismiss="modal" name="submit" id="submit" value="submit" onclick="onlineDelFunc()">Удалить</button>
<button type="button" class="btn red" data-dismiss="modal">Отмена</button></div></div></div></div>

<input type="hidden" id="goToFunc5" name="goToFunc5" value="goToFunc5">
<div class="modal fade bs-modal-sm" id="Func_del" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog modal-sm"><div class="modal-content"><div class="modal-header">
<h4 class="modal-title">Удаление онлайна</h4>
</div><div class="modal-body">Вы уверены что хотите удалить функции?</div><div class="modal-footer">
<button type="button" class="btn green" data-dismiss="modal" name="submit" id="submit" value="submit" onclick="profileDelFunc()">Удалить</button>
<button type="button" class="btn red" data-dismiss="modal">Отмена</button></div></div></div></div>

<input type="hidden" id="goToFunc6" name="goToFunc6" value="goToFunc6">
<div class="modal fade bs-modal-sm" id="liker_del" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog modal-sm"><div class="modal-content"><div class="modal-header">
<h4 class="modal-title">Удаление лайкера</h4>
</div><div class="modal-body">Вы уверены что хотите удалить лайкер?</div><div class="modal-footer">
<button type="button" class="btn green" data-dismiss="modal" name="submit" id="submit" value="submit" onclick="likerDelFunc()">Удалить</button>
<button type="button" class="btn red" data-dismiss="modal">Отмена</button></div></div></div></div>'; }

function curl($url){
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true );
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false );
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false );
	$response = curl_exec($ch); curl_close($ch);
	return $response;
}

#Done
include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php');
?>
