<? if(isset($_GET['request'])){
    include($_SERVER['DOCUMENT_ROOT'].'/data/connect.php');
    $title = ''.$site['Name'].' • API Вконтакте';
	$menu['api'] = 'active animated fadeIn';
	include($_SERVER['DOCUMENT_ROOT'].'/data/head.php');
?>
<div class="col-md-12">
<div class="portlet light portlet-fit portlet-form bordered">
<div class="portlet-title"><div class="caption"><i class="fa fa-user font-blue"></i>
<span class="caption-subject font-dark sbold uppercase">Поиск людей</span>
</div></div><div class="portlet-body"><div class="form-body">

<div class="mt-element-card mt-element-overlay" id="info" name="info">
<div class="row">

<?
if(empty($_GET['request'])){ echo '<div class="col-md-12 animated fadeInUp"><div class="alert alert-dismissable alert-danger">Не найдено</div></div>'; } else{
$firstget = $mysqli->query('SELECT * FROM `users` WHERE first_name LIKE "%'.$_GET['request'].'%" OR last_name LIKE "%'.$_GET['request'].'%" ORDER BY id DESC');

if($firstget->num_rows == 0){ echo '<div class="col-md-12 animated fadeInUp"><div class="alert alert-dismissable alert-danger">Не найдено</div></div>'; }

while($row = $firstget->fetch_array()) {
echo '<div class="col-md-3"><div class="panel">
<div class="panel-body"><div class="mt-overlay-3 mt-overlay-3-icons">
<img src="'.$row['photo'].'"><div class="mt-overlay"><h2>'.$row['first_name'].' '.$row['last_name'].' <br> • ID'.$row['id'].' •</h2><ul class="mt-info">
<li><a class="btn blue btn-circle" href="/id'.$row['id'].'"><i class="fa fa-user"></i></a></li></ul></div></div></div></div></div>'; } }?>

</div></div></div></div></div></div>
<? include($_SERVER['DOCUMENT_ROOT'].'/data/foot.php'); } else{ header("Location: /"); } ?>
